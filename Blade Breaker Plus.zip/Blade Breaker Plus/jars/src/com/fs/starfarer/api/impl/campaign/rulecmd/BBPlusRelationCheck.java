package com.fs.starfarer.api.impl.campaign.rulecmd;

import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.util.Misc;
import java.util.List;
import java.util.Map;
/**
 *
 * @author techpriest
 */
public class BBPlusRelationCheck extends BaseCommandPlugin {
	
    @Override
    public boolean execute(final String ruleId, final InteractionDialogAPI dialog, final List<Misc.Token> params, final Map<String, MemoryAPI> memoryMap) {
        if (dialog == null) {
            return false;
        }
        
        final int relation = params.get(0).getInt((Map)memoryMap);
        final int current = params.get(1).getInt((Map)memoryMap);
        final SectorEntityToken entity = dialog.getInteractionTarget();
        
        if (entity.getActivePerson() == null) {
            return false;
        }
        if (current == 100) {
            return entity.getActivePerson().getRelToPlayer().getRepInt() >= relation && entity.getActivePerson().getRelToPlayer().getRepInt() <= current;
        }
        
        return entity.getActivePerson().getRelToPlayer().getRepInt() >= relation && entity.getActivePerson().getRelToPlayer().getRepInt() < current;
    }
    
}