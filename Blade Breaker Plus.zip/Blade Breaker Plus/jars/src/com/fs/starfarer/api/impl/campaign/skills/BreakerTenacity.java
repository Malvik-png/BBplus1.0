package com.fs.starfarer.api.impl.campaign.skills;

import com.fs.starfarer.api.characters.ShipSkillEffect;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
/**
 *
 * @author Mayu
 */
public class BreakerTenacity {
	        
    public static final float ROF_BONUS = 15f;
    public static final float DEGRADE_REDUCTION_PERCENT = 15f;
    public static final float ENMITY_BONUS = 15f;
    public static final float ENMITY_BONUS_SPEED = 10f;
    public static final float HULL_POINTS = 50f;

    public static class Level1 implements ShipSkillEffect {
            
        @Override
        public void apply(final MutableShipStatsAPI stats, final HullSize hullSize, final String id, final float level) {
            if (stats.getVariant().hasHullMod("istl_bbengineering")){
                stats.getCRLossPerSecondPercent().modifyMult(id, 1f - DEGRADE_REDUCTION_PERCENT / 100f); 
            }
        }

        @Override
        public void unapply(final MutableShipStatsAPI stats, final HullSize hullSize, final String id) {
                stats.getCRLossPerSecondPercent().unmodify(id);
        }
      
        @Override
        public String getEffectDescription(final float level) {
            return "-" + (int)(DEGRADE_REDUCTION_PERCENT) + "% combat readiness degradation rate after peak performance time runs out (piloted Blade Breaker ship)";                       
        }
                
        @Override
        public String getEffectPerLevelDescription() {
            return null;
        }
		
        @Override
        public ScopeDescription getScopeDescription() {
            return ScopeDescription.PILOTED_SHIP;
        }
    
    } 
                                
    public static class Level2 implements ShipSkillEffect {
		
        @Override
        public void apply(final MutableShipStatsAPI stats, final HullSize hullSize, final String id, final float level) {
            if (stats.getVariant().hasHullMod("istl_bbengineering")){
                stats.getBallisticRoFMult().modifyPercent(id, ROF_BONUS);
                stats.getEnergyRoFMult().modifyPercent(id, ROF_BONUS);
            }
        }
		
        @Override
        public void unapply(final MutableShipStatsAPI stats, final HullSize hullSize, final String id) {
            stats.getBallisticRoFMult().unmodify(id);
            stats.getEnergyRoFMult().unmodify(id);
        }	
		
        @Override
        public String getEffectDescription(final float level) {
            return "+" + (int) ROF_BONUS + "% rate of fire for ballistic and energy weapons (piloted Blade Breaker ship)";
        }
		
        @Override
        public String getEffectPerLevelDescription() {
            return null;
        }
		
        @Override
        public ScopeDescription getScopeDescription() {
            return ScopeDescription.PILOTED_SHIP;
        }

    }  

    public static class Level3 implements ShipSkillEffect {
            
        @Override
        public void apply(final MutableShipStatsAPI stats, final HullSize hullSize, final String id, final float level) { 
            //Placeholder
        }
                
        @Override
        public void unapply(final MutableShipStatsAPI stats, final HullSize hullSize, final String id) {
            //Placeholder
        }
                                     
        @Override
        public String getEffectDescription(final float level) {
            return "+" + (int) ENMITY_BONUS_SPEED  + " top speed when hull integrity falls below " + (int) HULL_POINTS + "% (piloted Blade Breaker ship)";
        }
                
        @Override
        public String getEffectPerLevelDescription() {
            return null;
        }
		
        @Override
        public ScopeDescription getScopeDescription() {
            return ScopeDescription.PILOTED_SHIP;
        }
    } 

    public static class Level4 implements ShipSkillEffect {
    
        @Override
        public void apply(final MutableShipStatsAPI stats, final HullSize hullSize, final String id, final float level) { 
            if (stats.getVariant().hasHullMod("istl_bbengineering")){
                stats.getVariant().addMod("bbplus_breaker_tenacity"); 
            }
        } 
                
        @Override
        public void unapply(final MutableShipStatsAPI stats, final HullSize hullSize, final String id) {
            stats.getVariant().removeMod("bbplus_breaker_tenacity");
        }
                                     
        @Override
        public String getEffectDescription(final float level) {
            return "+" + (int) ENMITY_BONUS + "% ballistic and energy weapon damage when hull integrity falls below " + (int) HULL_POINTS + "% (piloted Blade Breaker ship)";
        }
                
        @Override
        public String getEffectPerLevelDescription() {
            return null;
        }
		
        @Override
        public ScopeDescription getScopeDescription() {
            return ScopeDescription.PILOTED_SHIP;
        }
    
    }       
    
}