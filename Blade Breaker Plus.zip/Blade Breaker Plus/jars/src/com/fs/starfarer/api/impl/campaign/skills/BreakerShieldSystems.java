package com.fs.starfarer.api.impl.campaign.skills;

import com.fs.starfarer.api.characters.ShipSkillEffect;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
/**
 *
 * @author Mayu
 */
public class BreakerShieldSystems {
	        
    public static final float SHIELD_BEAM_REDUCTION = 30f;
    public static final float SHIELD_KINETIC_REDUCTION = 30f;
    public static final float SHIELD_FRAG_REDUCTION = 30f;
    public static final float SHIELD_UNFOLD_RATE = 15f;

    public static class Level1 implements ShipSkillEffect {
            
        @Override
        public void apply(final MutableShipStatsAPI stats, final HullSize hullSize, final String id, final float level) {
            if (stats.getVariant().hasHullMod("istl_bbengineering")){
                    stats.getBeamShieldDamageTakenMult().modifyMult(id, 1f - SHIELD_BEAM_REDUCTION / 100f);
                    stats.getEnergyShieldDamageTakenMult().modifyMult(id, 1f - SHIELD_BEAM_REDUCTION / 100f);                        
                    //stats.getHighExplosiveShieldDamageTakenMult().modifyMult(id, -0.80f);
                    //stats.getMissileShieldDamageTakenMult().modifyMult(id, -0.80f);                   
            }
        }
                
        @Override
        public void unapply(final MutableShipStatsAPI stats, final HullSize hullSize, final String id) {
            stats.getBeamShieldDamageTakenMult().unmodify(id);
            stats.getEnergyShieldDamageTakenMult().unmodify(id);
        }
                
        @Override 
        public String getEffectDescription(final float level) {
            return "-" + (int) SHIELD_BEAM_REDUCTION + "% beam damage to shields (piloted Blade Breaker ship)";
        }
                
        @Override
        public String getEffectPerLevelDescription() {
            return null;
        }

        @Override
        public ScopeDescription getScopeDescription() {
            return ScopeDescription.PILOTED_SHIP;
        }

    } 
                                
    public static class Level2 implements ShipSkillEffect {
		
        @Override
        public void apply(final MutableShipStatsAPI stats, final HullSize hullSize, final String id, final float level) {
            if (stats.getVariant().hasHullMod("istl_bbengineering")){
                stats.getFragmentationShieldDamageTakenMult().modifyMult(id, 1f - SHIELD_FRAG_REDUCTION / 100f);
            }
        }
		
        @Override
        public void unapply(final MutableShipStatsAPI stats, final HullSize hullSize, final String id) {
            stats.getFragmentationShieldDamageTakenMult().unmodify(id);
        }	

        @Override
        public String getEffectDescription(final float level) {
            return "-" + (int) SHIELD_FRAG_REDUCTION + "% fragmentation damage to shields (piloted Blade Breaker ship)";
        }
		
        @Override
        public String getEffectPerLevelDescription() {
            return null;
        }
		
        @Override
        public ScopeDescription getScopeDescription() {
            return ScopeDescription.PILOTED_SHIP;
        }

    }  
        
    public static class Level3 implements ShipSkillEffect {
            
        @Override
        public void apply(final MutableShipStatsAPI stats, final HullSize hullSize, final String id, final float level) {
            if (stats.getVariant().hasHullMod("istl_bbengineering")){
                stats.getKineticShieldDamageTakenMult().modifyMult(id, 1f - SHIELD_KINETIC_REDUCTION / 100f);                            
            }
        }
                
        @Override
        public void unapply(final MutableShipStatsAPI stats, final HullSize hullSize, final String id) {
            stats.getKineticShieldDamageTakenMult().unmodify(id);
        }
                
        @Override
        public String getEffectDescription(final float level) {
            return "-" + (int) SHIELD_KINETIC_REDUCTION + "% kinetic damage to shields (piloted Blade Breaker ship)";
        }
                
        @Override
        public String getEffectPerLevelDescription() {
            return null;
        }

        @Override
        public ScopeDescription getScopeDescription() {
            return ScopeDescription.PILOTED_SHIP;
        }

    } 
    
    public static class Level4 implements ShipSkillEffect {
            
        @Override
        public void apply(final MutableShipStatsAPI stats, final HullSize hullSize, final String id, final float level) {
            if (stats.getVariant().hasHullMod("istl_bbengineering")){
                stats.getShieldTurnRateMult().modifyPercent(id, SHIELD_UNFOLD_RATE);
                stats.getShieldUnfoldRateMult().modifyPercent(id, SHIELD_UNFOLD_RATE);
            }
        }

        @Override
        public void unapply(final MutableShipStatsAPI stats, final HullSize hullSize, final String id) {
            stats.getShieldTurnRateMult().unmodify(id);
            stats.getShieldUnfoldRateMult().unmodify(id);
        }
                
        @Override
        public String getEffectDescription(final float level) {
            return "+" + (int) SHIELD_UNFOLD_RATE + "% shield raise rate and shield turn rate (piloted Blade Breaker ship)";
        }

        @Override
        public String getEffectPerLevelDescription() {
            return null;
        }
		
        @Override
        public ScopeDescription getScopeDescription() {
            return ScopeDescription.PILOTED_SHIP;
        }

    }         
        
}