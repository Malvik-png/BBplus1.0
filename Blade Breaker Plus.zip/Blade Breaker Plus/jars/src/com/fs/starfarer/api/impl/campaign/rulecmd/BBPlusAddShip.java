package com.fs.starfarer.api.impl.campaign.rulecmd;

import com.fs.starfarer.api.combat.ShipVariantAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.util.Misc;
import java.util.List;
import java.util.Map;
/**
 *
 * @author techpriest
 */
public class BBPlusAddShip extends BaseCommandPlugin {
	
    @Override
    public boolean execute(final String ruleId, final InteractionDialogAPI dialog, final List<Misc.Token> params, final Map<String, MemoryAPI> memoryMap) {
        if (dialog == null) {
            return false;
        }
        
        final String hullvariant = params.get(0).getString((Map)memoryMap);
        final String shipname = params.get(1).getString((Map)memoryMap);
        final FleetMemberAPI ship = Global.getFactory().createFleetMember(FleetMemberType.SHIP, hullvariant);
        ship.setShipName("FSS " + shipname);
		
        Global.getSector().getPlayerFleet().getFleetData().addFleetMember(ship);
        final ShipVariantAPI nextvariant = Global.getSettings().getVariant(hullvariant);
        AddRemoveCommodity.addFleetMemberGainText(nextvariant, dialog.getTextPanel());
        Global.getSoundPlayer().playUISound("bbplus_cargo_commodity_ui", 1f, 1f);
        
        return true;
    }
    
}