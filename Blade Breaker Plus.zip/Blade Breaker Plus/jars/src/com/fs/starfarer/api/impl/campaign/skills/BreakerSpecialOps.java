package com.fs.starfarer.api.impl.campaign.skills;

import com.fs.starfarer.api.characters.ShipSkillEffect;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import java.util.HashMap;
import java.util.Map;
/**
 *
 * @author Mayu
 */
@SuppressWarnings("MapReplaceableByEnumMap")
public class BreakerSpecialOps {
	
    public final static Map<HullSize, Float> BONUS = new HashMap<ShipAPI.HullSize, Float>();
        static 
        {
            BONUS.put(HullSize.FRIGATE, 4f);
            BONUS.put(HullSize.DESTROYER, 6f);
            BONUS.put(HullSize.CRUISER, 8f);
            BONUS.put(HullSize.CAPITAL_SHIP, 10f);
        }
    //public static final float OP_BONUS = 10f;      
    public static final float CAPACITORS_BONUS = 10f;
    public static final float VENTS_BONUS = 10f;
    public static final float OVERLOAD_REDUCTION = 25f;
    //public static final int EXTRA_MODS = 1;

    public static class Level1 implements ShipSkillEffect {
            
        @Override
        public void apply(final MutableShipStatsAPI stats, final HullSize hullSize, final String id, final float level) {
            if (stats.getVariant().hasHullMod("istl_bbengineering")){
                stats.getFluxDissipation().modifyPercent(id, CAPACITORS_BONUS);
                stats.getFluxCapacity().modifyPercent(id, VENTS_BONUS);
            }
            //Global.getSector().getPlayerPerson().getStats().getShipOrdnancePointBonus().modifyPercent(id, OP_BONUS);
        }
                
        @Override
        public void unapply(final MutableShipStatsAPI stats, final HullSize hullSize, final String id) {
            stats.getFluxDissipation().unmodify(id);
            stats.getFluxCapacity().unmodify(id);
            //Global.getSector().getPlayerPerson().getStats().getShipOrdnancePointBonus().unmodify(id);
        }
      
        @Override
        public String getEffectDescription(final float level) {
            return "+" + (int) CAPACITORS_BONUS + "% maximum flux capacitors and vents (piloted Blade Breaker ship)";
        }
                
        @Override
        public String getEffectPerLevelDescription() {
            return null;
        }
		
        @Override
        public ScopeDescription getScopeDescription() {
            return ScopeDescription.PILOTED_SHIP;
        }

    } 
                                
    public static class Level2 implements ShipSkillEffect {
		
        @Override
        public void apply(final MutableShipStatsAPI stats, final HullSize hullSize, final String id, final float level) {
            if (stats.getVariant().hasHullMod("istl_bbengineering")){
                stats.getOverloadTimeMod().modifyMult(id, 1f - OVERLOAD_REDUCTION / 100f);
            }
        }
		
        @Override
        public void unapply(final MutableShipStatsAPI stats, final HullSize hullSize, final String id) {
            stats.getOverloadTimeMod().unmodify(id);
        }	

        @Override
        public String getEffectDescription(final float level) {
            return "-" + (int)(OVERLOAD_REDUCTION) + "% overload duration (piloted Blade Breaker ship)";
        }

        @Override
        public String getEffectPerLevelDescription() {
            return null;
        }
		
        @Override
        public ScopeDescription getScopeDescription() {
            return ScopeDescription.PILOTED_SHIP;
        }

    }  
        
    public static class Level3 implements ShipSkillEffect {
            
        @Override
        public void apply(final MutableShipStatsAPI stats, final HullSize hullSize, final String id, final float level) {
            final Float bonus = BONUS.get(hullSize);
          //if (stats.getVariant().hasHullMod("istl_bbengineering")){
            if (bonus != null) {
                stats.getDynamic().getMod(Stats.ELECTRONIC_WARFARE_FLAT).modifyFlat(id, bonus);
                            }
          //}
        }

        @Override
        public void unapply(final MutableShipStatsAPI stats, final HullSize hullSize, final String id) {
            stats.getDynamic().getMod(Stats.ELECTRONIC_WARFARE_FLAT).unmodify(id);
        }

        @Override
        public String getEffectDescription(final float level) {
            int frigate = (int)Math.round(BONUS.get(HullSize.FRIGATE));
            int destroyer = (int)Math.round(BONUS.get(HullSize.DESTROYER));
            int cruiser = (int)Math.round(BONUS.get(HullSize.CRUISER));
            int capital = (int)Math.round(BONUS.get(HullSize.CAPITAL_SHIP));
            return "+" + frigate + "/" + destroyer + "/" + cruiser + "/" + capital + "% to ECM rating of ships, depending on ship size";
        }
                
        @Override
        public String getEffectPerLevelDescription() {
            return null;
        }

        @Override
        public ScopeDescription getScopeDescription() {
            return ScopeDescription.PILOTED_SHIP;
        }

    } 
             	
}