package com.fs.starfarer.api.impl.campaign.rulecmd;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoPickerListener;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.OptionPanelAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.TextPanelAPI;
import com.fs.starfarer.api.campaign.econ.CommoditySpecAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.RepActionEnvelope;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.RepActions;
import com.fs.starfarer.api.impl.campaign.ids.Strings;
import com.fs.starfarer.api.campaign.comm.CommMessageAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.Misc.Token;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Map;
import java.awt.Color;
import org.apache.log4j.Logger;
import data.campaign.ids.istl_Commodities;
import com.fs.starfarer.api.impl.campaign.ids.BBPlus_Ranks;
/**
 * If you have complains, have sex techpriest
 * @author Mayu
 */
public class SigmaMatterTrader extends BaseCommandPlugin {
	
    protected CampaignFleetAPI playerFleet;
    protected SectorEntityToken entity;
    protected FactionAPI playerFaction;
    protected FactionAPI entityFaction;
    protected TextPanelAPI text;
    protected OptionPanelAPI options;
    protected CargoAPI playerCargo;
    protected MemoryAPI memory;
    protected MarketAPI market;
    protected InteractionDialogAPI dialog;
    protected Map<String, MemoryAPI> memoryMap;
    protected PersonAPI person;
    protected FactionAPI faction;
    protected boolean buysSigmaMatters;
    protected float valueMult;
    protected float repMult;
    public static final String GEMIE = "Gemie";
    public static final String SEPHIRALABS = "Sephira Research Labs";
    public static Logger log = Global.getLogger(SigmaMatterTrader.class);
    final Color green = new Color(55,245,65,255);
    public static final Set<String> SMATTERS_IDS = new HashSet<>(Arrays.asList(new String[] {
        istl_Commodities.SIGMA_MATTER_UNSTABLE,
        istl_Commodities.SIGMA_MATTER_LOW,
        istl_Commodities.SIGMA_MATTER_HIGH,
    }));        
        
    @Override
    public boolean execute(final String ruleId, final InteractionDialogAPI dialog, final List<Token> params, final Map<String, MemoryAPI> memoryMap) {	
        this.dialog = dialog;
        this.memoryMap = memoryMap;
        this.memory = getEntityMemory(memoryMap);
        this.entity = dialog.getInteractionTarget();
        this.text = dialog.getTextPanel();
        this.options = dialog.getOptionPanel();
        this.playerFleet = Global.getSector().getPlayerFleet();
        this.playerCargo = this.playerFleet.getCargo();
        this.playerFaction = Global.getSector().getPlayerFaction();
        this.entityFaction = this.entity.getFaction();
        this.person = dialog.getInteractionTarget().getActivePerson();
        this.faction = this.person.getFaction();
        this.buysSigmaMatters = this.faction.getCustomBoolean("buysSigmaMatters");
        this.valueMult = this.faction.getCustomFloat("SigmaMatterValueMult");
        this.repMult = this.faction.getCustomFloat("SigmaMatterRepMult");
        // Used for JSON and Rules.csv
        final String command = params.get(0).getString((Map)memoryMap);
        if (command == null) {
            return false;
        }            
        switch (command) {
      //case "selectSigmaMatters":
            //selectSigmaMatters();
            //break;
        case "playerHasSigmaMatters":
            return playerHasSigmaMatters();
        case "personCanAcceptSigmaMatters":
            return personCanAcceptSigmaMatters();
        case "selectligma":
            this.selectSigmaMatters();
            break;
        default:
            break;
        }
        return true;
    }
    // We don't want other factions trading ligmas right?
    // So sad that Artemisia Sun died of ligma...................................
    protected boolean personCanAcceptSigmaMatters() {
        if (person == null || !buysSigmaMatters) {
            return false;
        }
        return BBPlus_Ranks.CHIEF_RESEARCHER.equals(person.getPostId());
    }

    protected void selectSigmaMatters() {
        final CargoAPI copy = Global.getFactory().createCargo(false);
        for (final CargoStackAPI stack : this.playerCargo.getStacksCopy()) {
            if (isSigmaMatters(stack)) {
                copy.addFromStack(stack);
            }
        }
        copy.sort();	
        final float width = 310f;
        //final InteractionDialogAPI dialog = this.dialog;
        //final Map<String, MemoryAPI> memoryMap = this.memoryMap;                 
        this.dialog.showCargoPickerDialog("Select a Sigma Matter to turn in", "Confirm", "Cancel", true, width, copy, (CargoPickerListener)new CargoPickerListener() {
            @Override
            public void pickedCargo(final CargoAPI cargo) {
                cargo.sort();
                for (final CargoStackAPI stack : cargo.getStacksCopy()) {
                    SigmaMatterTrader.this.playerCargo.removeItems(stack.getType(), stack.getData(), stack.getSize());                         
                    if (stack.isCommodityStack()) { // should be always, but just in case
                        AddRemoveCommodity.addCommodityLossText(stack.getCommodityId(), (int) stack.getSize(), SigmaMatterTrader.this.text);
                    }
                }
            
                final float bounty = SigmaMatterTrader.this.computeSigmaCreditValue(cargo);
                final float repChange = SigmaMatterTrader.this.computeSigmaReputationValue(cargo);

                if (bounty > 0.0f) {
                    SigmaMatterTrader.this.playerCargo.getCredits().add(bounty);
                    AddRemoveCommodity.addCreditsGainText((int)bounty, SigmaMatterTrader.this.text);
                }
				
                if (repChange >= 1f) {
                    final CoreReputationPlugin.CustomRepImpact impact = new CoreReputationPlugin.CustomRepImpact();
                    final CoreReputationPlugin.CustomRepImpact impact2 = new CoreReputationPlugin.CustomRepImpact();
                    impact.delta = repChange * 0.01f;
                    impact2.delta = repChange * 0.01f;
                    impact2.delta *= 0.50f;
                    // rep to faction
                    Global.getSector().adjustPlayerReputation(
                        new RepActionEnvelope(
                            RepActions.CUSTOM, impact2,
                            null, text, true
                        ), 
                        faction.getId()
                    );
                    //if (impact.delta >= 0.01f) { // OG
                    //	Global.getSector().adjustPlayerReputation(
                    //			new RepActionEnvelope(RepActions.CUSTOM, impact,
                    //								  null, text, true), 
                    //								  person);
                    //}
                    //impact.delta *= 0.25f; // Old part
                    if (impact.delta >= 0.01f) {
                        Global.getSector().adjustPlayerReputation(
                           (Object)new CoreReputationPlugin.RepActionEnvelope(
                                CoreReputationPlugin.RepActions.CUSTOM, (Object)impact,
                                   (CommMessageAPI)null, SigmaMatterTrader.this.text, true), 
                                        SigmaMatterTrader.this.person);
                    }
                }
                FireBest.fire((String)null, SigmaMatterTrader.this.dialog, (Map)SigmaMatterTrader.this.memoryMap, "SigmaMattersTurnedIn");
            }
                        
            @Override
            public void cancelledCargoSelection() {
            //return;
            }
                        
            @Override
            public void recreateTextPanel(final TooltipMakerAPI panel, final CargoAPI cargo, final CargoStackAPI pickedUp, final boolean pickedUpFromSource, final CargoAPI combined) {
                final float bounty = SigmaMatterTrader.this.computeSigmaCreditValue(combined);
                final float repChange = SigmaMatterTrader.this.computeSigmaReputationValue(combined);
                //final float repChange = (int)(SigmaMatterTrader.this.computeSigmaReputationValue(combined) / 0.55f);
                final float pad = 3f;
                //float small = 5f;
                final float opad = 10f;
                panel.setParaFontOrbitron();
                panel.addPara(Misc.ucFirst(faction.getDisplayName()), SigmaMatterTrader.this.faction.getBaseUIColor(), 1f);
                panel.setParaFontDefault();		
                panel.addImage(faction.getLogo(), width * 1f, 3f);
                panel.addImage(Global.getSettings().getSpriteName("tooltips", "sigmalist"), width * 1f, 3f);
                panel.addPara(
                        "Turning Sigma Matter in to " + 
                        SigmaMatterTrader.this.faction.getDisplayNameLongWithArticle() + " " +
                        "will help the progress of %s yielding better result in:", opad, Misc.getHighlightColor(), new String[] { SEPHIRALABS }
                    );
                panel.beginGridFlipped(width, 1, 40f, 10f);
                panel.addToGrid(0, 0, "Gratituity value", "" + (int)(SigmaMatterTrader.this.valueMult * 100f) + "%");
                panel.addToGrid(0, 1, "Relation gain", "" + (int)(SigmaMatterTrader.this.repMult * 100f) + "%");
                //panel.addToGrid(0, 2, "Faction reputation gain", "" + (int)(SigmaMatterTrader.this.repMult * 0.55f) + "%");
                panel.addGrid(pad);
                //faction.getDisplayNameWithArticle() 
                //+ (int) repChange2 + ""
                panel.addPara(
                        "If you turn in the selected Sigma Matter(s), you will receive a %s payment " +
                        "and your relationship with %s will improve by %s points. " +
                        "Reputation with the Deserters will improve by %s points as well.",
                        opad * 1f, green,
                        Misc.getWithDGS(bounty) + Strings.C, GEMIE + "",
                        "" + (int) repChange, "" + (int) repChange / 2 + ""
                    );
	    }
        });
    }

    protected float computeSigmaCreditValue(final CargoAPI cargo) {
        float bounty = 0;
        for (final CargoStackAPI stack : cargo.getStacksCopy()) {
            final CommoditySpecAPI spec = stack.getResourceIfResource();
                if (spec != null && spec.hasTag("sigma_matter")) {
                    bounty += spec.getBasePrice() * stack.getSize();
                }
            }
        bounty *= valueMult;
        return bounty;
    }
	
    protected float computeSigmaReputationValue(final CargoAPI cargo) {
        float rep = 0;
        for (final CargoStackAPI stack : cargo.getStacksCopy()) {
            final CommoditySpecAPI spec = stack.getResourceIfResource();
                if (spec != null && spec.hasTag("sigma_matter")) {
                    rep += getBaseRepValue(spec.getId()) * stack.getSize();
                }
        }
        rep *= repMult;
        //if (rep < 1f) rep = 1f;
        return rep;
    }
	
    public static float getBaseRepValue(final String SigmaMatterType) {
        if (istl_Commodities.SIGMA_MATTER_HIGH.equals(SigmaMatterType)) {
            return 6f;
        }
        if (istl_Commodities.SIGMA_MATTER_LOW.equals(SigmaMatterType)) {
            return 4f;
        }
        if (istl_Commodities.SIGMA_MATTER_UNSTABLE.equals(SigmaMatterType)) {
            return 2f;
        }
        return 1f;
    }

    protected boolean playerHasSigmaMatters() {
        for (final CargoStackAPI stack : playerCargo.getStacksCopy()) {
        final CommoditySpecAPI spec = stack.getResourceIfResource();
        //if (spec == null) return false;
        //String id = spec.getId();
            if (spec != null && spec.hasTag("sigma_matter")) {
                return true;
            }//!ALLOWED_IDS.contains(id)
        }  //spec.getDemandClass().equals(istl_Commodities.SIGMA_MATTER)
        //spec != null && spec.getDemandClass().equals(istl_Commodities.SIGMA_MATTER)
        return false;
    }
      
    public static boolean isSigmaMatters(final CargoStackAPI stack) {
        final CommoditySpecAPI spec = stack.getResourceIfResource();
        if (spec == null) return false;
        final String id = spec.getId();
        //if (!spec.hasTag("sigma_matter") && !SMATTERS_IDS.contains(id))
        //    return false;
        //return true;
        return !(!spec.hasTag("sigma_matter") && !SMATTERS_IDS.contains(id));
    }        
           
}