package com.fs.starfarer.api.impl.campaign.rulecmd;

import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import java.util.List;
import java.util.Map;

public class BBPlusAddSpecial extends BaseCommandPlugin {
	
    @Override
    public boolean execute(final String ruleId, final InteractionDialogAPI dialog, final List<Misc.Token> params, final Map<String, MemoryAPI> memoryMap) {
        if (dialog == null) {
            return false;
        }
        
        final String id1 = params.get(0).getString((Map)memoryMap);
        
        if (params.size() > 1) {
            final String data2 = params.get(1).getString((Map)memoryMap);
            Global.getSector().getPlayerFleet().getCargo().addSpecial(new SpecialItemData(id1, data2), 1.0f);
        }
        else {
            Global.getSector().getPlayerFleet().getCargo().addSpecial(new SpecialItemData(id1, (String)null), 1.0f);
        }
        Global.getSoundPlayer().playUISound("bbplus_cargo_special_ui", 1f, 1f);
        
        return true;
    }
    
}