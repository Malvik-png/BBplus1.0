package com.fs.starfarer.api.impl.campaign.ids;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.PersonImportance;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.characters.FullName.Gender;
import com.fs.starfarer.api.characters.ImportantPeopleAPI;
import com.fs.starfarer.api.characters.PersonAPI;

@SuppressWarnings("UnusedAssignment") //fuck u IDE
public class BBPlus_People extends People {

        // Starkeep Sephira Inhabitants
        public static final String MELVA = "bbplus_melva";
        public static final String SEVUS = "bbplus_sevus";
        public static final String GEMIE = "bbplus_gemie";
        public static final String BAROLT = "bbplus_barolt";
        public static final String ROLAND = "bbplus_roland";
        // Night Ravens Mercenaries
        public static final String ASELIA = "bbplus_aselia";
        public static final String RIEN = "bbplus_rien";
        public static final String LEONHARD = "bbplus_leonhard";
        // Dummy stuff for dialogues
        public static final String DUMMYONE = "bbplus_gemie_dm"; //wtf two gemies!!?!?!
                
	public static PersonAPI getPerson(final String id) {
            return Global.getSector().getImportantPeople().getPerson(id);
	}
	   
	public void advance() {
            createFactionLeaders();
            createMiscCharacters();
	}

    public static void createFactionLeaders() {
        final ImportantPeopleAPI ip = Global.getSector().getImportantPeople();
        MarketAPI market = null;
    	// mama melva
        market =  Global.getSector().getEconomy().getMarket("deserter_starkeep");
		if (market != null) {
			PersonAPI person = Global.getFactory().createPerson();
			person.setId(MELVA);
			person.setFaction("the_deserter_ex");
			person.setGender(Gender.FEMALE);
			person.setRankId("bbplus_head_of_operations");
			person.setPostId("factionLeader");
			person.setImportance(PersonImportance.VERY_HIGH);
			person.getName().setFirst("Melva");
			person.getName().setLast("Hawthorne");
			person.setPortraitSprite(Global.getSettings().getSpriteName("characters", "melva"));
			person.getStats().setSkillLevel(Skills.SPACE_OPERATIONS, 3); // yep
			person.getStats().setSkillLevel(Skills.PLANETARY_OPERATIONS, 3);
			person.getStats().setSkillLevel(Skills.INDUSTRIAL_PLANNING, 3);
			person.getStats().setSkillLevel("bbplus_breaker_ops", 3);
            person.getStats().setSkillLevel("bbplus_breaker_shield_systems", 3);
            person.getStats().setSkillLevel("bbplus_breaker_tenacity", 4);
            person.getStats().setSkillLevel(Skills.HELMSMANSHIP, 3);
            person.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 3);
            person.getStats().setSkillLevel(Skills.SHIELD_MODULATION, 3);
            person.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 3);
            person.getStats().setSkillLevel(Skills.SYSTEMS_EXPERTISE, 3);                        
            person.getStats().setSkillLevel(Skills.ENERGY_WEAPON_MASTERY, 2);
            person.getStats().setSkillLevel(Skills.GUNNERY_IMPLANTS, 3);
            person.getStats().setLevel(15);
            person.setPersonality(Personalities.STEADY);
                        
			market.setAdmin(person);
			market.getCommDirectory().addPerson(person, 0);
			market.addPerson(person);
			ip.addPerson(person);
		}            
                
	}        
        
	public static void createMiscCharacters() {
		final ImportantPeopleAPI ip = Global.getSector().getImportantPeople();
		MarketAPI market = null;
                
        // The shitposter NPC
        market =  Global.getSector().getEconomy().getMarket("deserter_starkeep");
		if (market != null) {
			PersonAPI person = Global.getFactory().createPerson();
			person.setId(SEVUS);
			person.setFaction("the_deserter_ex");
			person.setGender(Gender.MALE);
			person.setRankId("bbplus_vice_commander");
			person.setPostId("bbplus_vice_commander");
			person.setImportance(PersonImportance.HIGH);
			person.getName().setFirst("Sevus");
			person.getName().setLast("Harksten");
			person.addTag(Tags.CONTACT_MILITARY);
			person.setVoice(Voices.OFFICIAL);
			person.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sevus"));
			person.getStats().setSkillLevel("bbplus_breaker_ops", 3);
            person.getStats().setSkillLevel("bbplus_breaker_tenacity", 4);                        
			person.getStats().setSkillLevel(Skills.PHASE_MASTERY, 2); // He's the OG pilot of Bladestalker
            person.getStats().setSkillLevel(Skills.PHASE_CORPS, 1);
			person.getStats().setSkillLevel(Skills.GUNNERY_IMPLANTS, 3);
            person.getStats().setSkillLevel(Skills.HELMSMANSHIP, 3);
            person.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 3);
            person.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 3);
            person.getStats().setSkillLevel(Skills.SYSTEMS_EXPERTISE, 3);
            person.getStats().setLevel(11);
            person.setPersonality(Personalities.AGGRESSIVE);
                        
			market.getCommDirectory().addPerson(person, 1);
			market.addPerson(person);
			ip.addPerson(person);
		}      
                
        // Grouchy researcher gf
        market =  Global.getSector().getEconomy().getMarket("deserter_starkeep");
		if (market != null) {
			PersonAPI person = Global.getFactory().createPerson();
			person.setId(GEMIE);
			person.setFaction("the_deserter_ex");
			person.setGender(Gender.FEMALE);
			person.setRankId("bbplus_chief_researcher");
			person.setPostId("bbplus_chief_researcher");
			person.setImportance(PersonImportance.HIGH);
			person.getName().setFirst("Gemie");
			person.getName().setLast("");
			person.setPortraitSprite(Global.getSettings().getSpriteName("characters", "gemie"));
            person.getStats().setSkillLevel("bbplus_breaker_ops", 2);
            person.getStats().setSkillLevel("bbplus_breaker_shield_systems", 3);
            person.getStats().setSkillLevel("bbplus_breaker_tenacity", 4);
            person.getStats().setSkillLevel(Skills.ELECTRONIC_WARFARE, 2);
            person.getStats().setSkillLevel(Skills.ENERGY_WEAPON_MASTERY, 2);
            person.getStats().setSkillLevel(Skills.GUNNERY_IMPLANTS, 3);                        
            person.getStats().setLevel(6);
            person.setPersonality(Personalities.STEADY);

			market.getCommDirectory().addPerson(person, 2);
			market.addPerson(person);
			ip.addPerson(person);
		}               
                
        // Assigned station officer
        market =  Global.getSector().getEconomy().getMarket("deserter_starkeep");
		if (market != null) {
			PersonAPI person = Global.getFactory().createPerson();
			person.setId(BAROLT);
			person.setFaction("the_deserter_ex");
			person.setGender(Gender.MALE);
			person.setRankId(Ranks.SPACE_CAPTAIN);
			person.setPostId(Ranks.POST_STATION_COMMANDER);
			person.addTag(Tags.CONTACT_TRADE);
			person.setVoice(Voices.SOLDIER);                        
			person.setImportance(PersonImportance.MEDIUM);
			person.getName().setFirst("Barolt");
			person.getName().setLast("Arkland");
			person.setPortraitSprite(Global.getSettings().getSpriteName("characters", "barolt"));
			
			market.getCommDirectory().addPerson(person, 3);
			market.addPerson(person);
			ip.addPerson(person);
		}                   
                
        // Special super soldier as hireable mercenary
        market =  Global.getSector().getEconomy().getMarket("deserter_starkeep");
		if (market != null) {
			PersonAPI person = Global.getFactory().createPerson();
			person.setId(ROLAND);
			person.setFaction("the_deserter_ex");
			person.setGender(Gender.MALE);
			person.setRankId(Ranks.GROUND_PRIVATE);
			person.setPostId(Ranks.GROUND_PRIVATE);
			person.setVoice(Voices.SOLDIER);                        
			person.setImportance(PersonImportance.LOW);
			person.getName().setFirst("Roland");
			person.getName().setLast("Thermidor");
			person.setPortraitSprite(Global.getSettings().getSpriteName("characters", "roland"));
			person.getStats().setSkillLevel("bbplus_breaker_ops", 3);
            person.getStats().setSkillLevel("bbplus_breaker_shield_systems", 3);
            person.getStats().setSkillLevel("bbplus_breaker_tenacity", 4);
            person.getStats().setSkillLevel(Skills.HELMSMANSHIP, 3);
            person.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 3);
            person.getStats().setSkillLevel(Skills.SHIELD_MODULATION, 3);
            person.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 3);
            person.getStats().setSkillLevel(Skills.SYSTEMS_EXPERTISE, 3);                        
            //person.getStats().setSkillLevel(Skills.ENERGY_WEAPON_MASTERY, 3);
            //person.getStats().setSkillLevel(Skills.GUNNERY_IMPLANTS, 3);
            person.getStats().setLevel(10);
            person.setPersonality(Personalities.AGGRESSIVE);
                        
			market.getCommDirectory().addPerson(person, 4);
                        market.getCommDirectory().getEntryForPerson(person).setHidden(true);
			market.addPerson(person);
			ip.addPerson(person);
		}                 

            // Mercs for fluff    
                market =  Global.getSector().getEconomy().getMarket("deserter_starkeep");
		if (market != null) {
			PersonAPI person = Global.getFactory().createPerson();
			person.setId(ASELIA);
			person.setFaction("the_deserter_ex");
			person.setGender(Gender.FEMALE);
			person.setRankId("bbplus_merc_leader");
			person.setPostId("bbplus_merc_leader");
			person.setImportance(PersonImportance.MEDIUM);
			person.getName().setFirst("Aselia");
			person.getName().setLast("Griffith");
			person.setPortraitSprite(Global.getSettings().getSpriteName("characters", "aselia"));
                        //person.getStats().setSkillLevel(Skills.WOLFPACK_TACTICS, 2);
			//person.getStats().setSkillLevel(Skills.GUNNERY_IMPLANTS, 2);
			//person.getStats().setSkillLevel(Skills.INDUSTRIAL_PLANNING, 3);
			
			market.getCommDirectory().addPerson(person);
			market.getCommDirectory().getEntryForPerson(person).setHidden(true);
			market.addPerson(person);
			ip.addPerson(person);
		}
                
                market =  Global.getSector().getEconomy().getMarket("deserter_starkeep");
		if (market != null) {
			PersonAPI person = Global.getFactory().createPerson();
			person.setId(RIEN);
			person.setFaction("the_deserter_ex");
			person.setGender(Gender.FEMALE);
			person.setRankId("bbplus_merc_member");
			person.setPostId("bbplus_merc_member");
			person.setImportance(PersonImportance.MEDIUM);
			person.getName().setFirst("Rien");
			person.getName().setLast("Daimus");
			person.setPortraitSprite(Global.getSettings().getSpriteName("characters", "rien"));
			
			market.getCommDirectory().addPerson(person);
			market.getCommDirectory().getEntryForPerson(person).setHidden(true);
			market.addPerson(person);
			ip.addPerson(person);
		}                   

                market =  Global.getSector().getEconomy().getMarket("deserter_starkeep");
		if (market != null) {
			PersonAPI person = Global.getFactory().createPerson();
			person.setId(LEONHARD);
			person.setFaction("the_deserter_ex");
			person.setGender(Gender.MALE);
			person.setRankId("bbplus_merc_member");
			person.setPostId("bbplus_merc_member");
			person.setImportance(PersonImportance.MEDIUM);
			person.getName().setFirst("Leonhard");
			person.getName().setLast("Windsor");
			person.setPortraitSprite(Global.getSettings().getSpriteName("characters", "leonhard"));
			
			market.getCommDirectory().addPerson(person);
			market.getCommDirectory().getEntryForPerson(person).setHidden(true);
			market.addPerson(person);
			ip.addPerson(person);
		}

                // A clone of Gemie!? w0w!!!
                market =  Global.getSector().getEconomy().getMarket("deserter_starkeep");
		if (market != null) {
			PersonAPI person = Global.getFactory().createPerson();
			person.setId(DUMMYONE);
			person.setFaction("the_deserter_ex");
			person.setGender(Gender.FEMALE);
			person.setRankId("");
			person.setPostId("");
			person.getName().setFirst("Gemie");
			person.getName().setLast("");
			person.setPortraitSprite(Global.getSettings().getSpriteName("characters", "dummygemie"));
			
			market.getCommDirectory().addPerson(person);
			market.getCommDirectory().getEntryForPerson(person).setHidden(true);
			market.addPerson(person);
			ip.addPerson(person);
		} 
                
        }
	
}