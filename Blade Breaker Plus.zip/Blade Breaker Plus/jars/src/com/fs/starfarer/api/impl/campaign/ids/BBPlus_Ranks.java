package com.fs.starfarer.api.impl.campaign.ids;

public class BBPlus_Ranks extends Ranks {
	
	public static final String CHIEF_RESEARCHER = "bbplus_chief_researcher";
        public static final String SEPHIRA_RESEARCHER = "bbplus_sephira_researcher";
	//public static String POST_ = "";
	
}



