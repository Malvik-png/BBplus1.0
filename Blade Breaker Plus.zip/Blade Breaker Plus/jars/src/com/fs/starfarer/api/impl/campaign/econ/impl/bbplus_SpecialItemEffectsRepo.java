package com.fs.starfarer.api.impl.campaign.econ.impl;

import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.InstallableIndustryItemPlugin;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.impl.campaign.ids.Strings;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import java.util.HashMap;
import java.util.Map;
import com.fs.starfarer.api.impl.campaign.ids.BBPlus_Items;
/**
 * A shitty way to implement custom shit
 * @author Mayu
 */
public class bbplus_SpecialItemEffectsRepo {
    //public static String ORBITALSTATION = "bbplus_Conditions.ORBITALSTATION";
    public static final int DISCHARGE_ABSORBER_PROD_BONUS = 2;	
    public static final int BIO_PRINTER_PROD_BONUS = 1;
    public static final float DEUTERION_ISOMETER_FLEET_BONUS = 1.35f;
    public static final float SYNERGIST_CLUSTER_POINT_DEFENSE_BONUS = 1.50f;
    //public static String POLLUTION_ID = Conditions.POLLUTION;
    public static void addItemEffectsToVanillaRepo() {
        ItemEffectsRepo.ITEM_EFFECTS.putAll(ITEM_EFFECTS);
    }
    
    public static final Map<String, InstallableItemEffect> ITEM_EFFECTS = new HashMap<String, InstallableItemEffect>() {{

        put(BBPlus_Items.DISCHARGE_ABSORBER, new BaseInstallableItemEffect(BBPlus_Items.DISCHARGE_ABSORBER) {
                    
            @Override
            public void apply(final Industry industry) {
                industry.supply(id + "_0", Commodities.FUEL, DISCHARGE_ABSORBER_PROD_BONUS, Misc.ucFirst(spec.getName().toLowerCase()));
            }

            @Override
            public void unapply(final Industry industry) {
                industry.getSupply(Commodities.FUEL).getQuantity().unmodifyFlat(id + "_0");
            }   
                             
            @Override
            protected void addItemDescriptionImpl(final Industry industry, final TooltipMakerAPI text, final SpecialItemData data, final InstallableIndustryItemPlugin.InstallableItemDescriptionMode mode, final String pre, final float pad) {
                             //if(industry == null){
                text.addPara(pre + "Increases Deserters HQ fuel production by %s units.",
                                pad, Misc.getHighlightColor(), 
                                "" + (int) DISCHARGE_ABSORBER_PROD_BONUS );
                              // }
        }});

        put(BBPlus_Items.BIO_PRINTER, new BaseInstallableItemEffect(BBPlus_Items.BIO_PRINTER) {
                    
            @Override
            public void apply(final Industry industry) {
                industry.supply(id + "_0", Commodities.FOOD, BIO_PRINTER_PROD_BONUS, Misc.ucFirst(spec.getName().toLowerCase()));
                industry.supply(id + "_0", Commodities.ORGANS, BIO_PRINTER_PROD_BONUS, Misc.ucFirst(spec.getName().toLowerCase()));
            }

            @Override
            public void unapply(final Industry industry) {
                industry.getSupply(Commodities.FOOD).getQuantity().unmodifyFlat(id + "_0");
                industry.getSupply(Commodities.ORGANS).getQuantity().unmodifyFlat(id + "_0");
            }   
                    
            @Override
            protected void addItemDescriptionImpl(final Industry industry, final TooltipMakerAPI text, final SpecialItemData data, final InstallableIndustryItemPlugin.InstallableItemDescriptionMode mode, final String pre, final float pad) {
                    text.addPara(pre + "Increases Bio Fabricator Complex production by %s unit(s).",
                                    pad, Misc.getHighlightColor(), 
                                    "" + (int) BIO_PRINTER_PROD_BONUS );
        }});
        /////// Custom Colony Items that is obtainable         
        put(BBPlus_Items.DEUTERION_ISOMETER, new BaseInstallableItemEffect(BBPlus_Items.DEUTERION_ISOMETER) {
                    
            @Override
            public void apply(final Industry industry) {
                industry.getMarket().getStats().getDynamic().getMod(Stats.COMBAT_FLEET_SIZE_MULT).modifyMult(spec.getId(), DEUTERION_ISOMETER_FLEET_BONUS, Misc.ucFirst(spec.getName().toLowerCase()));
            }

            @Override
            public void unapply(final Industry industry) {
                industry.getMarket().getStats().getDynamic().getMod(Stats.COMBAT_FLEET_SIZE_MULT).unmodifyMult(spec.getId());
            }   
                    
            @Override
            protected void addItemDescriptionImpl(final Industry industry, final TooltipMakerAPI text, final SpecialItemData data, final InstallableIndustryItemPlugin.InstallableItemDescriptionMode mode, final String pre, final float pad) {
                text.addPara(pre + "Increases size of fleets launched by colony: %s.",
                                pad, Misc.getHighlightColor(), 
                                Strings.X + DEUTERION_ISOMETER_FLEET_BONUS);
        }});

        put(BBPlus_Items.SYNERGIST_CLUSTER_POINT, new BaseInstallableItemEffect(BBPlus_Items.SYNERGIST_CLUSTER_POINT) {
                    
            @Override
            public void apply(final Industry industry) {
                //MarketConditionSpecAPI mc = Global.getSettings().getMarketConditionSpec("");
                //MarketAPI market = industry.getMarket();
                //Industry planetaryshield = industry;
                //industry.getMarket().addCondition(POLLUTION_ID);
                industry.getMarket().getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).modifyMult(spec.getId(), SYNERGIST_CLUSTER_POINT_DEFENSE_BONUS, Misc.ucFirst(spec.getName().toLowerCase()));
            }

            @Override
            public void unapply(final Industry industry) {
                industry.getMarket().getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).unmodifyMult(spec.getId());
            }   
                    
            @Override
            protected void addItemDescriptionImpl(final Industry industry, final TooltipMakerAPI text, final SpecialItemData data, final InstallableIndustryItemPlugin.InstallableItemDescriptionMode mode, final String pre, final float pad) {
                text.addPara(pre + "Increases ground defenses by %s.",
                                pad, Misc.getHighlightColor(), 
                                Strings.X + SYNERGIST_CLUSTER_POINT_DEFENSE_BONUS);
        }});        
    }};

}