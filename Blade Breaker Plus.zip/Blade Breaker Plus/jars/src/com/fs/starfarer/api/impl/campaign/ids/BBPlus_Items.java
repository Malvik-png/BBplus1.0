package com.fs.starfarer.api.impl.campaign.ids;

//import com.fs.starfarer.api.impl.campaign.ids.Items;

public class BBPlus_Items extends Items {
    // Unique colony items for lore building
    // But why...
    // Because autism
    public static final String DISCHARGE_ABSORBER = "bbplus_discharge_absorber";
    public static final String BIO_PRINTER = "bbplus_bio_printer";
    // Colony items for the pl*yers
    public static final String DEUTERION_ISOMETER = "bbplus_deuterion_isometer";
    // Below will be obtainable from an NPC and it will be a one-off
    public static final String SYNERGIST_CLUSTER_POINT = "bbplus_synergy_cluster";
    
}