package com.fs.starfarer.api.impl.campaign.rulecmd;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.util.Misc.Token;
import java.util.List;
import java.util.Map;
/**
 *
 * @author Mayu
 */
public class BBPlusHasShip extends BaseCommandPlugin {

    @Override
    public boolean execute(final String ruleId, final InteractionDialogAPI dialog, final List<Token> params, final Map<String, MemoryAPI> memoryMap) {
	if (dialog == null) {
            return false;
	}
		
        final String id = params.get(0).getString(memoryMap);

	for (final FleetMemberAPI member : Global.getSector().getPlayerFleet().getFleetData().getMembersListCopy()) {
            if (member.getHullSpec().getHullId().equals(id)) return true;
	}
        //getBaseHullId()
	return false;
    }

}
