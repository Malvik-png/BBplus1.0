package data.campaign.ids;

public class bbplus_Industries {
    // NPC only industries
    public static final String FOODPROCESS = "bbplus_food_processor";
    public static final String DESERTERHQ = "bbplus_deserter_hq";
    // Player available industries
    public static final String DESERTEROUTPOST = "bbplus_deserter_outpost";
    //public static final String NU_SIGMA_SHIELD = "bbplus_nu_sigma_shield";
}