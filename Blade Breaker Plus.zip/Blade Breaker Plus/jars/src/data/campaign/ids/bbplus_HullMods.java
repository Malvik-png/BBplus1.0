package data.campaign.ids;

public class bbplus_HullMods {
    // SNRI Labs fuckery
    public static final String SNRI_CARRIER_COMMAND = "bbplus_snri_carrier_command";
    public static final String SNRI_STRIKE_COMMAND = "bbplus_snri_strike_command";
    public static final String SNRI_WING_COMMAND = "bbplus_snri_wing_command";
    public static final String BBPLUS_TAG_SNRI_PACKAGE = "bbplus_snri_package";
    // Specialized Logistic Hullmods
    public static final String BBD_SPECIALIZED_LOGISTICS = "bbplus_bbdlogistics";
    public static final String BBD_CARGO = "bbplus_additionalcargoholds";
    public static final String BBD_FUEL = "bbplus_extrafueltanks";
    public static final String BBD_CREW = "bbplus_expandedcrewquarters";
    public static final String BBD_SALVAGE = "bbplus_utilitydrones";

}
