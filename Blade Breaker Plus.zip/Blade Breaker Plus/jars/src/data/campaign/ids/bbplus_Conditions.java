package data.campaign.ids;

public class bbplus_Conditions {
    
    public static final String ORBITALSTATION = "bbplus_orbital_station";
    public static final String CLOSEDDOOR = "bbplus_closed_door";
    public static final String DIMENSIONAL_TURBULENCE = "bbplus_spatial_turbulence";
    public static final String CRACKED_PLANET = "bbplus_cracked_planet";

}