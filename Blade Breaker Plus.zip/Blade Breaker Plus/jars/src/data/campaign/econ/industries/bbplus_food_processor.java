package data.campaign.econ.industries;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.impl.campaign.econ.impl.BaseIndustry;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Pair;
/**
 * MC DICKS OF CLONED LIVERS AND SHITTY CALORIE BARS
 * @author Mayu
 */
public class bbplus_food_processor extends BaseIndustry {
    // their special food production industry, ligma calorie bars anyone?
    // for the record, I might actually add the calorie bar as a special commodity but what does that achieve?
    // nevermind lol
    @Override
    public boolean isHidden() {
        return !market.getFactionId().equals("the_deserter_ex");
    }
	
    @Override
    public boolean isFunctional() {
        return market.getFactionId().equals("the_deserter_ex");
    }

    @Override
    public boolean isAvailableToBuild() {
        return market.getFactionId().equals("the_deserter_ex");
    }
	
    @Override
    public boolean showWhenUnavailable() {
        return false;
    }	

    @Override
    public void apply() {
        super.apply(true);
        final int size = market.getSize();
        demand(Commodities.HEAVY_MACHINERY, size +0); // -1
        ////////////
        supply(Commodities.FOOD, size -1);
        supply(Commodities.ORGANS, size);
        //supply(BBPlus_Items.TYPE5_RATION, size -1); Space Calorie Bar lol       
        final Pair<String, Integer> deficit = getMaxDeficit(Commodities.HEAVY_MACHINERY);
        //applyDeficitToProduction(0, deficit, Commodities.FOOD, Commodities.ORGANICS);
        applyDeficitToProduction(1, deficit, Commodities.FOOD, Commodities.ORGANS);	
        if (!isFunctional()) {
            supply.clear();
        }
    }
	
    @Override
    public void unapply() {
        super.unapply();
    }

    @Override
    public String getCurrentImage() {
        if (getSpecialItem() != null) {
            return Global.getSettings().getSpriteName("industry", "advanced_bio_complex");
        }
        return super.getCurrentImage();
    }         
        
    @Override
    protected boolean hasPostDemandSection(final boolean hasDemand, final IndustryTooltipMode mode) {
         return mode != IndustryTooltipMode.NORMAL || isFunctional();
    }

    @Override
    public void createTooltip(final IndustryTooltipMode mode, final TooltipMakerAPI tooltip, final boolean expanded) {
        super.createTooltip(mode, tooltip, expanded);	
    }
	  
    @Override
    protected boolean canImproveToIncreaseProduction() {
        return true;
    } 
      
}