package data.campaign.econ.industries;

import java.awt.Color;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.econ.CommoditySpecAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.MarketCMD.RaidDangerLevel;
import com.fs.starfarer.api.impl.campaign.econ.impl.BaseIndustry;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Industries;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.impl.campaign.ids.Strings;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
/**
 *
 * @author Mayu
 */
public class bbplus_deserter_hq extends BaseIndustry {
    // I don't need them producing fleets in their system, it does defeat the purpose of making them hidden
    @Override
    public boolean isHidden() {
        return !market.getFactionId().equals("the_deserter_ex");
    }
	
    @Override
    public boolean isFunctional() {
        return market.getFactionId().equals("the_deserter_ex");
    }

    @Override
    public boolean isAvailableToBuild() {
        return market.getFactionId().equals("the_deserter_ex");
    }
	
    @Override
    public boolean showWhenUnavailable() {
        return false;
    }

    public static final float DEFENSE_BONUS_PATROL = 0.1f;
    public static final float DEFENSE_BONUS_MILITARY = 2.2f; //2
    public static final float DEFENSE_BONUS_COMMAND = 1.8f;
    public static final float ALPHA_CORE_BONUS = 0.35f;
    public static float IMPROVE_DEFENSE_BONUS;
    static {
        bbplus_deserter_hq.IMPROVE_DEFENSE_BONUS = 1.30f;
    } 

    @Override
    public void apply() {
        super.apply(true);
        final int size = market.getSize();
        final boolean patrol = getSpec().hasTag(Industries.TAG_PATROL);
        final boolean militaryBase = getSpec().hasTag(Industries.TAG_MILITARY);
        final boolean command = getSpec().hasTag(Industries.TAG_COMMAND);        
        super.apply(!patrol);
        if (patrol) {
            applyIncomeAndUpkeep(3);
        }		
        final int extraDemand = 0;	
        demand(Commodities.SUPPLIES, size - 2 + extraDemand);
        //demand(Commodities.SHIPS, size - 1 + extraDemand);	
        supply(Commodities.CREW, size -1);
        supply(Commodities.FUEL, size -2);
        if (!patrol) {
            //demand(Commodities.HAND_WEAPONS, size);
            supply(Commodities.MARINES, size -1);			
            //Pair<String, Integer> deficit = getMaxDeficit(Commodities.HAND_WEAPONS);
            //applyDeficitToProduction(1, deficit, Commodities.MARINES);
        }
        modifyStabilityWithBaseMod();
        final float mult = getDeficitMult(Commodities.SUPPLIES);
        String extra = "";
        if (mult != 1) {
            String com = getMaxDeficit(Commodities.SUPPLIES).one;
            extra = " (" + getDeficitText(com).toLowerCase() + ")";
        }
        float bonus = DEFENSE_BONUS_MILITARY;
        if (patrol) bonus = DEFENSE_BONUS_PATROL;
        else if (command) bonus = DEFENSE_BONUS_COMMAND;
        market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).modifyMult(getModId(), 1f + bonus * mult, getNameForModifier() + extra);	
        //String extra = "";
        //float mult = 3;
        market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).modifyMult(getModId(), 1f + bonus * mult, "BB Deserters HQ" + extra);
        final MemoryAPI memory = market.getMemoryWithoutUpdate();
        if (militaryBase || command) {
            Misc.setFlagWithReason(memory, MemFlags.MARKET_MILITARY, getModId(), true, -1);
        }
        if (!isFunctional()) {
            supply.clear();
            unapply();
        }
    }

    @Override
    public void unapply() {
        super.unapply();
        unmodifyStabilityWithBaseMod();
        market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).unmodifyMult(getModId());
    }
	
    @Override
    protected boolean hasPostDemandSection(final boolean hasDemand, final IndustryTooltipMode mode) {
        return mode != IndustryTooltipMode.NORMAL || isFunctional();
    }
	
    @Override
    protected void addPostDemandSection(final TooltipMakerAPI tooltip, final boolean hasDemand, final IndustryTooltipMode mode) {
        if (mode != IndustryTooltipMode.NORMAL || isFunctional()) {
            addStabilityPostDemandSection(tooltip, hasDemand, mode);
            final boolean patrol = getSpec().hasTag(Industries.TAG_PATROL);
            final boolean command = getSpec().hasTag(Industries.TAG_COMMAND);
            float bonus = DEFENSE_BONUS_MILITARY;
            if (patrol) bonus = DEFENSE_BONUS_PATROL;
            if (command) bonus = DEFENSE_BONUS_COMMAND;
            addGroundDefensesImpactSection(tooltip, bonus, Commodities.SUPPLIES);
        }
    }
	
    @Override
    protected int getBaseStabilityMod() {
        final boolean patrol = getSpec().hasTag(Industries.TAG_PATROL);
        final boolean militaryBase = getSpec().hasTag(Industries.TAG_MILITARY);
        final boolean command = getSpec().hasTag(Industries.TAG_COMMAND);
        int stabilityMod = 1;
        if (patrol) {
            stabilityMod = 1;
        }
        else if (militaryBase) {
            stabilityMod = 2;
        }
        else if (command) {
            stabilityMod = 2;
        }
        return stabilityMod;
    }

    @Override
    public String getCurrentImage() {
        if (getSpecialItem() != null) {
            return Global.getSettings().getSpriteName("industry", "advanced_deserter_hq");
        }
        return super.getCurrentImage();
    }        

    @Override
    public float getPatherInterest() {        
        return -420.0f; // fuck off lunatics
    }   
        
    @Override
    protected void applyAlphaCoreModifiers() {
        market.getStats().getDynamic().getMod(Stats.COMBAT_FLEET_SIZE_MULT).modifyMult(
        getModId(), 1f + ALPHA_CORE_BONUS, "Alpha core (" + getNameForModifier() + ")");
    }
	
    @Override
    protected void applyNoAICoreModifiers() {
        market.getStats().getDynamic().getMod(Stats.COMBAT_FLEET_SIZE_MULT).unmodifyMult(getModId());
    }

    @Override
    protected void applyAlphaCoreSupplyAndDemandModifiers() {
        demandReduction.modifyFlat(getModId(0), DEMAND_REDUCTION, "Alpha core");
    }
	
    @Override
    protected void addAlphaCoreDescription(final TooltipMakerAPI tooltip, final AICoreDescriptionMode mode) {
        final float opad = 10f;
        final Color highlight = Misc.getHighlightColor();
        String pre = "Alpha-level AI core currently assigned. ";
        if (mode == AICoreDescriptionMode.MANAGE_CORE_DIALOG_LIST || mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
            pre = "Alpha-level AI core. ";
        }
        final float a = ALPHA_CORE_BONUS;
        //String str = "" + (int)Math.round(a * 100f) + "%";
        String str = Strings.X + (1f + a);
        if (mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
            CommoditySpecAPI coreSpec = Global.getSettings().getCommoditySpec(aiCoreId);
            TooltipMakerAPI text = tooltip.beginImageWithText(coreSpec.getIconName(), 48);
            text.addPara(pre + "Reduces upkeep cost by %s. Reduces demand by %s unit. " +
                               "Increases fleet size by %s.", 0f, highlight,
                               "" + (int)((1f - UPKEEP_MULT) * 100f) + "%", "" + DEMAND_REDUCTION,
                               str);
            tooltip.addImageWithText(opad);
            return;
        }
        tooltip.addPara(pre + "Reduces upkeep cost by %s. Reduces demand by %s unit. " +
                              "Increases fleet size by %s.", opad, highlight,
                              "" + (int)((1f - UPKEEP_MULT) * 100f) + "%", "" + DEMAND_REDUCTION,
                              str);
    }
		
   @Override
    public boolean canImprove() {
        return true;
    }
    
   @Override
    protected void applyImproveModifiers() {
        if (this.isImproved()) {
            this.market.getStats().getDynamic().getMod("ground_defenses_mod").modifyMult("bbplus_deserter_hq_improve_bonus", bbplus_deserter_hq.IMPROVE_DEFENSE_BONUS, "Improvements (BB Deserters HQ)");
        }
        else {
            this.market.getStats().getDynamic().getMod("ground_defenses_mod").unmodifyMult("bbplus_deserter_hq_improve_bonus");
        }
    }
    
    @Override
    public void addImproveDesc(final TooltipMakerAPI info, final Industry.ImprovementDescriptionMode mode) {
        final float opad = 10.0f;
        final Color highlight = Misc.getHighlightColor();
        final float a = bbplus_deserter_hq.IMPROVE_DEFENSE_BONUS;
        final String str = "\u00d7" + a + "";
        if (mode == Industry.ImprovementDescriptionMode.INDUSTRY_TOOLTIP) {
            info.addPara("Ground defenses increased by %s.", 0.0f, highlight, new String[] { str });
        }
        else {
            info.addPara("Increases ground defenses by %s.", 0.0f, highlight, new String[] { str });
        }
        info.addSpacer(opad);
        super.addImproveDesc(info, mode);
    }   

    @Override
    public RaidDangerLevel adjustCommodityDangerLevel(final String commodityId, final RaidDangerLevel level) {
        return level.next();
    }

    @Override
    public RaidDangerLevel adjustItemDangerLevel(final String itemId, final String data, final RaidDangerLevel level) {
        return level.next();
    }
    
}