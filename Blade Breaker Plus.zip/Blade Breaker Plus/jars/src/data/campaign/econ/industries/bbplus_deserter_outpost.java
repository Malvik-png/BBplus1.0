package data.campaign.econ.industries;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.impl.campaign.econ.impl.BaseIndustry;
import com.fs.starfarer.api.impl.campaign.econ.impl.MilitaryBase;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.MarketCMD.RaidDangerLevel;
import com.fs.starfarer.api.impl.campaign.ids.Ranks;
import com.fs.starfarer.api.campaign.econ.CommoditySpecAPI;
import com.fs.starfarer.api.campaign.econ.CommodityOnMarketAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.impl.campaign.fleets.FleetParamsV3;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactoryV3;
import com.fs.starfarer.api.impl.campaign.fleets.PatrolAssignmentAIV4;
import com.fs.starfarer.api.impl.campaign.fleets.RouteManager;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactory;
import com.fs.starfarer.api.impl.campaign.ids.Industries;
import com.fs.starfarer.api.campaign.listeners.FleetEventListener;
import com.fs.starfarer.api.campaign.CampaignEventListener;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.BattleAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.campaign.RepLevel;
import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.Misc;
import java.util.Random;
import java.awt.Color;
import org.apache.log4j.Logger;
import org.lwjgl.util.vector.Vector2f;
import data.scripts.utils.BBPlus_ID;
import data.scripts.BBPlusPlugin;
/**
 *
 * @author Mayu
 */
@SuppressWarnings("FieldMayBeFinal")
public class bbplus_deserter_outpost extends BaseIndustry implements RouteManager.RouteFleetSpawner, FleetEventListener {
	
    protected IntervalUtil tracker;
    protected float returningPatrolValue;
    private static Logger log;
    public static String ID;
    public static float DEFENSE_BONUS;
    public static float IMPROVE_DEFENSE_BONUS;
    //public static final float STABILITY_BONUS = 1.0f;
    public static final float ALPHA_CORE_BONUS = 0.25f;
    public static final float ALPHA_STAB_BONUS = 1.0f;
    public static final String FACTION = BBPlus_ID.FACTION_ID;
    //private static final float ALPHA_CORE_INCOME_BONUS = 1.0f;
        
    static {
        bbplus_deserter_outpost.log = Global.getLogger((Class)BBPlusPlugin.class);
        bbplus_deserter_outpost.ID = "bbplus_deserter_outpost";
        bbplus_deserter_outpost.DEFENSE_BONUS = 150.0f;
        bbplus_deserter_outpost.IMPROVE_DEFENSE_BONUS = 1.20f;
    }
    
    public bbplus_deserter_outpost() {
        this.tracker = new IntervalUtil(Global.getSettings().getFloat("averagePatrolSpawnInterval") * 0.7f, Global.getSettings().getFloat("averagePatrolSpawnInterval") * 1.3f);
        this.returningPatrolValue = 0.0f;
    }
    
    @Override
    public boolean isHidden() {
        bbplus_deserter_outpost.log.info((Object)"isHidden");
        if (this.market.getFactionId().equals("the_deserter_ex")) {
            bbplus_deserter_outpost.log.info((Object)"false");
            return false;
        }
        bbplus_deserter_outpost.log.info((Object)"true");
        final RepLevel rep = this.market.getFaction().getRelationshipLevel("the_deserter_ex");
        return !rep.isPositive();
    }
    
    //@Override
    //public boolean isFunctional() {
    //    bbplus_deserter_outpost.log.info((Object)"isFunctional");
    //    if (this.market.getFactionId().equals("the_deserter_ex")) {
    //        bbplus_deserter_outpost.log.info((Object)"true");
   //         return true;
    //    }
    //    final RepLevel rep = this.market.getFaction().getRelationshipLevel("the_deserter_ex");
    //    bbplus_deserter_outpost.log.info((Object)("check rep " + rep.isPositive()));
    //    return rep.isPositive();
   // }
    
    @Override
    public void apply() {
        super.apply(true);
        final int size = this.market.getSize();
        //this.demand("domestic_goods", size / 2 + 1);
        this.demand("supplies", size / 2 + 1);
        this.demand("fuel", size / 2 + 1);
        this.demand("ships", size / 2 + 1);
        //market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).modifyFlat(bbplus_deserter_outpost.ID, DEFENSE_BONUS, getNameForModifier());
        //this.modifyStabilityWithBaseMod();
        final MemoryAPI memory = this.market.getMemoryWithoutUpdate();
        Misc.setFlagWithReason(memory, "$patrol", this.getModId(), true, -1.0f);
        if (!this.isFunctional()) {            
            this.demand.clear();
            this.supply.clear();
            this.market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).unmodifyFlat(bbplus_deserter_outpost.ID);
            this.unapply();           
            this.market.getStability().unmodifyFlat(bbplus_deserter_outpost.ID);
            ////////this.market.getStability().modifyFlat(getModId(), STABILITY_BONUS, "Deserters Outpost" );
        }
        else {
            //this.market.getStability().modifyFlat(bbplus_deserter_outpost.ID, STABILITY_BONUS, this.getNameForModifier());
            this.market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).modifyFlat(bbplus_deserter_outpost.ID, DEFENSE_BONUS, getNameForModifier());
        }
    }
    
    @Override
    public void unapply() {
        super.unapply();
        final MemoryAPI memory = this.market.getMemoryWithoutUpdate();
        Misc.setFlagWithReason(memory, "$patrol", this.getModId(), false, -1.0f);
        this.market.getStability().unmodifyFlat(getModId());
        this.market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).unmodifyFlat(bbplus_deserter_outpost.ID);
    }
    
    @Override
    protected boolean hasPostDemandSection(final boolean hasDemand, final Industry.IndustryTooltipMode mode) {
        return mode != Industry.IndustryTooltipMode.NORMAL || this.isFunctional();
    }
    
    @Override
    protected void addPostDemandSection(final TooltipMakerAPI tooltip, final boolean hasDemand, final Industry.IndustryTooltipMode mode) {
        if (mode != Industry.IndustryTooltipMode.NORMAL || this.isFunctional()) {
            final float opad = 10f;
            final Color h = Misc.getHighlightColor();
            //Misc.getPositiveHighlightColor()
            tooltip.addPara("Pather interest: %s", opad, h, "-15" );
            tooltip.addPara("Ground defense strength: %s", opad, h, new String[] { "+150" });
            //tooltip.addPara("Stability bonus: %s", opad, h, new String[] { "+1" });
            this.addCustomDescriptions(tooltip, mode);
        }
    }

    //@Override
    //protected int getBaseStabilityMod() {
    //    return 1;
    //}

    @Override
    public String getNameForModifier() {
        if (this.getSpec().getName().contains("HQ")) {
            return this.getSpec().getName();
        }
        return Misc.ucFirst(this.getSpec().getName());
    }
    
    protected void addCustomDescriptions(final TooltipMakerAPI tooltip, final Industry.IndustryTooltipMode mode) {
        final Color deserters = new Color(105,105,120,255);
        tooltip.addPara("Adds a %s patrol around this colony.", 10.0f, deserters, new String[] { "Blade Breaker Deserters" });
    }

    //@Override
    //protected Pair<String, Integer> getStabilityAffectingDeficit() {
    //    return (Pair<String, Integer>)this.getMaxDeficit(new String[] { "supplies", "fuel", "ships" });
    //}

    @Override
    public boolean isDemandLegal(final CommodityOnMarketAPI com) {
        return true;
    }
    
    @Override
    public boolean isSupplyLegal(final CommodityOnMarketAPI com) {
        return true;
    }
    
    @Override
    protected void buildingFinished() {
        super.buildingFinished();
        this.tracker.forceIntervalElapsed();
    }
    
    @Override
    protected void upgradeFinished(final Industry previous) {
        super.upgradeFinished(previous);
        this.tracker.forceIntervalElapsed();
    }
    
    @Override
    public void advance(final float amount) {
        super.advance(amount);
        if (Global.getSector().getEconomy().isSimMode()) {
            return;
        }
        if (!this.isFunctional()) {
            return;
        }
        final float days = Global.getSector().getClock().convertToDays(amount);
        float spawnRate = 1.0f;
        final float rateMult = this.market.getStats().getDynamic().getStat("combat_fleet_spawn_rate_mult").getModifiedValue();
        spawnRate *= rateMult;
        float extraTime = 0.0f;
        if (this.returningPatrolValue > 0.0f) {
            final float interval = this.tracker.getIntervalDuration();
            extraTime = interval * days;
            this.returningPatrolValue -= days;
            if (this.returningPatrolValue < 0.0f) {
                this.returningPatrolValue = 0.0f;
            }
        }
        this.tracker.advance(days * spawnRate + extraTime);
        if (this.tracker.intervalElapsed()) {
            final String sid = this.getRouteSourceId();
            final int light = this.getCount(FleetFactory.PatrolType.FAST);
            final int medium = this.getCount(FleetFactory.PatrolType.COMBAT);
            final int heavy = this.getCount(FleetFactory.PatrolType.HEAVY);
            final int maxLight = 2;
            final int maxMedium = 1;
            final int maxHeavy = 1; // To justify its upkeep
            final WeightedRandomPicker<FleetFactory.PatrolType> picker = (WeightedRandomPicker<FleetFactory.PatrolType>)new WeightedRandomPicker();
            picker.add((FleetFactory.PatrolType)(Object)FleetFactory.PatrolType.HEAVY, (float)(maxHeavy - heavy));
            picker.add((FleetFactory.PatrolType)(Object)FleetFactory.PatrolType.COMBAT, (float)(maxMedium - medium));
            picker.add((FleetFactory.PatrolType)(Object)FleetFactory.PatrolType.FAST, (float)(maxLight - light));
            if (picker.isEmpty()) {
                return;
            }
            final FleetFactory.PatrolType type = (FleetFactory.PatrolType)picker.pick();
            final MilitaryBase.PatrolFleetData custom = new MilitaryBase.PatrolFleetData(type);
            final RouteManager.OptionalFleetData extra = new RouteManager.OptionalFleetData(this.market);
            extra.fleetType = type.getFleetType();
            //Long.valueOf(Misc.genRandomSeed())
            final RouteManager.RouteData route = RouteManager.getInstance().addRoute(sid, this.market, Misc.genRandomSeed(), extra, (RouteManager.RouteFleetSpawner)this, (Object)custom);
            final float patrolDays = 35.0f + (float)Math.random() * 10.0f;
            route.addSegment(new RouteManager.RouteSegment(patrolDays, this.market.getPrimaryEntity()));
        }
    }
    
    @Override
    public void reportAboutToBeDespawnedByRouteManager(final RouteManager.RouteData route) {
    }
    
    @Override
    public boolean shouldRepeat(final RouteManager.RouteData route) {
        return false;
    }
    
    public int getCount(final FleetFactory.PatrolType... types) {
        int count = 0;
        for (final RouteManager.RouteData data : RouteManager.getInstance().getRoutesForSource(this.getRouteSourceId())) {
            if (data.getCustom() instanceof MilitaryBase.PatrolFleetData) {
                final MilitaryBase.PatrolFleetData custom = (MilitaryBase.PatrolFleetData)data.getCustom();
                for (final FleetFactory.PatrolType type : types) {
                    if (type == custom.type) {
                        ++count;
                        break;
                    }
                }
            }
        }
        return count;
    }
    
    public int getMaxPatrols(final FleetFactory.PatrolType type) {
        if (type == FleetFactory.PatrolType.FAST) {
            return (int)this.market.getStats().getDynamic().getMod("patrol_num_light_mod").computeEffective(0.0f);
        }
        if (type == FleetFactory.PatrolType.COMBAT) {
            return (int)this.market.getStats().getDynamic().getMod("patrol_num_medium_mod").computeEffective(0.0f);
        }
        if (type == FleetFactory.PatrolType.HEAVY) {
            return (int)this.market.getStats().getDynamic().getMod("patrol_num_heavy_mod").computeEffective(0.0f);
        }
        return 0;
    }
    
    @Override
    public boolean shouldCancelRouteAfterDelayCheck(final RouteManager.RouteData route) {
        return false;
    }
    
    @Override
    public void reportBattleOccurred(final CampaignFleetAPI fleet, final CampaignFleetAPI primaryWinner, final BattleAPI battle) {
        //
    }
    
    @Override
    public void reportFleetDespawnedToListener(final CampaignFleetAPI fleet, final CampaignEventListener.FleetDespawnReason reason, final Object param) {
        if (!this.isFunctional()) {
            return;
        }
        if (reason == CampaignEventListener.FleetDespawnReason.REACHED_DESTINATION) {
            final RouteManager.RouteData route = RouteManager.getInstance().getRoute(this.getRouteSourceId(), fleet);
            if (route.getCustom() instanceof MilitaryBase.PatrolFleetData) {
                final MilitaryBase.PatrolFleetData custom = (MilitaryBase.PatrolFleetData)route.getCustom();
                if (custom.spawnFP > 0) {
                    final float fraction = (float)(fleet.getFleetPoints() / custom.spawnFP);
                    this.returningPatrolValue += fraction;
                }
            }
        }
    }
    
    @Override
    public CampaignFleetAPI spawnFleet(final RouteManager.RouteData route) {
        if (!this.isFunctional()) {
            return null;
        }
        final MilitaryBase.PatrolFleetData custom = (MilitaryBase.PatrolFleetData)route.getCustom();
        final FleetFactory.PatrolType type = custom.type;
        final Random random = route.getRandom();
        float combat = 0.0f;
        float tanker = 0.0f;
        float freighter = 0.0f;
        final String fleetType = type.getFleetType();
        switch (type) {
            case FAST: {
                combat = Math.round(3.0f + random.nextFloat() * 2.0f) * 5.0f;
                break;
            }
            case COMBAT: {
                combat = Math.round(6.0f + random.nextFloat() * 3.0f) * 5.0f;
                tanker = Math.round(random.nextFloat()) * 5.0f;
                break;
            }
            case HEAVY: {
                combat = Math.round(10.0f + random.nextFloat() * 5.0f) * 5.0f;
                tanker = Math.round(random.nextFloat()) * 10.0f;
                freighter = Math.round(random.nextFloat()) * 10.0f;
                break;
            }
        }
        final FleetParamsV3 params = new FleetParamsV3(this.market, (Vector2f)null, "the_deserter_ex", route.getQualityOverride(), fleetType, combat, freighter, tanker, 0.0f, 0.0f, 0.0f, 0.0f);
        params.timestamp = route.getTimestamp();
        params.random = random;
        params.modeOverride = Misc.getShipPickMode(this.market);
        params.modeOverride = FactionAPI.ShipPickMode.PRIORITY_THEN_ALL;
        final CampaignFleetAPI fleet = FleetFactoryV3.createFleet(params);
        if (fleet == null || fleet.isEmpty()) {
            return null;
        }
        fleet.setFaction(this.market.getFactionId(), true);
        fleet.setNoFactionInName(true);
        fleet.addEventListener((FleetEventListener)this);
        fleet.getMemoryWithoutUpdate().set("$isPatrol", (Object)true);
        if (type == FleetFactory.PatrolType.FAST || type == FleetFactory.PatrolType.COMBAT) {
            fleet.getMemoryWithoutUpdate().set("$isCustomsInspector", (Object)true);
        }
        final String postId = Ranks.POST_PATROL_COMMANDER;
        String rankId = Ranks.SPACE_COMMANDER;
        switch (type) {
            case FAST: {
                rankId = Ranks.SPACE_LIEUTENANT;
                break;
            }
            case COMBAT: {
                rankId = Ranks.SPACE_COMMANDER;
                break;
            }
            case HEAVY: {
                rankId = Ranks.SPACE_CAPTAIN;
                break;
            }
        }
        fleet.getCommander().setPostId(postId);
        fleet.getCommander().setRankId(rankId);
        this.market.getContainingLocation().addEntity((SectorEntityToken)fleet);
        fleet.setFacing((float)Math.random() * 360.0f);
        fleet.setLocation(this.market.getPrimaryEntity().getLocation().x, this.market.getPrimaryEntity().getLocation().x);
        fleet.addScript((EveryFrameScript)new PatrolAssignmentAIV4(fleet, route));
        if (custom.spawnFP <= 0) {
            custom.spawnFP = fleet.getFleetPoints();
        }
        return fleet;
    }
    
    public String getRouteSourceId() {
        return String.valueOf(this.getMarket().getId()) + "_" + "the_deserter_ex";
    }
    
    @Override
    public boolean isAvailableToBuild() {
        boolean canBuild = false;
        for (final Industry ind : market.getIndustries()) {
            if (ind == this) continue;
            if (!ind.isFunctional()) continue;
            if (ind.getSpec().hasTag(Industries.TAG_SPACEPORT)) {
	        canBuild = true;
	        break;
            }
        }
        if (this.market.getFactionId().equals("the_deserter_ex")) {
            return true;
        }
        final RepLevel rep = this.market.getFaction().getRelationshipLevel("the_deserter_ex");
        return canBuild && rep.isPositive();
    }
    
    @Override
    public String getUnavailableReason() {
	return "Requires a functional spaceport";
    }
        
    @Override
    public boolean showWhenUnavailable() {
        return false;
    }

    @Override
    public String getCurrentImage() {
        if (getSpecialItem() != null) {
            return Global.getSettings().getSpriteName("industry", "advanced_deserter_outposts");
        }
        return super.getCurrentImage();
    }     
    
    @Override
    public float getPatherInterest() {
        if (this.isFunctional() && !this.isBuilding() && this.aiCoreId != null && this.aiCoreId.equals("alpha_core")) {
            return -45.0f;
        }            
        return -15.0f;
    }
        
    @Override
    protected void applyAlphaCoreModifiers() {
        this.market.getStability().modifyFlat(this.getModId(1), 1.0f, "Alpha core (" + this.getNameForModifier() + ")");
    }
    
    @Override
    protected void applyNoAICoreModifiers() {
        this.market.getStability().unmodifyFlat(this.getModId(1));
        //this.supplyBonus.unmodifyFlat(this.getModId(0));
        this.demandReduction.unmodifyFlat(this.getModId(0));
    }
    
    @Override
    protected void applyAlphaCoreSupplyAndDemandModifiers() {
        //this.supplyBonus.modifyFlat(this.getModId(0), (float)bbplus_deserter_outpost.SUPPLY_BONUS, "Alpha core");
        this.demandReduction.modifyFlat(this.getModId(0), (float)bbplus_deserter_outpost.DEMAND_REDUCTION, "Alpha core");
    }
    
    @Override
    protected void addAlphaCoreDescription(final TooltipMakerAPI tooltip, final Industry.AICoreDescriptionMode mode) {
        final float opad = 10.0f;
        final Color highlight = Misc.getHighlightColor();
        String pre = "Alpha-level AI core currently assigned. ";
        if (mode == Industry.AICoreDescriptionMode.MANAGE_CORE_DIALOG_LIST || mode == Industry.AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
            pre = "Alpha-level AI core. ";
        }
        //final float a = 1.0f;
        //final String str = "\u00d7" + (1.0f + a);
        if (mode == Industry.AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
            final CommoditySpecAPI coreSpec = Global.getSettings().getCommoditySpec(this.aiCoreId);
            final TooltipMakerAPI text = tooltip.beginImageWithText(coreSpec.getIconName(), 48.0f);
            text.addPara(String.valueOf(pre) + "Reduces upkeep cost by %s. Reduces demand by %s unit. " +
                                               "Increases stability by %s. " + "Reduces Pather interest by %s.", 0.0f, highlight, new String[] { (int)((1.0f - bbplus_deserter_outpost.UPKEEP_MULT) * 100.0f) + "%", Misc.getRoundedValue(1.0f) + "", new StringBuilder().append(bbplus_deserter_outpost.DEMAND_REDUCTION).toString(), "-45"});
            tooltip.addImageWithText(opad);
            return;
        }
            tooltip.addPara(String.valueOf(pre) + "Reduces upkeep cost by %s. Reduces demand by %s unit. " +
                                                  "Increases stability by %s. " + "Reduces Pather interest by %s.", 0.0f, highlight, new String[] { (int)((1.0f - bbplus_deserter_outpost.UPKEEP_MULT) * 100.0f) + "%", new StringBuilder().append(bbplus_deserter_outpost.DEMAND_REDUCTION).toString(), "1", "-45"});
    }

   @Override
    public boolean canImprove() {
        return true;
    }
    
   @Override
    protected void applyImproveModifiers() {
        if (this.isImproved()) {
            this.market.getStats().getDynamic().getMod("ground_defenses_mod").modifyMult("bbplus_deserter_outpost_improve_bonus", bbplus_deserter_outpost.IMPROVE_DEFENSE_BONUS, "Improvements (Deserters Outpost)");
        }
        else {
            this.market.getStats().getDynamic().getMod("ground_defenses_mod").unmodifyMult("bbplus_deserter_outpost_improve_bonus");
        }
    }
    
    @Override
    public void addImproveDesc(final TooltipMakerAPI info, final Industry.ImprovementDescriptionMode mode) {
        final float opad = 10.0f;
        final Color highlight = Misc.getHighlightColor();
        final float a = bbplus_deserter_outpost.IMPROVE_DEFENSE_BONUS;
        final String str = "\u00d7" + a + "";
        if (mode == Industry.ImprovementDescriptionMode.INDUSTRY_TOOLTIP) {
            info.addPara("Ground defenses increased by %s.", 0.0f, highlight, new String[] { str });
        }
        else {
            info.addPara("Increases ground defenses by %s.", 0.0f, highlight, new String[] { str });
        }
        info.addSpacer(opad);
        super.addImproveDesc(info, mode);
    }
    
    @Override
    public RaidDangerLevel adjustCommodityDangerLevel(final String commodityId, final RaidDangerLevel level) {
        return level.next();
    }

    @Override
    public RaidDangerLevel adjustItemDangerLevel(final String itemId, final String data, final RaidDangerLevel level) {
        return level.next();
    }
    
}