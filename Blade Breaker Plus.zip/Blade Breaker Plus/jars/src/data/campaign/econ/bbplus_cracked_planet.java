package data.scripts.campaign.econ;

import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.impl.campaign.ids.Industries;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.econ.BaseHazardCondition;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
/**
 *
 * @author Mayu
 */
public class bbplus_cracked_planet extends BaseHazardCondition {

    public static final int RESOURCE_REDUCTION = 2;

    @Override
    public void apply(final String id) {
        super.apply(id);
        final Industry industry = market.getIndustry(Industries.MINING);
        if(industry != null && industry.isFunctional()){
            industry.getSupply(Commodities.ORE).getQuantity().modifyFlat(id, -RESOURCE_REDUCTION);
            industry.getSupply(Commodities.RARE_ORE).getQuantity().modifyFlat(id, -RESOURCE_REDUCTION);
        }   
        
    }

    @Override
    public void unapply(final String id) {
        super.unapply(id);
    }
    
    @Override
    protected void createTooltipAfterDescription(final TooltipMakerAPI tooltip, final boolean expanded) {
        super.createTooltipAfterDescription(tooltip, expanded);
        tooltip.addPara("%s ore and transplutonic ore production (Mining)",
                10f, Misc.getHighlightColor(),
                "-" + (int) RESOURCE_REDUCTION
	); 
    }

}