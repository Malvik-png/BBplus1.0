package data.scripts.campaign.econ;

import com.fs.starfarer.api.impl.campaign.econ.BaseHazardCondition;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
/**
 *
 * @author Mayu
 */
public class bbplus_orbital_station extends BaseHazardCondition{
    
    public static final float PRODUCTION_BONUS = 0.50f; // They managed to stole a high-end manufactory when they escaped the BBs
    public static final float DEFENSE_BONUS = 1.5f;     // Armed with the array of formidable batteries
    //public static float ACCESSIBILITY_BONUS = -10f;
    @Override
    public void apply(final String id) {
    super.apply(id);
    if (this.market.getFaction() != null) {
        if (this.market.getFaction().getId().contains("the_deserter_ex")) {
            this.market.getStats().getDynamic().getMod(Stats.PRODUCTION_QUALITY_MOD).modifyFlat(id, PRODUCTION_BONUS, "Starkeep Manufactory");
            this.market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).modifyMult(id, DEFENSE_BONUS, "Starkeep Defense Array");
		//market.getAccessibilityMod().modifyFlat(id, getAccessibilityBonus()/100, "Starkeep Defense Array");
            }
        else{
            this.market.getStats().getDynamic().getMod(Stats.PRODUCTION_QUALITY_MOD).unmodify(id);
            this.market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).unmodify(id);
            }
        }
    }
	
    @Override
    public void unapply(final String id) {
    super.unapply(id);
        this.market.getStats().getDynamic().getMod(Stats.PRODUCTION_QUALITY_MOD).unmodify(id);
        this.market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).unmodify(id);
        // market.getAccessibilityMod().unmodify(id);
    }
	
    @Override
    protected void createTooltipAfterDescription(final TooltipMakerAPI tooltip, final boolean expanded) {
        super.createTooltipAfterDescription(tooltip, expanded);
        if (this.market == null) {
            return;
        }
        tooltip.addPara(
                "%s ships produced quality.",
                10f,
                Misc.getHighlightColor(),
                "+" + (int)((PRODUCTION_BONUS)*100) + "%"
        );
		
		tooltip.addPara(
                "%s defense rating.",
                10f,
                Misc.getHighlightColor(),
                "+" + (int)((DEFENSE_BONUS-1)*100) + "%"
        );
		tooltip.addPara(
                "These effects only applies to %s market(s).",
                10f,
                Misc.getHighlightColor(),
                "Deserters"
        );        
	//	tooltip.addPara(
     //           "%s accessibility (based on market size).",
     //           10f,
     //           Misc.getHighlightColor(),
     //           "+" + (int)ACCESSIBILITY_BONUS + "%"
     //   );
		
    }

}