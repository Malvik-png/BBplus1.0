package data.scripts;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.CampaignPlugin;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketConditionAPI;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.intel.deciv.DecivTracker;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Industries;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import com.fs.starfarer.api.combat.MissileAIPlugin;
import com.fs.starfarer.api.combat.MissileAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.PluginPick;
import java.util.ArrayList;
import java.util.Arrays;
import org.dark.shaders.util.TextureData;
import org.dark.shaders.util.ShaderLib;
import com.fs.starfarer.api.impl.campaign.econ.impl.bbplus_SpecialItemEffectsRepo;
import data.scripts.ai.projectiles.bbplus_ExocetBombletAI;
import data.scripts.listeners.BBPlusBattleResultListener;
import data.scripts.world.BBPlusAddMarketplace;
import data.scripts.world.BBPlusGen;
import data.campaign.ids.bbplus_Conditions;
import data.campaign.ids.bbplus_Industries;
import com.fs.starfarer.api.impl.campaign.ids.BBPlus_Items;
import com.fs.starfarer.api.impl.campaign.ids.BBPlus_People;

public class BBPlusPlugin extends BaseModPlugin {
   // holy fuck I hate java so much
   private final BBPlusBattleResultListener resultListener = new BBPlusBattleResultListener(false);
   public static final String EXOCET_BOMBLET_ID = "bbplus_exocet_collider_bomblet";
   private static final String DME = "istl_dassaultmikoyan";
   private static final String GRAPHICSLIB = "shaderLib";
   private static final String QLIPHOTH_SYSTEM = "Qliphoth";
   private static final String STARKEEP_SEPHIRA_STATION = "deserter_starkeep";
   private static final String DESERTER_FACTION = "the_deserter_ex";
   private static final String DETECT_GEN = "gen";
   private static final float DETECTION_RANGE = 5000f;
   //private static final float TARRIF_RATE = 0.2f;
   //@Override
   //public void onApplicationLoad() throws ClassNotFoundException {  
   //    try {
   //        Global.getSettings().getScriptClassLoader().loadClass("data.scripts.DMEModPlugin");
   //    } catch (ClassNotFoundException ex) {
   //        String message = System.lineSeparator()
   //                + System.lineSeparator() + "Dassault-Mikoyan Engineering is required to run Blade Breaker Plus!"
   //                + System.lineSeparator() + System.lineSeparator()
   //                + "You can download DME at http://fractalsoftworks.com/forum/index.php?topic=11322.0"
   //                + System.lineSeparator();
   //        throw new ClassNotFoundException(message);
   //    }
   //    
   //}
    // for those chucklefucks who can't read or who doesn't want to, here's something for you
    @Override
    public void onApplicationLoad() {
        final boolean hasDME = Global.getSettings().getModManager().isModEnabled(DME);
        final boolean hasGraphicsLib = Global.getSettings().getModManager().isModEnabled(GRAPHICSLIB);
        if (!hasDME) {
            throw new RuntimeException("Dassault-Mikoyan Engineering is required to run Blade Breaker Plus!" +
            "\nYou can download DME at http://fractalsoftworks.com/forum/index.php?topic=11322.0");
        }
        if (hasGraphicsLib) {
            ShaderLib.init();
            TextureData.readTextureDataCSV("data/lights/bbplus_texture_data.csv");
        }        
    }

    @Override
    public void onNewGame() { 
        initBBplus();       
    }	    
    
    @Override
    public void onGameLoad(final boolean isNewGame) {
        final SectorAPI sector = Global.getSector();
        if (sector != null && sector.getListenerManager() != null) {
            sector.addListener(resultListener);
            if (!sector.getListenerManager().hasListener(resultListener)) {
                sector.getListenerManager().addListener(resultListener);
            }
        }
        bbplus_SpecialItemEffectsRepo.addItemEffectsToVanillaRepo();
    }	
 
    @Override
    public void onNewGameAfterTimePass(){
        bbpLoadMarket(); // fuck you thrice
    }    
        
    @Override
    public PluginPick<MissileAIPlugin> pickMissileAI(final MissileAPI missile, final ShipAPI launchingShip) {
        switch (missile.getProjectileSpecId()) { 
            case "bbplus_exocet_collider_bomblet":
                return new PluginPick<MissileAIPlugin>(new bbplus_ExocetBombletAI(missile, launchingShip), CampaignPlugin.PickPriority.MOD_SPECIFIC);
            default:
        }
        return null;
        // if (!projectileSpecId.equals("bbplus_exocet_collider_bomblet")) {
        //    return null;
        // }
	    // return (PluginPick<MissileAIPlugin>)new PluginPick((Object)new bbplus_ExocetBombletAI(missile, launchingShip), CampaignPlugin.PickPriority.MOD_SPECIFIC);   	
    }
    
    public static void bbpLoadMarket() {
        //motherfucker took me hundreds of braincells to make it work as intended
        final SectorAPI sector = Global.getSector(); 
        if (Global.getSector().getStarSystem(QLIPHOTH_SYSTEM) != null) {
            final StarSystemAPI system = sector.getStarSystem(QLIPHOTH_SYSTEM);
            final SectorEntityToken starkeep_sephira = system.getEntityById(STARKEEP_SEPHIRA_STATION);
            final MarketAPI starkeepMarket = BBPlusAddMarketplace.addMarketplace(
				DESERTER_FACTION, starkeep_sephira, null,
				"Starkeep Sephira", // name of the market
				4, // size of the market (from the JSON)
                new ArrayList<>(Arrays.asList( // Special snowflakes conditions for BBD market.
				bbplus_Conditions.ORBITALSTATION,
				bbplus_Conditions.CLOSEDDOOR,
				Conditions.STEALTH_MINEFIELDS,
				Conditions.POPULATION_4
				)),
                new ArrayList<>(Arrays.asList( // Special industries for them too.
				//bbplus_Industries.DESERTERHQ,
				//bbplus_Industries.FOODPROCESS,
				Industries.POPULATION,
				Industries.SPACEPORT,
				Industries.WAYSTATION,
				//Industries.ORBITALWORKS,
				Industries.STARFORTRESS_HIGH,
				Industries.HEAVYBATTERIES
				)),
                new ArrayList<>(Arrays.asList( // No filthy stinky pirates allowed!
				Submarkets.SUBMARKET_OPEN,
				Submarkets.GENERIC_MILITARY,
				Submarkets.SUBMARKET_STORAGE)),
                0.2f // lowered tarrif
		);       
                // Industries with special shit
                starkeepMarket.addIndustry(bbplus_Industries.DESERTERHQ, new ArrayList<>(Arrays.asList(BBPlus_Items.DISCHARGE_ABSORBER)));
                starkeepMarket.addIndustry(bbplus_Industries.FOODPROCESS, new ArrayList<>(Arrays.asList(BBPlus_Items.BIO_PRINTER)));
                starkeepMarket.addIndustry(Industries.ORBITALWORKS, new ArrayList<>(Arrays.asList(Items.CORRUPTED_NANOFORGE)));
                // To hide this fucking thing
                starkeepMarket.setEconGroup(starkeepMarket.getId());
                starkeepMarket.setHidden(true);
                starkeepMarket.setSurveyLevel(MarketAPI.SurveyLevel.FULL);
                starkeep_sephira.setSensorProfile(1f);
                starkeep_sephira.setDiscoverable(true);
                starkeep_sephira.setDiscoveryXP(1000f);
                starkeep_sephira.getDetectedRangeMod().modifyFlat(DETECT_GEN, DETECTION_RANGE);
                starkeepMarket.getMemoryWithoutUpdate().set(DecivTracker.NO_DECIV_KEY, true);                
                for (final MarketConditionAPI mc : starkeepMarket.getConditions()) {
                    //if (mc.requiresSurveying()) {
                    mc.setSurveyed(true);
                    //}
		}
            starkeepMarket.reapplyConditions();              
        }
        new BBPlus_People().advance(); 
    }
    
    private static void initBBplus() {
        new BBPlusGen().generate(Global.getSector());
    }
    
}