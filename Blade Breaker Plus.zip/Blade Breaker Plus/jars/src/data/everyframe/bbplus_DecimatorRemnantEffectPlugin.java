package data.scripts.everyframe;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseEveryFrameCombatPlugin;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamageType;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.input.InputEventAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.awt.Color;
import org.lwjgl.util.vector.Vector2f;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.combat.AIUtils;
/**
 *
 * @author Mayu -  based on codepalette's haze plugin
 */
public class bbplus_DecimatorRemnantEffectPlugin extends BaseEveryFrameCombatPlugin {

    private CombatEngineAPI engine;
    private static final List<HazePointData> entityList = new ArrayList<HazePointData>();
    private static final Map<Integer, Color> PARTICLE_COLOR = new HashMap<>();
    static
    {
    	PARTICLE_COLOR.put(0, new Color(205,25,70,230));
    	PARTICLE_COLOR.put(1, new Color(125,20,30,250));
    	PARTICLE_COLOR.put(2, new Color(235,90,5,255));
    }    
    private final IntervalUtil fxInterval = new IntervalUtil(0.1f, 0.1f);
    private static final Vector2f ZERO = new Vector2f();
    
    public static class HazePointData {
        public float duration;
        public float size;
        public CombatEntityAPI projectile;
        public ShipAPI ship;
        public WeaponAPI weapon;
        private final Vector2f origin;
        public HazePointData(final Vector2f origin, final CombatEntityAPI projectile, final WeaponAPI weapon, final ShipAPI ship, final float size, final float duration) {
                this.origin = origin;
                this.weapon = weapon;
                this.projectile = projectile;
                this.ship = ship;
                this.size = size;
                this.duration = duration;
        }
    }

    @Override
    public void init(final CombatEngineAPI engine) {
        this.engine = engine;
    }
    
    @Override
    public void advance(final float amount, final List<InputEventAPI> events) {
        //if (engine.isPaused()) {
        //    return;
        //}
    	if(engine == null) {
            engine = Global.getCombatEngine();
    	}
    	if(engine == null) {
            return;
    	}
    	if(entityList.isEmpty()) {
            return;
    	}
    	fxInterval.advance(amount);
        for(final HazePointData haze : new ArrayList<HazePointData>(entityList)) {
            if(fxInterval.intervalElapsed()) {
                final Vector2f origin;
                final int explosionColor;
                origin = MathUtils.getRandomPointInCircle(haze.origin, haze.size); 
            	final List<ShipAPI> enemies = AIUtils.getNearbyEnemies(haze.projectile, haze.size);
                if(!enemies.isEmpty()) {
                    final float crBonus = 0;		
	            for(final ShipAPI enemy : enemies) {	
		        engine.applyDamage(enemy, origin,
                        (haze.weapon.getDamage().computeDamageDealt(amount) * 0.25f) * (1 + crBonus),
		                    DamageType.HIGH_EXPLOSIVE,
		                    0,
		                    false,
		                    true,
		                    haze.ship
                        );
                    }
            	}
                explosionColor = MathUtils.getRandomNumberInRange(0, 2);
                engine.addHitParticle(origin, ZERO, haze.size * (1 +(float)Math.random()*3), 1, 0.3f+(float)Math.random(), PARTICLE_COLOR.get(explosionColor));
            }
            haze.duration -= amount;
            if(haze.duration < 0) {
                removeHaze(haze);
            }
        }
    }
    
    public static void addHaze(final Vector2f origin, final CombatEntityAPI projectile, final WeaponAPI weapon, final ShipAPI ship, final float size, final float duration) {
    	entityList.add(new HazePointData(origin, projectile, weapon, ship, size, duration));
    }
    
    public static void removeHaze(final HazePointData haze) {
    	entityList.remove(haze);
    }
	
}