package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;

public class BBPlusBreakerTenacity extends BaseHullMod {
       
    public static final float ENMITY_BONUS_DAMAGE = 15f;
    public static final float ENMITY_BONUS_SPEED = 10f;
    public static final int HULL_POINTS = 50;
    private final String ID;
    private final String BREAKER_TENACITY_SKILL = "bbplus_breaker_tenacity";
    public BBPlusBreakerTenacity() {
        this.ID = "BBPlusBreakerTenacity";
    }    
    //Pl*yers can't exploit this now huh?
    //SIGMA LOL!
    @Override
    public void applyEffectsAfterShipCreation(final ShipAPI ship, final String id){
        if (ship.getCaptain() == null || (ship.getCaptain().getStats().getSkillLevel(BREAKER_TENACITY_SKILL) <= 2)) {
            ship.getVariant().removeMod("bbplus_breaker_tenacity");
        }
    }  
    
    @Override
    public void advanceInCombat(final ShipAPI ship, final float amount) {
        final CombatEngineAPI engine = Global.getCombatEngine();
        final float percentageOfHPLeft = ship.getHitpoints() / ship.getMaxHitpoints();
        if (percentageOfHPLeft > 0.5f) {
            ship.getMutableStats().getMaxSpeed().unmodify(this.ID);
            ship.getMutableStats().getBallisticWeaponDamageMult().unmodify(this.ID);
            ship.getMutableStats().getEnergyWeaponDamageMult().unmodify(this.ID);
        }
        else {
            ship.getMutableStats().getMaxSpeed().modifyFlat(this.ID, ENMITY_BONUS_SPEED);
            ship.getMutableStats().getBallisticWeaponDamageMult().modifyPercent(this.ID, ENMITY_BONUS_DAMAGE);
            ship.getMutableStats().getEnergyWeaponDamageMult().modifyPercent(this.ID, ENMITY_BONUS_DAMAGE);
        }
        if (engine.getPlayerShip() != ship) {
            return;
        }
        final String crewStatus;
        // < less than
        // > greater than
        if (percentageOfHPLeft <= 0.5f) {
            crewStatus = "Undaunted!";
            engine.maintainStatusForPlayerShip((Object)(String.valueOf(this.ID) + "_TOOLTIP_ONE"), Global.getSettings().getSpriteName("tooltips", "bbtenacity"), "Crew Status: " + crewStatus, "Ballistic and energy damage +15%", false);
            engine.maintainStatusForPlayerShip((Object)(String.valueOf(this.ID) + "_TOOLTIP_TWO"), Global.getSettings().getSpriteName("tooltips", "bbtenacity"), "Breaker Tenacity", "Max top speed +10", false);
            //Global.getCombatEngine().maintainStatusForPlayerShip("Breaker Tenacity", "graphics/tooltips/bbplus_breaker_tenacity", "Max top speed: ","+" + "10",false);             
        }
    }
    //I'm not letting you to use this freely on non-BB ships
    //And even so, it's not gonna work without the skill tied to this
    //So come and try to wage an arms race, filthy Earthnoids
    //Also fuck you techpriest; you started this
    //Chitagupta delenda est
    @Override
    public boolean isApplicableToShip(final ShipAPI ship) {
        return ship != null && (ship.getVariant().getHullMods().contains("istl_bbengineering"));
    }

    @Override
    public String getUnapplicableReason(final ShipAPI ship) {
        if (ship == null || !ship.getVariant().getHullMods().contains("istl_bbengineering"))
            return "Can only be installed on a Blade Breaker ship";
        return null;
    }    
    
    @Override
    public String getDescriptionParam(final int index, final ShipAPI.HullSize hullSize) {
        if (index == 0) {
            return "The bonuses only applies on ships with Blade Breaker Engineering.";
        }
        return null;
    }    
    
    @Override
    public void addPostDescriptionSection(final TooltipMakerAPI tooltip, final ShipAPI.HullSize hullSize, final ShipAPI ship, final float width, final boolean isForModSpec) {
        final Color green = new Color(55,245,65,255);
        final Color flavor = new Color(110,110,110,255);
        final float pad = 10f;
        final float padStats = 5f;
        final float padList = 6f;
        final float padSig = 1f;    
        tooltip.addSectionHeading("Details", Alignment.MID, pad);
        tooltip.addPara("The following bonus will be applied when hull integrity falls below %s.", pad, Misc.getNegativeHighlightColor(), new String[] { HULL_POINTS + "%" });
        tooltip.addPara("- Increased ballistic weapon damage: %s \n- Increased energy weapon damage: %s \n- Increased top speed: %s flat", padStats, green, new String[] { ENMITY_BONUS_DAMAGE + "%", ENMITY_BONUS_DAMAGE + "%", ENMITY_BONUS_SPEED + "" });
        tooltip.addPara("%s", padList, flavor, new String[] { "\"There is no place for me other than the battlefield. To live as I please, and die a senseless death. That is who I am. Not a mere man of flesh. War is part of my existence.\"" });
        tooltip.addPara("%s", padSig, flavor, new String[] { "         \u2014 Valjean's Hired Guns Captain" });
    }    
    
    @Override
    public Color getBorderColor() {
       return new Color(225,140,105,245);
    }

    @Override
    public Color getNameColor() {
       return new Color(225,140,105,255);
    }
        
}