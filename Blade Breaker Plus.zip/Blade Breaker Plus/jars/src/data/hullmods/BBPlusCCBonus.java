package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;

public class BBPlusCCBonus extends BaseHullMod {
	// this faction isn't an actual faction at all; it shouldn't have CC bonus whatsoever
	// but then, I am just fucking with priest and I'll take this chance lole
	// and I'm pretty sure some of you dweebs will try to establish alliance via Nex with the Deserters
	// so you can see what will happen
	// and if you managed to discover this then you secretly installed VNSector
	// have sex techpriest you fucking coomer piss of shiet
    private static final float FLUX_DISSIPATION_MULT = 1.10f;
    private static final float HARD_FLUX_DIS = 10f;
    public static final float CORONA_EFFECT_REDUCTION = 0.85f;

    @Override
    public void applyEffectsBeforeShipCreation(final HullSize hullSize, final MutableShipStatsAPI stats, final String id) {
        stats.getFluxDissipation().modifyMult(id, FLUX_DISSIPATION_MULT);
        stats.getHardFluxDissipationFraction().modifyFlat(id, (float)HARD_FLUX_DIS * 0.01f);
        stats.getDynamic().getStat(Stats.CORONA_EFFECT_MULT).modifyMult(id, CORONA_EFFECT_REDUCTION);
    }
    
    @Override
    public String getDescriptionParam(final int index, final HullSize hullSize){
        //if (index == 0) return "" + "10" + "%";
        //if (index == 1) return "" + (int) HARD_FLUX_DIS + "%";
        //if (index == 2) return "" + (int) Math.round((1f - CORONA_EFFECT_REDUCTION) * 100f) + "%";
        return null;
    }

    @Override
    public void addPostDescriptionSection(final TooltipMakerAPI tooltip, final ShipAPI.HullSize hullSize, final ShipAPI ship, final float width, final boolean isForModSpec) {
        final Color green = new Color(55,245,65,255);
        final Color flavor = new Color(110,110,110,255);        
        final float pad = 10f;
        final float padQuote = 6f;
        final float padSig = 1f;
        tooltip.addSectionHeading("Details", Alignment.MID, pad);
        tooltip.addPara("- Improved flux dissipation: %s \n- Dissipates hardflux while shields are on: %s \n- Reduced negative effects of solar corona and hyperspace storm: %s", pad, green, new String[] { Misc.getRoundedValue(10.0f) + "%", Misc.getRoundedValue(10.0f) + "%", Misc.getRoundedValue(15.0f) + "%"});
        tooltip.addPara("%s", padQuote, flavor, new String[] { "\"This is nothing to concern yourself over. Just do what you are told and bring that damn sample here!\"" });
        tooltip.addPara("%s", padSig, flavor, new String[] { "         \u2014 Sixth Bureau Chief Engineer" });           
    }	

    @Override
    public Color getBorderColor() {
        return new Color(50,190,160,0);
    }

    @Override
    public Color getNameColor() {
        return new Color(65,250,175,255);
    }

}