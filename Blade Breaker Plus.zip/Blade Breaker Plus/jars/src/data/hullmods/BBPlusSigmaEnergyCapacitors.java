package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;

public class BBPlusSigmaEnergyCapacitors extends BaseHullMod {
	
    public static final float ROF_BONUS = 10f; // Hullmod bloat LOLMAO
    public static final float ENERGY_BONUS = 0.15f; // Experimental shit again
	
    @Override
    public void applyEffectsAfterShipCreation(final ShipAPI ship, final String id) {
        final MutableShipStatsAPI stats = ship.getMutableStats();
        stats.getEnergyRoFMult().modifyPercent(id, ROF_BONUS); // Helps to ramp up the flux level lol
    }

    @Override
    public void advanceInCombat(final ShipAPI ship, final float amount) {
        if (!ship.isAlive()) return;
            final ShipAPI playerShip = Global.getCombatEngine().getPlayerShip();
		//float FLUX_LEVEL = ship.getFluxTracker().getFluxLevel();
            final float FLUX_LEVEL = Math.min((ship.getFluxTracker().getFluxLevel() / 0.90f), 1f);
            ship.getMutableStats().getEnergyWeaponDamageMult().modifyMult("BBPlusSigmaEnergyCapacitors", 1f + ENERGY_BONUS * FLUX_LEVEL);
		//ship.getMutableStats().getEnergyWeaponDamageMult().modifyMult("BBPlusSigmaEnergyCapacitors", 1f + (0.25f * FLUX_LEVEL/2f));
        if (ship == playerShip){
				//Global.getCombatEngine().maintainStatusForPlayerShip("SEC RoF", "graphics/hullmods/bbplus_sec.png",
				//"Sigma Energy Capacitors: ","+" + "10% Rate Of Fire",false); // To let the player know that this fucking shit is working
            Global.getCombatEngine().maintainStatusForPlayerShip("Energy Damage", "graphics/hullmods/bbplus_sec.png",
                    "Sigma Energy Capacitors: ", "+" + Math.round((0f + (ENERGY_BONUS * FLUX_LEVEL)) * 100f) + "% Energy Weapon Damage",false);
				//"Sigma Energy Capacitors: ","+" + Math.round((0f + (0.25f * FLUX_LEVEL/2f)) * 100f) + "% Energy Damage",false);
        }
    }
	
    @Override
    public String getDescriptionParam(final int index, final HullSize hullSize) {
        //if (index == 0) return "" + (int) ROF_BONUS + "%";
        //if (index == 1) return "" + 15 + "%";
        return null;
    }

    @Override
    public void addPostDescriptionSection(final TooltipMakerAPI tooltip, final ShipAPI.HullSize hullSize, final ShipAPI ship, final float width, final boolean isForModSpec) {
        final Color green = new Color(55,245,65,255);
        final Color flavor = new Color(110,110,110,255);
        final float pad = 10f;
        final float padQuote = 6f;
        final float padSig = 1f;
        tooltip.addSectionHeading("Details", Alignment.MID, pad);
        tooltip.addPara("- Increased energy weapon's rate of fire: %s \n- Bonus energy damage cap: %s", pad, green, new String[] { Misc.getRoundedValue(10.0f) + "%", Misc.getRoundedValue(15.0f) + "%"});		
        tooltip.addPara("%s", padQuote, flavor, new String[] { "\"Don't worry, I got this; I know exactly what I am doing.\"" });
        tooltip.addPara("%s", padSig, flavor, new String[] { "         \u2014 Lavoisier Base R&D Engineer's famous last words" });    
    }	

}