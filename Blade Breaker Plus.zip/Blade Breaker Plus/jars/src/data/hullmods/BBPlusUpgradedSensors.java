package data.hullmods;

import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.hullmods.BaseLogisticsHullMod;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;
import java.util.HashSet;
import java.util.Set;

public class BBPlusUpgradedSensors extends BaseLogisticsHullMod {
    
    private static final Set<String> BLOCKED_HULLMODS = new HashSet();
    static
    {
        BLOCKED_HULLMODS.add("hiressensors"); // god, fuck, it's already highres what else do you want it to be?
    }
    private final static float SENSOR_MULT = 70f;
    private final static float PROFILE_MULT = 0.7f;
    
    @Override
    public void applyEffectsBeforeShipCreation(final HullSize hullSize, final MutableShipStatsAPI stats, final String id) {
        stats.getSensorStrength().modifyMult(id, 1f + SENSOR_MULT * 0.01f);
        stats.getSensorProfile().modifyMult(id, PROFILE_MULT);
    }
    
    @Override
    public void applyEffectsAfterShipCreation(final ShipAPI ship, final String id){
        for (final String tmp : BLOCKED_HULLMODS) {
            if (ship.getVariant().getHullMods().contains(tmp)) {                
                ship.getVariant().removeMod(tmp);
                DMEBlockedHullmodDisplayScript.showBlocked(ship);
            }
        }
    }

    @Override
    public String getDescriptionParam(final int index, final HullSize hullSize) {
        //if (index == 0) return "" + (int) SENSOR_MULT;
        //if (index == 1) return "" + (int) ((1f - PROFILE_MULT) * 100f) + "%";
        //if (index == 2) return "" + "High Resolution Sensors";
        return null;
    }
	
    @Override
    public boolean isApplicableToShip(final ShipAPI ship) {
        return ship != null && (!ship.getVariant().getHullMods().contains("hiressensors"));
    }
    
    @Override
    public String getUnapplicableReason(final ShipAPI ship) {
	if (ship.getVariant().hasHullMod("hiressensors")) {
           return "Incompatible with High Resolution Sensors.";
	}
        return null;
    }

    @Override
    public void addPostDescriptionSection(final TooltipMakerAPI tooltip, final ShipAPI.HullSize hullSize, final ShipAPI ship, final float width, final boolean isForModSpec) {
        final Color green = new Color(55,245,65,255);
        final float pad = 10f;
        tooltip.addSectionHeading("Incompatibilities", Alignment.MID, pad);
        tooltip.addPara("- %s", pad, Misc.getNegativeHighlightColor(), new String[] { "High Resolution Sensors" });	
        tooltip.addSectionHeading("Details", Alignment.MID, pad);
        tooltip.addPara("- Increased sensor strength: %s \n- Reduced ship's sensor profile: %s", pad, green, new String[] { Misc.getRoundedValue(70.0f) + "%", Misc.getRoundedValue(30.0f) + "%"});		
    }

}