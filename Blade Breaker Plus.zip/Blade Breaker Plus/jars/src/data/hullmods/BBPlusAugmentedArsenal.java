package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.util.Misc;
import java.util.HashSet;
import java.util.Set;
import java.awt.Color;

public class BBPlusAugmentedArsenal extends BaseHullMod {
	
    private static final Set<String> BLOCKED_HULLMODS = new HashSet();
    static
    {
        BLOCKED_HULLMODS.add("magazines"); // No
    }
    //private float check = 0;
    //private String ID, ERROR = "IncompatibleHullmodWarning";
    public static final float AMMO_BONUS = 60f; // I just want more unique hullmod shit
    public static final float FLUX_REDUC_PERCENT = 15f;
	
    @Override
    public void applyEffectsBeforeShipCreation(final HullSize hullSize, final MutableShipStatsAPI stats, final String id) {
        stats.getBallisticAmmoBonus().modifyPercent(id, AMMO_BONUS);
        stats.getEnergyAmmoBonus().modifyPercent(id, AMMO_BONUS);
        stats.getBallisticWeaponFluxCostMod().modifyPercent(id, -FLUX_REDUC_PERCENT);
        stats.getEnergyWeaponFluxCostMod().modifyPercent(id, -FLUX_REDUC_PERCENT);
    }
	
    @Override
    public String getDescriptionParam(final int index, final HullSize hullSize) {
	//if (index == 0) return "" + (int) AMMO_BONUS + "%";
	//if (index == 1) return "" + (int) FLUX_REDUC_PERCENT + "%";
	//if (index == 2) return "" + "Expanded Magazines";
        return null;
    }

    @Override
    public void applyEffectsAfterShipCreation(final ShipAPI ship, final String id){
        for (final String tmp : BLOCKED_HULLMODS) {
            if (ship.getVariant().getHullMods().contains(tmp)) {                
                ship.getVariant().removeMod(tmp);
                DMEBlockedHullmodDisplayScript.showBlocked(ship);				
                //ship.getVariant().addMod(ERROR);
            }
        }
    }

    @Override
    public boolean isApplicableToShip(final ShipAPI ship) {
        return ship != null && (!ship.getVariant().getHullMods().contains("magazines"));
    }
    
    @Override
    public String getUnapplicableReason(final ShipAPI ship) {
        if (ship.getVariant().hasHullMod("magazines")) {
            return "The weaponries of this ship are already extended and maximized"; // adding the expanded magazines hullmod is too much, yes?
        }
        return null;
    }

    @Override
    public void addPostDescriptionSection(final TooltipMakerAPI tooltip, final ShipAPI.HullSize hullSize, final ShipAPI ship, final float width, final boolean isForModSpec) {
        final Color green = new Color(55,245,65,255);
        final Color flavor = new Color(110,110,110,255);
        final float pad = 10f;
        final float padQuote = 6f;
        final float padSig = 1f;	
        tooltip.addSectionHeading("Incompatibilities", Alignment.MID, pad);
        tooltip.addPara("- %s", pad, Misc.getNegativeHighlightColor(), new String[] { "Expanded Magazines" });	
        tooltip.addSectionHeading("Details", Alignment.MID, pad);
        tooltip.addPara("- Increased maximum ammo capacity: %s \n- Reduced flux cost for energy and ballistic weapons: %s", pad, green, new String[] { Misc.getRoundedValue(60.0f) + "%", Misc.getRoundedValue(15.0f) + "%"});
        tooltip.addPara("%s", padQuote, flavor, new String[] { "\"Remember this well: an ordnance technician at a dead run will outrank everybody.\"" });
        tooltip.addPara("%s", padSig, flavor, new String[] { "         \u2014 Martinique Guard Commodore" });   
    }	

}