package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;
import java.util.HashSet;
import java.util.Set;

public class BBPlusBeamRefractor extends BaseHullMod {
    private static final Set<String> BLOCKED_HULLMODS = new HashSet();
    static
    {
        BLOCKED_HULLMODS.add("high_scatter_amp");
    }     
    public static final float BEAM_DAMAGE_BONUS = 20f;    
    public static final float BEAM_RANGE_PENALTY = 25f;
    
    @Override
    public void applyEffectsBeforeShipCreation(final HullSize hullSize, final MutableShipStatsAPI stats, final String id) {		
        stats.getBeamWeaponDamageMult().modifyPercent(id, BEAM_DAMAGE_BONUS);
        stats.getBeamWeaponRangeBonus().modifyPercent(id, -BEAM_RANGE_PENALTY);
    }
    
    @Override
    public void applyEffectsAfterShipCreation(final ShipAPI ship, final String id){
        for (final String tmp : BLOCKED_HULLMODS) {
            if (ship.getVariant().getHullMods().contains(tmp)) {                
                ship.getVariant().removeMod(tmp);
                DMEBlockedHullmodDisplayScript.showBlocked(ship);
                //ship.getVariant().addMod(ERROR);
            }
        }
    }
    // No, you can't use this outside of BB ships despite being a built-in
	// But then, it's not even implemented yet, b-b-b-b-b based!?
    @Override
    public boolean isApplicableToShip(final ShipAPI ship) {
        return ship != null && (ship.getVariant().getHullMods().contains("istl_bbengineering")) &&
                               !ship.getVariant().getHullMods().contains("high_scatter_amp");
    }

    @Override
    public String getUnapplicableReason(final ShipAPI ship) {
        if (ship == null || !ship.getVariant().getHullMods().contains("istl_bbengineering"))
            return "Can only be installed on a Blade Breaker ship";
	if (ship.getVariant().hasHullMod("high_scatter_amp")) // No
            return "Incompatible with High Scatter Amplifier";        
        return null;
    } 
        
    @Override
    public String getDescriptionParam(final int index, final HullSize hullSize) {
        return null;
    }

    @Override
    public void addPostDescriptionSection(final TooltipMakerAPI tooltip, final ShipAPI.HullSize hullSize, final ShipAPI ship, final float width, final boolean isForModSpec) {
        final Color green = new Color(55,245,65,255);
        final Color red = new Color(255,0,0,255);
        final Color flavor = new Color(110,110,110,255);
        final float pad = 10f;
        final float padQuote = 6f;
        final float padSig = 1f;
        final float padNeg = 0.0f;
        tooltip.addSectionHeading("Incompatibilities", Alignment.MID, pad);
        tooltip.addPara("- %s", pad, Misc.getNegativeHighlightColor(), new String[] { "High Scatter Amplifier" });
        tooltip.addSectionHeading("Details", Alignment.MID, pad);
        tooltip.addPara("- Increased beam weapon damage: %s", pad, green, new String[] { BEAM_DAMAGE_BONUS + "%" });
        tooltip.addPara("\n- Reduced range for beam weapons: %s", padNeg, red, new String[] { BEAM_RANGE_PENALTY + "%" });
        tooltip.addPara("%s", padQuote, flavor, new String[] { "\"Don't stare at it idiot! You will burn your retina!\"" });
        tooltip.addPara("%s", padSig, flavor, new String[] { "         \u2014 SNRI lab scientist data logs c202.09.03" });
    }
    
}