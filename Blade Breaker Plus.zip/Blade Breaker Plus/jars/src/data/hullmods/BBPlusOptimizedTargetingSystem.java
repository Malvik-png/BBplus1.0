package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;
import java.util.HashSet;
import java.util.Set;

public class BBPlusOptimizedTargetingSystem extends BaseHullMod {

    private static final Set<String> BLOCKED_HULLMODS = new HashSet();
        static
        {
            BLOCKED_HULLMODS.add("targetingunit"); // How about no
            BLOCKED_HULLMODS.add("dedicated_targeting_core"); // Just no
        }
        //private float check = 0;
        //private String ID, ERROR = "IncompatibleHullmodWarning";
    public static final float RANGE_BONUS = 80f; // I added this because I don't want the generic ATC
    public static final float PD_MINUS = 50f;
    public static final float BB_SHIELD_EFF = 10f; // A bit of fuck you
    public static final float BB_SHIELD_ABSORP_MULT = 10f;
    public static final float BB_SHIELD_REDUCTION = 10f;
    public static final float BB_SHIELD_RATE = 10f;
    public static final float BB_SHIELD_UPKEEP_BONUS = 10f;
        
    @Override
    public void applyEffectsBeforeShipCreation(final HullSize hullSize, final MutableShipStatsAPI stats, final String id) {
        stats.getBallisticWeaponRangeBonus().modifyPercent(id, RANGE_BONUS);
        stats.getEnergyWeaponRangeBonus().modifyPercent(id, RANGE_BONUS);	
        stats.getNonBeamPDWeaponRangeBonus().modifyPercent(id, -PD_MINUS);
        stats.getBeamPDWeaponRangeBonus().modifyPercent(id, -PD_MINUS);
       //Shield fuckery
        stats.getShieldDamageTakenMult().modifyPercent(id, -BB_SHIELD_EFF);
        stats.getShieldAbsorptionMult().modifyMult(id, 1f - BB_SHIELD_ABSORP_MULT * 0.01f);
        stats.getHighExplosiveShieldDamageTakenMult().modifyMult(id, 1f - BB_SHIELD_REDUCTION / 100f);
        stats.getBeamShieldDamageTakenMult().modifyMult(id, 1f - BB_SHIELD_REDUCTION / 100f);
        stats.getFragmentationShieldDamageTakenMult().modifyMult(id, 1f - BB_SHIELD_REDUCTION / 100f);
        stats.getKineticShieldDamageTakenMult().modifyMult(id, 1f - BB_SHIELD_REDUCTION / 100f);
        stats.getMissileShieldDamageTakenMult().modifyMult(id, 1f - BB_SHIELD_REDUCTION / 100f);
        stats.getProjectileShieldDamageTakenMult().modifyMult(id, 1f - BB_SHIELD_REDUCTION / 100f);        
        stats.getShieldUpkeepMult().modifyMult(id, 1f - BB_SHIELD_UPKEEP_BONUS * 0.01f);
        stats.getShieldUnfoldRateMult().modifyPercent(id, BB_SHIELD_RATE);
        stats.getShieldTurnRateMult().modifyPercent(id, BB_SHIELD_RATE);                    
    }

    @Override
    public void applyEffectsAfterShipCreation(final ShipAPI ship, final String id){
        for (final String tmp : BLOCKED_HULLMODS) {
            if (ship.getVariant().getHullMods().contains(tmp)) {                
                ship.getVariant().removeMod(tmp);
                DMEBlockedHullmodDisplayScript.showBlocked(ship);
                //ship.getVariant().addMod(ERROR);
            }
        }
    }
	
    @Override
    public String getDescriptionParam(final int index, final HullSize hullSize) {
        //if (index == 0) return "" + (int) Math.round(RANGE_BONUS) + "%";
        //if (index == 1) return "" + (int) Math.round(RANGE_BONUS - PD_MINUS) + "%";
        //if (index == 2) return "" + (int) SHIELD_EFF + "%";
        //if (index == 3) return "" + "Integrated Targeting Unit";
        //if (index == 4) return "" + "Dedicated Targeting Core";
        //if (index == 0) return "" + (int)RANGE_THRESHOLD;
        //if (index == 1) return "" + (int)((RANGE_MULT - 1f) * 100f);
        //if (index == 1) return "" + new Float(VISION_BONUS).intValue();
        return null;
    }

    @Override
    public boolean isApplicableToShip(final ShipAPI ship) {
        return (!ship.getVariant().getHullMods().contains("targetingunit")) &&// Also considering to add ATC but that shit is built-in anyway
                !ship.getVariant().getHullMods().contains("dedicated_targeting_core");
    }
	
    @Override
    public String getUnapplicableReason(final ShipAPI ship) {
        if (ship.getVariant().getHullMods().contains("targetingunit")) {
            return "Incompatible with Integrated Targeting Unit";
        }
        if (ship.getVariant().getHullMods().contains("dedicated_targeting_core")) {
            return "Incompatible with Dedicated Targeting Core";
         }
        return null;
    }
	
    @Override
    public void addPostDescriptionSection(final TooltipMakerAPI tooltip, final ShipAPI.HullSize hullSize, final ShipAPI ship, final float width, final boolean isForModSpec) {
        final Color green = new Color(55,245,65,255);
        final float pad = 10f;
        //tooltip.addSectionHeading("Incompatibilities", Alignment.MID, pad);
        //tooltip.addPara("- Incompatible with %s, %s", pad, Misc.getNegativeHighlightColor(), new String[] { "Dedicated Targeting Core", "Integrated Targeting Unit" });	
        tooltip.addSectionHeading("Details", Alignment.MID, pad);
        tooltip.addPara("- Increased range of ballistic and energy weapons: %s \n- Increased range of Point Defense weapons: %s \n- Increased shield efficiency: %s", pad, green, new String[] { Misc.getRoundedValue(80.0f) + "%", Misc.getRoundedValue(30.0f) + "%", Misc.getRoundedValue(10.0f) + "%"});		
    }	

}