package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;

public class BBPlusWeaponOvercharger extends BaseHullMod {
    
    public static final float DAMAGE_BONUS = 25f;
    public static final float FLUX_MALUS = 2f;
    // This is your fault techpriest
	// Once upon a time, techpriest walks in a bar
	// But then, there's no sex because he can't have and fuck you fckfiis coyiu yuotyu fuck you sSNEEEEEEEEED
    @Override
    public void applyEffectsBeforeShipCreation(final HullSize hullSize, final MutableShipStatsAPI stats, final String id) {
        stats.getBallisticWeaponDamageMult().modifyPercent(id, DAMAGE_BONUS);
        stats.getEnergyWeaponDamageMult().modifyPercent(id, DAMAGE_BONUS);
        stats.getBallisticWeaponFluxCostMod().modifyMult(id, FLUX_MALUS);
        stats.getEnergyWeaponFluxCostMod().modifyMult(id, FLUX_MALUS);  
    }

    @Override
    public String getDescriptionParam(final int index, final HullSize hullSize) {
        return null;
    }

    @Override
    public void addPostDescriptionSection(final TooltipMakerAPI tooltip, final ShipAPI.HullSize hullSize, final ShipAPI ship, final float width, final boolean isForModSpec) {
        final Color green = new Color(55,245,65,255);
        final Color red = new Color(255,0,0,255);
        final Color flavor = new Color(110,110,110,255);
        final float pad = 10f;
        final float padQuote = 6f;
        final float padSig = 1f;
        tooltip.addSectionHeading("Details", Alignment.MID, pad);
        tooltip.addPara("- Increased energy weapon damage: %s \n- Increased ballistic weapon damage: %s", pad, green, new String[] { Misc.getRoundedValue(25.0f) + "%", Misc.getRoundedValue(25.0f) + "%" });
        tooltip.addPara("- Ballistic and energy weapon flux cost are %s.", 0.0f, red, new String[] { "doubled" });
        tooltip.addPara("%s", padQuote, flavor, new String[] { "\"Don't you think this is way too overboard? I advise that we should stop right now.\"" });
        tooltip.addPara("%s", padSig, flavor, new String[] { "         \u2014 SNRI lab report #24, c199" });
    } 
    
}