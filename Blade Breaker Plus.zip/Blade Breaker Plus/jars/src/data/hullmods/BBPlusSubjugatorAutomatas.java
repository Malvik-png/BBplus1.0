package data.hullmods;

import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;

public class BBPlusSubjugatorAutomatas extends BaseHullMod {
    // murderous robot waifus
    public static final float SUBJUGATOR_AUTOMATAS = 200f;
    public static final float CASUALTIES_MULT = 0.90f;

    @Override
    public void applyEffectsBeforeShipCreation(final HullSize hullSize, final MutableShipStatsAPI stats, final String id) {
        stats.getDynamic().getMod(Stats.FLEET_GROUND_SUPPORT).modifyFlat(id, SUBJUGATOR_AUTOMATAS);
        stats.getDynamic().getStat(Stats.PLANETARY_OPERATIONS_CASUALTIES_MULT).modifyMult(id, CASUALTIES_MULT);
    }

    @Override
    public String getDescriptionParam(final int index, final HullSize hullSize) {
        //if (index == 0) return "" + (int) SUBJUGATOR_AUTOMATAS;
        return null;
    }

    @Override
    public boolean isApplicableToShip(final ShipAPI ship) {
        return false;
    }

    @Override
    public void addPostDescriptionSection(final TooltipMakerAPI tooltip, final ShipAPI.HullSize hullSize, final ShipAPI ship, final float width, final boolean isForModSpec) {
        final Color green = new Color(55,245,65,255);
        final Color flavor = new Color(110,110,110,255);
        final float pad = 10f;
        final float padQuote = 6f;
        final float padSig = 1f;	
        tooltip.addSectionHeading("Details", Alignment.MID, pad);
        tooltip.addPara("- Reduces marine casualties suffered during ground operations such as raids: %s \n- Increased planetary raid efficiency by %s up to the total number of marines in the fleet.", pad, green, new String[] { Misc.getRoundedValue(10.0f) + "%", Misc.getRoundedValue(200.0f) + ""});
        tooltip.addPara("%s", padQuote, flavor, new String[] { "\"W-What are those THINGS!? They don't stop coming!\"" });
        tooltip.addPara("%s", padSig, flavor, new String[] { "         \u2014 Gardien-chef in an undisclosed operation" });                
    }

}