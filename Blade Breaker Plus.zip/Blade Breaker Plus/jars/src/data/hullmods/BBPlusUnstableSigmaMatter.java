package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.CampaignUIAPI.CoreUITradeMode;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.util.Misc;
import java.util.HashMap;
import java.util.Map;
import java.awt.Color;
import data.campaign.ids.istl_Commodities;

public class BBPlusUnstableSigmaMatter extends BaseHullMod {

    private final Color color = new Color(90,210,160,255); // Gonna snort that sigma crack
    private static final String[] ALL_INCOMPAT_IDS = {
        "bbplus_sm_lowgrade", "bbplus_sm_highgrade", "bbplus_sigmanode",
        "bbplus_sm_lowgrade_dummy", "bbplus_sm_highgrade_dummy",
        "safetyoverrides", "solar_shielding", "converted_hangar", "roider_fighterClamps"};
    private final String BBreakerENG = "istl_bbengineering";
    private final String BBreakerASS = "istl_bbassault";
    public static final String DATA_PREFIX = "sigma_matter_unstable_gen_check_";
    public static final String ITEM = istl_Commodities.SIGMA_MATTER_UNSTABLE;
    private String[] getIncompatibleIds() {
        if (super.spec.getId().equals("bbplus_sm_unstable"))
            return ALL_INCOMPAT_IDS;
        return null;
    }        
    private static final Map speed = new HashMap();
        static
        {
            speed.put(HullSize.FRIGATE, 30f); // 15
            speed.put(HullSize.DESTROYER, 25f); // 20
            speed.put(HullSize.CRUISER, 20f); // 30
            speed.put(HullSize.CAPITAL_SHIP, 15f); // 35
        }
    private static final Map bbspeed = new HashMap();
        static
        {
            bbspeed.put(HullSize.FRIGATE, 25f); // 10
            bbspeed.put(HullSize.DESTROYER, 20f); // 15
            bbspeed.put(HullSize.CRUISER, 15f); // 25
            bbspeed.put(HullSize.CAPITAL_SHIP, 10f); // 30
        }
    public static final float BONUS_DAMAGE = 1.10f; //1.15f
    public static final float ROF_BONUS = 25f;
    private static final float RECOIL_REDUC = 50f;	
    private static final float DISS_BONUS = 1.60f;
    //public static final float WEAPON_FLUX_REDUCTION = 20f; // for a glorified SO, it's too much don't you think?
    public static final float ZERO_FLUX_SPEED = 15f;
	// Pseudo BB Engineering penalties and etc
    private static final float SUPPLY_PENALTY = 1.50f; //just like Sigma Node but since this is the superior version, it is more expensive
    private static final float OVERLOAD_DURATION_MULT = 1.50f; // there's nothing wrong with this, plus it takes 0 OP 
    private static final float ENGINE_DAMAGE = 1.10f; // your trophy is now usable so it's fine (^:
    public static final float EXPLODE_MULT = 1.5f; // E X P L O S I O N
    public static final float EXPLODE_RADIUS_MULT = 0.80f;
    public static final float CORONA_EFFECT_REDUCTION = 0.50f;
    private static final float PEAK_MULT = 0.5f; // halves the peak performance time
    private static final float RANGE_THRESHOLD = 550f;
    private static final float RANGE_MULT = 0.25f;
	// Lessened bonus for BB ships but the dumb malus is negated with some exceptions
    public static final float BB_BONUS_DAMAGE = 1.10f;
    public static final float BB_ROF_BONUS = 20f;
    private static final float BB_RECOIL_REDUC = 30f;	
    private static final float BB_DISS_BONUS = 1.50f;
    //public static final float BB_WEAPON_FLUX_REDUCTION = 15f;
    public static final float BB_ZERO_FLUX_SPEED = 10f;
    //Assault Mode
    @Override
    public void applyEffectsBeforeShipCreation(final ShipAPI.HullSize hullSize, final MutableShipStatsAPI stats, final String id) {
        // general malus
        stats.getVentRateMult().modifyMult(id, 0f); // prevents the use of active venting						
        stats.getEngineDamageTakenMult().modifyMult(id, ENGINE_DAMAGE);
        stats.getWeaponRangeThreshold().modifyFlat(id, RANGE_THRESHOLD); // clamped range
        stats.getWeaponRangeMultPastThreshold().modifyMult(id, RANGE_MULT);
        stats.getPeakCRDuration().modifyMult(id, PEAK_MULT);
        // what a fucking clusterfuck of a hullmod is this
        if (stats.getVariant().hasHullMod("istl_bbengineering")){
            // the BB Engineering-like penalties are negated for BB ships, why would you INCREASE it?
            // think of it as a supplementary sigma battery or some shit ok
            // in return, the benefits of this mod are lessened for BB ships
            stats.getMaxSpeed().modifyFlat(id, (Float) bbspeed.get(hullSize));
            stats.getAcceleration().modifyFlat(id, (Float) bbspeed.get(hullSize) * 1.5f);
            stats.getDeceleration().modifyFlat(id, (Float) bbspeed.get(hullSize) * 1.25f);	
        }
        else {
            stats.getMaxSpeed().modifyFlat(id, (Float) speed.get(hullSize));
            stats.getAcceleration().modifyFlat(id, (Float) speed.get(hullSize) * 1.5f);
            stats.getDeceleration().modifyFlat(id, (Float) speed.get(hullSize) * 1.25f);	
            stats.getSuppliesPerMonth().modifyMult(id, SUPPLY_PENALTY);
            stats.getDynamic().getStat(Stats.CORONA_EFFECT_MULT).modifyMult(id, CORONA_EFFECT_REDUCTION);
        }
    }
	
    @Override
    public void applyEffectsAfterShipCreation(final ShipAPI ship, final String id){
        final MutableShipStatsAPI stats = ship.getMutableStats();
        if (ship.getVariant().hasHullMod("istl_bbengineering")){		
            stats.getBallisticWeaponDamageMult().modifyPercent(id, BB_BONUS_DAMAGE);
            stats.getEnergyWeaponDamageMult().modifyPercent(id, BB_BONUS_DAMAGE);
            stats.getBallisticRoFMult().modifyPercent(id, BB_ROF_BONUS);
            stats.getEnergyRoFMult().modifyPercent(id, BB_ROF_BONUS);
            stats.getMissileRoFMult().modifyPercent(id, BB_ROF_BONUS);
            stats.getMaxRecoilMult().modifyMult(id, 1f - (0.01f * BB_RECOIL_REDUC));
            stats.getRecoilPerShotMult().modifyMult(id, 1f - (0.01f * BB_RECOIL_REDUC));
            stats.getRecoilDecayMult().modifyMult(id, 1f - (0.01f * BB_RECOIL_REDUC));
            stats.getFluxDissipation().modifyMult(id, BB_DISS_BONUS);
			//stats.getBallisticWeaponFluxCostMod().modifyPercent(id, -BB_WEAPON_FLUX_REDUCTION);
			//stats.getEnergyWeaponFluxCostMod().modifyPercent(id, -BB_WEAPON_FLUX_REDUCTION);
			//stats.getBeamWeaponFluxCostMult().modifyPercent(id, -BB_WEAPON_FLUX_REDUCTION);
            stats.getZeroFluxSpeedBoost().modifyFlat(id, BB_ZERO_FLUX_SPEED);				
        }
        else {
            stats.getBallisticWeaponDamageMult().modifyPercent(id, BONUS_DAMAGE);
            stats.getEnergyWeaponDamageMult().modifyPercent(id, BONUS_DAMAGE);
            stats.getBallisticRoFMult().modifyPercent(id, ROF_BONUS);
            stats.getEnergyRoFMult().modifyPercent(id, ROF_BONUS);
            stats.getMissileRoFMult().modifyPercent(id, ROF_BONUS);
            stats.getMaxRecoilMult().modifyMult(id, 1f - (0.01f * RECOIL_REDUC));
            stats.getRecoilPerShotMult().modifyMult(id, 1f - (0.01f * RECOIL_REDUC));
            stats.getRecoilDecayMult().modifyMult(id, 1f - (0.01f * RECOIL_REDUC));
            stats.getFluxDissipation().modifyMult(id, DISS_BONUS);
			//stats.getBallisticWeaponFluxCostMod().modifyPercent(id, -WEAPON_FLUX_REDUCTION);
			//stats.getEnergyWeaponFluxCostMod().modifyPercent(id, -WEAPON_FLUX_REDUCTION);
			//stats.getBeamWeaponFluxCostMult().modifyPercent(id, -WEAPON_FLUX_REDUCTION);
            stats.getZeroFluxSpeedBoost().modifyFlat(id, ZERO_FLUX_SPEED);						
            stats.getOverloadTimeMod().modifyMult(id, OVERLOAD_DURATION_MULT);
            stats.getDynamic().getStat(Stats.EXPLOSION_DAMAGE_MULT).modifyMult(id, EXPLODE_MULT); // boom just like the og
            stats.getDynamic().getStat(Stats.EXPLOSION_RADIUS_MULT).modifyMult(id, EXPLODE_RADIUS_MULT);
        }
        // no stacking of things, fuck off 
        for (final String tmp : ALL_INCOMPAT_IDS) {
            if (ship.getVariant().getHullMods().contains(tmp)) {                
                ship.getVariant().removeMod(tmp);
                DMEBlockedHullmodDisplayScript.showBlocked(ship);
		//ship.getVariant().addMod(ERROR);
            }
        }
    }
    
    @Override
    public boolean isApplicableToShip(final ShipAPI ship) {
        if (ship == null || ship.getVariant() == null)
            return false;
                if (ship.getVariant().getHullMods().contains("bbplus_sm_unstable_dummy")) return false;
                if (ship.getVariant().getHullMods().contains("converted_hangar")) return false;
                if (ship.getVariant().getHullMods().contains("safetyoverrides")) return false;
                if (ship.getVariant().getHullMods().contains("solar_shielding")) return false;
                if (ship.getVariant().getHullMods().contains("bbplus_sigmanode")) return false;
                if (ship.getVariant().getHullMods().contains("roider_fighterClamps")) return false;                
        if (BBPlusSigmaDriveInstaller.listContainsAny(ship.getVariant().getHullMods(), (Object[])ALL_INCOMPAT_IDS))
            return false;      
        return !BBPlusSigmaDriveInstaller.listContainsAny(ship.getVariant().getHullMods(), (Object[])getIncompatibleIds());
    }
    
    @Override
    public String getUnapplicableReason(final ShipAPI ship) {
        if (ship == null || ship.getVariant() == null)
            return "Unable to locate ship!";
                if (ship.getVariant().hasHullMod("bbplus_sm_unstable_dummy")) // To avoid fuckery
                    return "Sigma Drive Accelerator is already installed";
                if (ship.getVariant().hasHullMod("converted_hangar"))
                    return "Incompatible with Converted Hangar";
                if (ship.getVariant().hasHullMod("safetyoverrides"))
                    return "Incompatible with Safety Overrides";
                if (ship.getVariant().hasHullMod("solar_shielding"))
                    return "Incompatible with Solar Shielding";
                if (ship.getVariant().hasHullMod("bbplus_sigmanode"))
                    return "Incompatible with Sigma Node";
                if (ship.getVariant().hasHullMod("roider_fighterClamps"))
                    return "Incompatible with Fighter Clamps";                
        if (BBPlusSigmaDriveInstaller.listContainsAny(ship.getVariant().getHullMods(), (Object[])ALL_INCOMPAT_IDS) ||
            BBPlusSigmaDriveInstaller.listContainsAny(ship.getVariant().getHullMods(), (Object[])getIncompatibleIds()))
            return "Only one type of Sigma Matter can be installed per ship";  
        return ""; //I have to repeat this warning several times for those who doesn't read
    }

    @Override
    public void advanceInCampaign(final FleetMemberAPI member, final float amount) {
        final Map<String, Object> data = Global.getSector().getPersistentData();
        if (data.containsKey(DATA_PREFIX + member.getId())) {
            return;
        }
        BBPlusSigmaDriveInstaller.removePlayerCommodity(ITEM);
        data.put(DATA_PREFIX + member.getId(), "placeholder");
    }

    @Override
    public boolean canBeAddedOrRemovedNow(final ShipAPI ship, final MarketAPI marketOrNull, final CoreUITradeMode mode) {
        final int status = BBPlusSigmaDriveInstaller.isPlayerShip(ship, super.spec.getId());
        if (status == BBPlusSigmaDriveInstaller.NOT_PLAYER) {
            return false;
        }
        if (status != BBPlusSigmaDriveInstaller.HAS_HULLMOD && !BBPlusSigmaDriveInstaller.playerHasCommodity(ITEM)) {
            return false;
        }
        return super.canBeAddedOrRemovedNow(ship, marketOrNull, mode);
    }

    @Override
    public String getCanNotBeInstalledNowReason(final ShipAPI ship, final MarketAPI marketOrNull, final CoreUITradeMode mode) {
        final int status = BBPlusSigmaDriveInstaller.isPlayerShip(ship, super.spec.getId());
        if (status == BBPlusSigmaDriveInstaller.NOT_PLAYER) {
            return "This installation is not applicable to modules";
        }
        if (status != BBPlusSigmaDriveInstaller.HAS_HULLMOD && !BBPlusSigmaDriveInstaller.playerHasCommodity(ITEM)) {
            return "Installation requires [Unstable Sigma Matter] (1)";
        }
        return super.getCanNotBeInstalledNowReason(ship, marketOrNull, mode);
    }
    
    @Override
    public void advanceInCombat(final ShipAPI ship, final float amount) {
        //ship.getEngineController().fadeToOtherColor(this, color, null, 1f, 0.4f);
        ship.getEngineController().fadeToOtherColor(this, color, color, 1f, 1f);
        //ship.getEngineController().extendFlame(this, 0.25f, 0.25f, 0.25f);
    }
    
    @Override
    public String getDescriptionParam(final int index, final ShipAPI.HullSize hullSize) {
        //if (index == 0) return "" + (int) PEAK_MULT + "";
        if (index == 0) return "" + "varying effects";
        return null;
    }
    //HAVE SEX CRINJPRIEST
    @Override
    public void addPostDescriptionSection(final TooltipMakerAPI tooltip, final ShipAPI.HullSize hullSize, final ShipAPI ship, final float width, final boolean isForModSpec) {
        final Color bbreaker = new Color(155,155,190,255);
        final Color green = new Color(55,245,65,255);
        final Color red = new Color(255,0,0,255);
        final Color sigmadriveaccel = new Color(215,30,30,255);
        final Color warning = new Color (255,80,0,255);
        final float pad = 10f;
        final float opad = 8.0f;
        tooltip.addImage("graphics/tooltips/bbplus_sigmaborder.png", 368f, 8f, 5f);
        TooltipMakerAPI text = tooltip.beginImageWithText(Global.getSettings().getSpriteName("smatters", "usigma"), 33.0f);
        text.addPara("If the %s is installed on a Blade Breaker ship, it will provide different effects.", 3.0f, sigmadriveaccel, new String[] { "Unstable Sigma Matter" });
        tooltip.addImageWithText(3.0f);
        // If you view this modspec in your inventory without the null conditions then it will cause CTD so...
        // I need to put this so the game won't shit the bed.
        tooltip.addSectionHeading("Incompatibilities", Alignment.MID, pad);
        tooltip.addPara("- Incompatible with %s, %s, %s, %s", pad, Misc.getNegativeHighlightColor(), new String[] { "Converted Hangar", "Safety Overrides", "Sigma Node", "Solar Shielding" });
        tooltip.addSectionHeading("Details", Alignment.MID, pad);
        if (ship == null || ship.getVariant() == null) {
            tooltip.addPara("\n- Improved top speed: %s/%s/%s/%s (by hull size) \n- Ballistic and energy damage are increased: %s \n- Reduced weapon recoil: %s \n- Weapon rate of fire increased: %s \n- Increased flux dissipation: %s \n- Increases zero-flux speed bonus: %s flat \n- %s the harmful effects of solar coronas and hyperspace storms.", pad, green, new String[] { Misc.getRoundedValue(30.0f) + "", Misc.getRoundedValue(25.0f) + "", Misc.getRoundedValue(20.0f) + "", Misc.getRoundedValue(15.0f) + "", Misc.getRoundedValue(10.0f) + "%", Misc.getRoundedValue(50.0f) + "%", Misc.getRoundedValue(25.0f) + "%", Misc.getRoundedValue(60.0f) + "%", Misc.getRoundedValue(15.0f) + "", "Halves" });
            tooltip.addPara("- Supply cost is increased: %s \n- Overload duration is increased: %s \n- Reduces the peak performance time by a factor of %s. \n- Prevents the use of %s. \n- Limits the range of weaponries to %s or less. \n- The engines will receive %s more damage. \n- Explodes %s than a comparable hull.", 0.0f, red, new String[] { Misc.getRoundedValue(50.0f) + "%", Misc.getRoundedValue(50.0f) + "%", Misc.getRoundedValue(5.0f) + "", "active venting" , Misc.getRoundedValue(600.0f) + "su", Misc.getRoundedValue(10.0f) + "%", "more violently" });
        }
        else if (ship.getVariant().hasHullMod("istl_bbengineering") && ship.getVariant().hasHullMod("istl_bbassault")) {
            text = tooltip.beginImageWithText(Global.getSettings().getHullModSpec(BBreakerASS).getSpriteName(), 36f);
            text.addPara("A %s ship with %s is detected, further adjustment to bonuses are applied.", 0.0f, bbreaker, new String[] { "Blade Breaker", "Breaker Assault" });
            tooltip.addImageWithText(pad);
            tooltip.addPara("\n- Ballistic and energy damage are increased: %s \n- Reduced weapon recoil: %s \n- Weapon rate of fire increased: %s", 0.0f, green, new String[] { Misc.getRoundedValue(10.0f) + "%", Misc.getRoundedValue(30.0f) + "%", Misc.getRoundedValue(20.0f) + "%"});
			//tooltip.addPara("\n- Improved top speed: %s/%s/%s/%s (by hull size) \n- Ballistic and energy damage are increased: %s \n- Reduced weapon recoil: %s \n- Weapon rate of fire increased: %s", 1.0f, green, new String[] { Misc.getRoundedValue(25.0f) + "", Misc.getRoundedValue(20.0f) + "", Misc.getRoundedValue(15.0f) + "", Misc.getRoundedValue(10.0f) + "", Misc.getRoundedValue(10.0f) + "%", Misc.getRoundedValue(30.0f) + "%", Misc.getRoundedValue(20.0f) + "%"});
            tooltip.addPara("- The engines will receive %s more damage.", 0.0f, red, new String[] { Misc.getRoundedValue(10.0f) + "%" });
        }
        else if (ship.getVariant().hasHullMod("istl_bbengineering")) {
            text = tooltip.beginImageWithText(Global.getSettings().getHullModSpec(BBreakerENG).getSpriteName(), 36f);
            text.addPara("A %s ship is detected, certain negative effects are negated and overall bonus are reduced.", 0.0f, bbreaker, new String[] {"Blade Breaker"});
            tooltip.addImageWithText(pad);
			//tooltip.addPara("A %s ship is detected, certain negative effects are negated and overall bonus are reduced.", 6.0f, bbreaker, new String[] {"Blade Breaker"});
            tooltip.addPara("\n- Improved top speed: %s/%s/%s/%s (by hull size) \n- Ballistic and energy damage are increased: %s \n- Reduced weapon recoil: %s \n- Weapon rate of fire increased: %s \n- Increase flux dissipation: %s \n- Increases zero-flux speed bonus by: %s flat", 0.0f, green, new String[] { Misc.getRoundedValue(25.0f) + "", Misc.getRoundedValue(20.0f) + "", Misc.getRoundedValue(15.0f) + "", Misc.getRoundedValue(10.0f) + "", Misc.getRoundedValue(10.0f) + "%", Misc.getRoundedValue(30.0f) + "%", Misc.getRoundedValue(20.0f) + "%", Misc.getRoundedValue(50.0f) + "%", Misc.getRoundedValue(10.0f) + "" });
            tooltip.addPara("- Reduces the peak performance time by a factor of %s. \n- Prevents the use of %s. \n- Limits the range of weaponries to %s or less. \n- The engines will receive %s more damage.", 0.0f, red, new String[] { Misc.getRoundedValue(5.0f) + "", "active venting", Misc.getRoundedValue(600.0f) + "su", Misc.getRoundedValue(10.0f) + "%" });
        }
        else {
            tooltip.addPara("\n- Improved top speed: %s/%s/%s/%s (by hull size) \n- Ballistic and energy damage are increased: %s \n- Reduced weapon recoil: %s \n- Weapon rate of fire increased: %s \n- Increase flux dissipation: %s \n- Increases zero-flux speed bonus: %s flat \n- %s the harmful effects of solar coronas and hyperspace storms.", 0.0f, green, new String[] { Misc.getRoundedValue(30.0f) + "", Misc.getRoundedValue(25.0f) + "", Misc.getRoundedValue(20.0f) + "", Misc.getRoundedValue(15.0f) + "", Misc.getRoundedValue(10.0f) + "%", Misc.getRoundedValue(50.0f) + "%", Misc.getRoundedValue(25.0f) + "%", Misc.getRoundedValue(60.0f) + "%", Misc.getRoundedValue(15.0f) + "", "Halves" });
            tooltip.addPara("- Supply cost is increased: %s \n- Overload duration is increased: %s \n- Reduces the peak performance time by a factor of %s. \n- Prevents the use of %s. \n- Limits the range of weaponries to %s or less. \n- The engines will receive %s more damage. \n- Explodes %s than a comparable hull.", 0.0f, red, new String[] { Misc.getRoundedValue(50.0f) + "%", Misc.getRoundedValue(50.0f) + "%", Misc.getRoundedValue(5.0f) + "", "active venting" , Misc.getRoundedValue(600.0f) + "su", Misc.getRoundedValue(10.0f) + "%", "more violently" });
        }
        final TooltipMakerAPI alert = tooltip.beginImageWithText(Global.getSettings().getSpriteName("tooltips", "warning"), 40f);
        alert.addPara("%s", 0, warning, new String[] { "WARNING! Installation process will consume one Unstable Sigma Matter, once installed it will permanently remove the item from your inventory. Furthermore, removing the hullmod will not return the consumed Sigma Matter."});
        tooltip.addImageWithText(opad);
    }

}