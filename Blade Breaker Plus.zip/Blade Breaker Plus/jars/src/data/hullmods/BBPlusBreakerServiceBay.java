package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;
import java.util.HashSet;
import java.util.Set;

public class BBPlusBreakerServiceBay extends BaseHullMod {
	
    private static final Set<String> BLOCKED_HULLMODS = new HashSet();
    static
    {
        BLOCKED_HULLMODS.add("expanded_deck_crew"); // Just in case you fucks made this boardable
    }
	//private Color color = new Color(0,255,0,255);
    private static final float RATE_DECREASE_MODIFIER = 50f;
    private static final float FIGHTER_REPLACEMENT_RATE_BONUS = 10f;
    private static final float BB_FIGHTER_REPLACEMENT_RATE_BONUS = 15f;
    private static final float COST_REDUCTION_LPC = 2f;
    private static final float REPAIR_BONUS = 30f;
    
    @Override
    public void applyEffectsBeforeShipCreation(final HullSize hullSize, final MutableShipStatsAPI stats, final String id) {
        final float timeMult = 1f / ((100f + FIGHTER_REPLACEMENT_RATE_BONUS) / 100f);
        stats.getDynamic().getMod(Stats.ALL_FIGHTER_COST_MOD).modifyFlat(id, -COST_REDUCTION_LPC);
        stats.getDynamic().getMod(Stats.BOMBER_COST_MOD).modifyFlat(id, -COST_REDUCTION_LPC);
        stats.getDynamic().getMod(Stats.FIGHTER_COST_MOD).modifyFlat(id, -COST_REDUCTION_LPC);
        stats.getDynamic().getMod(Stats.INTERCEPTOR_COST_MOD).modifyFlat(id, -COST_REDUCTION_LPC);
        stats.getDynamic().getMod(Stats.SUPPORT_COST_MOD).modifyFlat(id, -COST_REDUCTION_LPC);
        stats.getCombatEngineRepairTimeMult().modifyMult(id, 1f - REPAIR_BONUS * 0.01f);
        stats.getCombatWeaponRepairTimeMult().modifyMult(id, 1f - REPAIR_BONUS * 0.01f);
        stats.getDynamic().getStat(Stats.REPLACEMENT_RATE_DECREASE_MULT).modifyMult(id, 1f - RATE_DECREASE_MODIFIER / 100f);
        stats.getFighterRefitTimeMult().modifyMult(id, timeMult);
    }

    @Override
    public void applyEffectsAfterShipCreation(final ShipAPI ship, final String id){
        for (final String tmp : BLOCKED_HULLMODS) {
            if (ship.getVariant().getHullMods().contains(tmp)) {                
                ship.getVariant().removeMod(tmp); 
                 DMEBlockedHullmodDisplayScript.showBlocked(ship);
                //ship.getVariant().addMod(ERROR);
            }
        }
    }
	
	//@Override
	//public void applyEffectsToFighterSpawnedByShip(ShipAPI fighter, ShipAPI ship, String id) {
	//	fighter.getEngineController().fadeToOtherColor(this, color, null, 1f, 0.4f);
	//	fighter.getEngineController().extendFlame(this, 0.25f, 0.25f, 0.25f);
	//}

    public void advanceInCombat(final ShipAPI fighter, final ShipAPI ship, final String id) {
        final float timeMult = 1f / ((100f + BB_FIGHTER_REPLACEMENT_RATE_BONUS) / 100f);
		//ShipAPI ship = null;
        final MutableShipStatsAPI stats = ship.getMutableStats();
		//if (stats.getEntity() instanceof ShipAPI) {
		//	ship = (ShipAPI) stats.getEntity();
		//} else {
		//	return;
		//}
		//for (ShipAPI fighter : getFighters(ship)) {
        if (fighter.getVariant().getHullSpec().getHullId().startsWith("bbplus_") ||
            fighter.getVariant().getHullSpec().getHullId().startsWith("istl_")) {
                stats.getDynamic().getStat(Stats.REPLACEMENT_RATE_DECREASE_MULT).modifyMult(id, 1f - RATE_DECREASE_MODIFIER / 100f);
                stats.getFighterRefitTimeMult().modifyMult(id, timeMult);
        }
		//}
			//ship.getEngineController().fadeToOtherColor(this, color, null, 1f, 0.4f);
			//ship.getEngineController().extendFlame(this, 0.25f, 0.25f, 0.25f);
			//fighter.getEngineController().fadeToOtherColor(this, color, null, 1f, 0.4f);
			//fighter.getEngineController().extendFlame(this, 0.25f, 0.25f, 0.25f);
    }
	
    @Override
    public String getDescriptionParam(final int index, final HullSize hullSize) {
        return null;
    }

    @Override
    public boolean affectsOPCosts() {
        return true;
    }
    // As always, this is a fucking built-in but I'll do it anyway
    @Override
    public boolean isApplicableToShip(final ShipAPI ship) {
        return (ship.getHullSpec().getFighterBays() >= 1) &&
        !ship.getVariant().getHullMods().contains("expanded_deck_crew");
    }
	
    @Override
    public String getUnapplicableReason(final ShipAPI ship) {
        if (ship.getHullSpec().getFighterBays() < 1) {
            return "Ship does not have standard fighter bays";
        }
        if (ship.getVariant().hasHullMod("expanded_deck_crew")) {
            return "Incompatible with Expanded Deck Crew"; // Can't have all nice things
        }
        return null;
    }

    @Override
    public void addPostDescriptionSection(final TooltipMakerAPI tooltip, final ShipAPI.HullSize hullSize, final ShipAPI ship, final float width, final boolean isForModSpec) {
        final Color green = new Color(55,245,65,255);
        final float pad = 10f;
        tooltip.addSectionHeading("Incompatibilities", Alignment.MID, pad);
        tooltip.addPara("- %s", pad, Misc.getNegativeHighlightColor(), new String[] { "Expanded Deck Crew" });	
        tooltip.addSectionHeading("Details", Alignment.MID, pad);
        tooltip.addPara("- Reduces the decay of fighter replacement rate due to losses: %s. \n- Increased maximum replacement rate: %s \n- Reduced OP cost to all LPCs: %s", pad, green, new String[] { Misc.getRoundedValue(50.0f) + "%", Misc.getRoundedValue(10.0f) + "%", Misc.getRoundedValue(2.0f) + ""});	
        final TooltipMakerAPI text = tooltip.beginImageWithText(Global.getSettings().getSpriteName("tooltips", "bbfighters"), 44.0f);
        text.addPara("Blade Breaker wings will receive additional %s maximum replacement rate bonus." + "\n", 0, green, new String[] { Misc.getRoundedValue(15.0f) + "%" });		
        tooltip.addImageWithText(pad);		
    }	

}