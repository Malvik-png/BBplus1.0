package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;

public class BBPlusBurstScanner extends BaseHullMod {
    
    private static final float SIGHT_BONUS = 50f;
    //private static final float SENSOR_BONUS = 25f;

    @Override
    public void applyEffectsBeforeShipCreation(final HullSize hullSize, final MutableShipStatsAPI stats, final String id) {
	stats.getSightRadiusMod().modifyPercent(id, SIGHT_BONUS);
	//stats.getSensorStrength().modifyFlat(id, SENSOR_BONUS);
    }

    @Override
    public String getDescriptionParam(final int index, final HullSize hullSize) {
	//if (index == 0) return "" + (int) SIGHT_BONUS + "%";
	//if (index == 1) return "" + (int) SENSOR_BONUS;
        return null;
    }

    @Override
    public void addPostDescriptionSection(final TooltipMakerAPI tooltip, final ShipAPI.HullSize hullSize, final ShipAPI ship, final float width, final boolean isForModSpec) {
        final Color green = new Color(55,245,65,255);
        final Color flavor = new Color(110,110,110,255);
        final float pad = 10f;
        final float padQuote = 6f;
        final float padSig = 1f;
        tooltip.addSectionHeading("Details", Alignment.MID, pad);
        tooltip.addPara("- Increased sight range in combat: %s", pad, green, new String[] { Misc.getRoundedValue(50.0f) + "%" }); //Misc.getRoundedValue(25.0f) + ""		
        tooltip.addPara("%s", padQuote, flavor, new String[] { "\"They always say knowing is half the battle but what is the other half?\"" });
        tooltip.addPara("%s", padSig, flavor, new String[] { "         \u2014 Dassault-Mikoyan Rafale I Pilot" });
    } 

}
