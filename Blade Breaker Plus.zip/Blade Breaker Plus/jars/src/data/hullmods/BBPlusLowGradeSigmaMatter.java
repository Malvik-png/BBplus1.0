package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.CampaignUIAPI.CoreUITradeMode;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.ui.Alignment;
import java.util.HashMap;
import java.util.Map;
import java.awt.Color;
import data.campaign.ids.istl_Commodities;

public class BBPlusLowGradeSigmaMatter extends BaseHullMod {

    private final Color color = new Color(90,210,160,255); // Gonna snort that sigma crack
    private static final String[] ALL_INCOMPAT_IDS = {
        "bbplus_sm_unstable", "bbplus_sm_highgrade", "bbplus_sigmanode",
        "bbplus_sm_unstable_dummy", "bbplus_sm_highgrade_dummy",
        "safetyoverrides", "solar_shielding", "converted_hangar", "roider_fighterClamps"};
    private final String BBreakerENG = "istl_bbengineering";
    private final String BBreakerSPT = "istl_bbsupport";        
    public static final String DATA_PREFIX = "sigma_matter_low_gen_check_";
    public static final String ITEM = istl_Commodities.SIGMA_MATTER_LOW;
    private String[] getIncompatibleIds() {
        if (super.spec.getId().equals("bbplus_sm_lowgrade")) //only one is allowed wtf
                return ALL_INCOMPAT_IDS;
        return null;
    }
    private static final Map range = new HashMap();
       static
       {
            range.put(HullSize.FIGHTER, 0f); //FUCK IRON SHELL
            range.put(HullSize.FRIGATE, 150f); // 150
            range.put(HullSize.DESTROYER, 200f); // 250
            range.put(HullSize.CRUISER, 300f); // 350
            range.put(HullSize.CAPITAL_SHIP, 350f); // 400
        }
    private static final Map bbrange = new HashMap();
        static
        {
            bbrange.put(HullSize.FIGHTER, 0f); //FUCK IRON SHELL MORE
            bbrange.put(HullSize.FRIGATE, 100f);
            bbrange.put(HullSize.DESTROYER, 150f);
            bbrange.put(HullSize.CRUISER, 250f);
            bbrange.put(HullSize.CAPITAL_SHIP, 300f);
        }
    //public static final float WEAPON_HEALTH_BONUS = 80f;
    //public static final float DAMAGE_REDUCTION = 1.25f; //nah, bad idea
    //public static final float HULL_BONUS = 10f;
    //public static final float MSL_BONUS_DAMAGE = 13f;
    public static final float MSL_HEALTH = 15f;
    public static final float MSL_SPEED = 15f;
    public static final float FLUX_BONUS = 1.20f;
    public static final float TURRET_SPEED_BONUS = 60f;
    private static final float AUTOFIRE_BONUS = 30f;
    public static final float PROJ_SPEED_MULT = 1.20f;
	// Pseudo BB Engineering penalties and etc
    private static final float SUPPLY_PENALTY = 1.50f; //just like Sigma Node but since this is the superior version, it is more expensive
    private static final float OVERLOAD_DURATION_MULT = 1.50f; // there's nothing wrong with this, plus it takes 0 OP 
    private static final float ENGINE_DAMAGE = 1.10f; // your trophy is now usable so it's fine (^:
    public static final float EXPLODE_MULT = 1.5f; // E X P L O S I O N
    public static final float EXPLODE_RADIUS_MULT = 0.80f;
    public static final float CORONA_EFFECT_REDUCTION = 0.50f;
    private static final float WEAPON_PENALTY = 1.35f;
	// Lessened bonus for BB ships but the dumb malus is negated with some exceptions
	//public static final float BB_MSL_BONUS_DAMAGE = 10f;
    public static final float BB_MSL_HEALTH = 10f;
    public static final float BB_MSL_SPEED = 10f;
    public static final float BB_FLUX_BONUS = 1.15f;
    public static final float BB_TURRET_SPEED_BONUS = 40f;
    private static final float BB_AUTOFIRE_BONUS = 20f;
    public static final float BB_PROJ_SPEED_MULT = 1.15f;
    //Support Mode
    @Override
    public void applyEffectsBeforeShipCreation(final HullSize hullSize, final MutableShipStatsAPI stats, final String id) {
	//stats.getEnergyDamageTakenMult().modifyMult(id, DAMAGE_REDUCTION);
	//stats.getWeaponHealthBonus().modifyPercent(id, WEAPON_HEALTH_BONUS);
	//>giving weapon health bonus then adding a weapon health penalty at the same time, lol
	//stats.getHullBonus().modifyPercent(id, HULL_BONUS); // nonsense
	// general malus
        stats.getWeaponDamageTakenMult().modifyMult(id, WEAPON_PENALTY); //penalty begins 
        stats.getEngineDamageTakenMult().modifyMult(id, ENGINE_DAMAGE);
        // what a fucking clusterfuck of a hullmod is this
        if (stats.getVariant().hasHullMod("istl_bbengineering")){
            // the BB Engineering-like penalties are negated for BB ships, why would you INCREASE it?
            // think of it as a supplementary sigma battery or some shit ok
            // in return, the benefits of this mod are lessened for BB ships
            stats.getBallisticWeaponRangeBonus().modifyFlat(id, (Float) bbrange.get(hullSize));
            stats.getEnergyWeaponRangeBonus().modifyFlat(id, (Float) bbrange.get(hullSize));
        }
        else {
            stats.getBallisticWeaponRangeBonus().modifyFlat(id, (Float) range.get(hullSize));
            stats.getEnergyWeaponRangeBonus().modifyFlat(id, (Float) range.get(hullSize));
            stats.getSuppliesPerMonth().modifyMult(id, SUPPLY_PENALTY);
            stats.getDynamic().getStat(Stats.CORONA_EFFECT_MULT).modifyMult(id, CORONA_EFFECT_REDUCTION);
        }
    }
	
    @Override
    public void applyEffectsAfterShipCreation(final ShipAPI ship, final String id){
        final MutableShipStatsAPI stats = ship.getMutableStats();
        if (ship.getVariant().hasHullMod("istl_bbengineering")){
            //stats.getMissileWeaponDamageMult().modifyPercent(id, BB_MSL_BONUS_DAMAGE); // maybe in the other hullmods (^=
            stats.getMissileMaxSpeedBonus().modifyPercent(id , BB_MSL_SPEED);
            stats.getMissileAccelerationBonus().modifyPercent(id , BB_MSL_SPEED);
            stats.getMissileMaxTurnRateBonus().modifyPercent(id , BB_MSL_SPEED);
            stats.getMissileTurnAccelerationBonus().modifyPercent(id , BB_MSL_SPEED);
            stats.getMissileHealthBonus().modifyPercent(id, BB_MSL_HEALTH);
            stats.getFluxCapacity().modifyMult(id, BB_FLUX_BONUS);
            stats.getWeaponTurnRateBonus().modifyPercent(id, BB_TURRET_SPEED_BONUS);
            stats.getBeamWeaponTurnRateBonus().modifyPercent(id, BB_TURRET_SPEED_BONUS);
            stats.getAutofireAimAccuracy().modifyFlat(id, BB_AUTOFIRE_BONUS * 0.01f);
            stats.getProjectileSpeedMult().modifyMult(id, BB_PROJ_SPEED_MULT);	
        }
        else {
            //stats.getMissileWeaponDamageMult().modifyPercent(id, MSL_BONUS_DAMAGE);
            stats.getMissileMaxSpeedBonus().modifyPercent(id , MSL_SPEED);
            stats.getMissileAccelerationBonus().modifyPercent(id , MSL_SPEED);
            stats.getMissileMaxTurnRateBonus().modifyPercent(id , MSL_SPEED);
            stats.getMissileTurnAccelerationBonus().modifyPercent(id , MSL_SPEED);
            stats.getMissileHealthBonus().modifyPercent(id, MSL_HEALTH);
            stats.getFluxCapacity().modifyMult(id, FLUX_BONUS);
            stats.getWeaponTurnRateBonus().modifyPercent(id, TURRET_SPEED_BONUS);
            stats.getBeamWeaponTurnRateBonus().modifyPercent(id, TURRET_SPEED_BONUS);
            stats.getAutofireAimAccuracy().modifyFlat(id, AUTOFIRE_BONUS * 0.01f);
            stats.getProjectileSpeedMult().modifyMult(id, PROJ_SPEED_MULT);	
            stats.getOverloadTimeMod().modifyMult(id, OVERLOAD_DURATION_MULT);
            stats.getDynamic().getStat(Stats.EXPLOSION_DAMAGE_MULT).modifyMult(id, EXPLODE_MULT); // boom just like the og
            stats.getDynamic().getStat(Stats.EXPLOSION_RADIUS_MULT).modifyMult(id, EXPLODE_RADIUS_MULT);
        }
        // no stacking of things, fuck off 
        for (final String tmp : ALL_INCOMPAT_IDS) {
            if (ship.getVariant().getHullMods().contains(tmp)) {                
                ship.getVariant().removeMod(tmp);
                DMEBlockedHullmodDisplayScript.showBlocked(ship);
		//ship.getVariant().addMod(ERROR);
            }
        }
    }
	
    @Override
    public boolean isApplicableToShip(final ShipAPI ship) {
        if (ship == null || ship.getVariant() == null)
            return false;
                if (ship.getVariant().getHullMods().contains("bbplus_sm_lowgrade_dummy")) return false;
                if (ship.getVariant().getHullMods().contains("converted_hangar")) return false;
                if (ship.getVariant().getHullMods().contains("safetyoverrides")) return false;
                if (ship.getVariant().getHullMods().contains("solar_shielding")) return false;          
                if (ship.getVariant().getHullMods().contains("bbplus_sigmanode")) return false;
                if (ship.getVariant().getHullMods().contains("roider_fighterClamps")) return false; 
        if (BBPlusSigmaDriveInstaller.listContainsAny(ship.getVariant().getHullMods(), (Object[])ALL_INCOMPAT_IDS))
            return false;       
        return !BBPlusSigmaDriveInstaller.listContainsAny(ship.getVariant().getHullMods(), (Object[])getIncompatibleIds());
    }
    
    @Override
    public String getUnapplicableReason(final ShipAPI ship) {
        if (ship == null || ship.getVariant() == null)
            return "Unable to locate ship!";
                if (ship.getVariant().hasHullMod("bbplus_sm_lowgrade_dummy")) // To avoid fuckery
                    return "Sigma Drive Stabilizer is already installed";
                if (ship.getVariant().hasHullMod("converted_hangar"))
                    return "Incompatible with Converted Hangar";
                if (ship.getVariant().hasHullMod("safetyoverrides"))
                    return "Incompatible with Safety Overrides";
                if (ship.getVariant().hasHullMod("solar_shielding"))
                    return "Incompatible with Solar Shielding";
                if (ship.getVariant().hasHullMod("bbplus_sigmanode"))
                    return "Incompatible with Sigma Node";
                if (ship.getVariant().hasHullMod("roider_fighterClamps"))
                    return "Incompatible with Fighter Clamps";            
        if (BBPlusSigmaDriveInstaller.listContainsAny(ship.getVariant().getHullMods(), (Object[])ALL_INCOMPAT_IDS) ||
            BBPlusSigmaDriveInstaller.listContainsAny(ship.getVariant().getHullMods(), (Object[])getIncompatibleIds()))
            return "Only one type of Sigma Matter can be installed per ship";     
        return ""; //I have to repeat this warning several times for those who doesn't read
    }

    @Override
    public void advanceInCampaign(final FleetMemberAPI member, final float amount) {
        final Map<String, Object> data = Global.getSector().getPersistentData();
        if (data.containsKey(DATA_PREFIX + member.getId())) {
            return;
        }
        BBPlusSigmaDriveInstaller.removePlayerCommodity(ITEM);
        data.put(DATA_PREFIX + member.getId(), "placeholder");
    }

    @Override
    public boolean canBeAddedOrRemovedNow(final ShipAPI ship, final MarketAPI marketOrNull, final CoreUITradeMode mode) {
        final int status = BBPlusSigmaDriveInstaller.isPlayerShip(ship, super.spec.getId());
        if (status == BBPlusSigmaDriveInstaller.NOT_PLAYER) {
            return false;
        }
        if (status != BBPlusSigmaDriveInstaller.HAS_HULLMOD && !BBPlusSigmaDriveInstaller.playerHasCommodity(ITEM)) {
            return false;
        }
        return super.canBeAddedOrRemovedNow(ship, marketOrNull, mode);
    }

    @Override
    public String getCanNotBeInstalledNowReason(final ShipAPI ship, final MarketAPI marketOrNull, final CoreUITradeMode mode) {
        final int status = BBPlusSigmaDriveInstaller.isPlayerShip(ship, super.spec.getId());
        if (status == BBPlusSigmaDriveInstaller.NOT_PLAYER) {
            return "This installation is not applicable to modules";
        }
        if (status != BBPlusSigmaDriveInstaller.HAS_HULLMOD && !BBPlusSigmaDriveInstaller.playerHasCommodity(ITEM)) {
            return "Installation requires [Low-Grade Sigma Matter] (1)";
        }
        return super.getCanNotBeInstalledNowReason(ship, marketOrNull, mode);
    }
   
    @Override
    public void advanceInCombat(final ShipAPI ship, final float amount) {
        //ship.getEngineController().fadeToOtherColor(this, color, null, 1f, 0.4f);
        ship.getEngineController().fadeToOtherColor(this, color, null, 1f, 1f);
        //ship.getEngineController().extendFlame(this, 0.25f, 0.25f, 0.25f);
    }
        
    @Override
    public String getDescriptionParam(final int index, final ShipAPI.HullSize hullSize) {
        //if (index == 0) return "" + "halves";
        if (index == 0) return "" + "varying effects";
        return null;
    }
    //HAVE SEX CRINJPRIEST
    @Override
    public void addPostDescriptionSection(final TooltipMakerAPI tooltip, final ShipAPI.HullSize hullSize, final ShipAPI ship, final float width, final boolean isForModSpec) {
        final Color bbreaker = new Color(155,155,190,255);
        final Color green = new Color(55,245,65,255);
        final Color red = new Color(255,0,0,255);
        final Color sigmadrivestabil = new Color(85,230,170,255);
        final Color warning = new Color (255,80,0,255);
        final float pad = 10f;
        final float opad = 8.0f;
        tooltip.addImage("graphics/tooltips/bbplus_sigmaborder.png", 368f, 8f, 5f);
        TooltipMakerAPI text = tooltip.beginImageWithText(Global.getSettings().getSpriteName("smatters", "lgsigma"), 33.0f);
        text.addPara("If the %s is installed on a Blade Breaker ship, it will provide different effects.", 3.0f, sigmadrivestabil, new String[] { "Low-Grade Sigma Matter" });
        tooltip.addImageWithText(3.0f);
        tooltip.addSectionHeading("Incompatibilities", Alignment.MID, pad);
        tooltip.addPara("- Incompatible with %s, %s, %s, %s", pad, Misc.getNegativeHighlightColor(), new String[] { "Sigma Node", "Safety Overrides", "Solar Shielding", "Converted Hangar" });
        tooltip.addSectionHeading("Details", Alignment.MID, pad);
		// If you view this modspec in your inventory without the null conditions then it will cause CTD so...
		// I need to put this so the game won't shit the bed.
        if (ship == null || ship.getVariant() == null) {
            tooltip.addPara("\n- Increased weapon range: %s/%s/%s/%s units \n- Improved flux capacity: %s \n- Missile durability is increased: %s \n- Improved missile speed: %s \n- Projectile speed increased: %s \n- Turret turn rate increased: %s \n- Improved leading accuracy of weapons: %s \n- %s the harmful effects of solar coronas and hyperspace storms.", pad, green, new String[] { Misc.getRoundedValue(150.0f) + "", Misc.getRoundedValue(200.0f) + "", Misc.getRoundedValue(300.0f) + "", Misc.getRoundedValue(350.0f) + "", Misc.getRoundedValue(20.0f) + "%", Misc.getRoundedValue(15.0f) + "%" , Misc.getRoundedValue(15.0f) + "%" , Misc.getRoundedValue(20.0f) + "%" , Misc.getRoundedValue(60.0f) + "%" , Misc.getRoundedValue(30.0f) + "%", "Halves" });
            tooltip.addPara("- Supply cost is increased: %s \n- Overload duration is increased: %s \n- Weapons on your ship take %s more damage. \n- The engines will receive %s more damage. \n- Explodes %s than a comparable hull.", 0.0f, red, new String[] { Misc.getRoundedValue(50.0f) + "%", Misc.getRoundedValue(50.0f) + "%", Misc.getRoundedValue(35.0f) + "%" , Misc.getRoundedValue(10.0f) + "%", "more violently" });
        }
        else if (ship.getVariant().hasHullMod("istl_bbengineering") && ship.getVariant().hasHullMod("istl_bbsupport")) {
            text = tooltip.beginImageWithText(Global.getSettings().getHullModSpec(BBreakerSPT).getSpriteName(), 36f);
            text.addPara("A %s ship with %s is detected, further adjustment to bonuses are applied.", 0, bbreaker, new String[] { "Blade Breaker", "Breaker Support" });
            tooltip.addImageWithText(pad);
            tooltip.addPara("\n- Improved flux capacity: %s \n- Missile durability is increased: %s \n- Improved missile speed: %s \n- Projectile speed increased: %s \n- Turret turn rate increased: %s \n- Improved leading accuracy of weapons: %s", 0.0f, green, new String[] { Misc.getRoundedValue(15.0f) + "%", Misc.getRoundedValue(10.0f) + "%" , Misc.getRoundedValue(10.0f) + "%" , Misc.getRoundedValue(15.0f) + "%" , Misc.getRoundedValue(40.0f) + "%" , Misc.getRoundedValue(20.0f) + "%" });
            tooltip.addPara("- The engines will receive %s more damage. \n- Weapons on your ship take %s more damage.", 0.0f, red, new String[] { Misc.getRoundedValue(10.0f) + "%", Misc.getRoundedValue(35.0f) + "%" });
        }
        else if (ship.getVariant().hasHullMod("istl_bbengineering")) {
            text = tooltip.beginImageWithText(Global.getSettings().getHullModSpec(BBreakerENG).getSpriteName(), 36f);
            text.addPara("A %s ship is detected, certain negative effects are negated and overall bonus are reduced.", 0.0f, bbreaker, new String[] {"Blade Breaker"});
            tooltip.addImageWithText(pad);
            tooltip.addPara("\n- Increased weapon range: %s/%s/%s/%s units \n- Improved flux capacity: %s \n- Missile durability is increased: %s \n- Improved missile speed: %s \n- Projectile speed increased: %s \n- Turret turn rate increased: %s \n- Improved leading accuracy of weapons: %s", 0.0f, green, new String[] { Misc.getRoundedValue(100.0f) + "", Misc.getRoundedValue(150.0f) + "", Misc.getRoundedValue(250.0f) + "", Misc.getRoundedValue(300.0f) + "", Misc.getRoundedValue(15.0f) + "%", Misc.getRoundedValue(10.0f) + "%" , Misc.getRoundedValue(10.0f) + "%" , Misc.getRoundedValue(15.0f) + "%" , Misc.getRoundedValue(40.0f) + "%" , Misc.getRoundedValue(20.0f) + "%" });
            tooltip.addPara("- The engines will receive %s more damage. \n- Weapons on your ship take %s more damage.", 0.0f, red, new String[] { Misc.getRoundedValue(10.0f) + "%", Misc.getRoundedValue(35.0f) + "%" });
        }
        else {
            tooltip.addPara("\n- Increased weapon range: %s/%s/%s/%s units \n- Improved flux capacity: %s \n- Missile durability is increased: %s \n- Improved missile speed: %s \n- Projectile speed increased: %s \n- Turret turn rate increased: %s \n- Improved leading accuracy of weapons: %s \n- %s the harmful effects of solar coronas and hyperspace storms.", 0.0f, green, new String[] { Misc.getRoundedValue(150.0f) + "", Misc.getRoundedValue(200.0f) + "", Misc.getRoundedValue(300.0f) + "", Misc.getRoundedValue(350.0f) + "", Misc.getRoundedValue(20.0f) + "%", Misc.getRoundedValue(15.0f) + "%" , Misc.getRoundedValue(15.0f) + "%" , Misc.getRoundedValue(20.0f) + "%" , Misc.getRoundedValue(60.0f) + "%" , Misc.getRoundedValue(30.0f) + "%", "Halves" });
            tooltip.addPara("- Supply cost is increased: %s \n- Overload duration is increased: %s \n- Weapons on your ship take %s more damage. \n- The engines will receive %s more damage. \n- Explodes %s than a comparable hull.", 0.0f, red, new String[] { Misc.getRoundedValue(50.0f) + "%", Misc.getRoundedValue(50.0f) + "%", Misc.getRoundedValue(35.0f) + "%" , Misc.getRoundedValue(10.0f) + "%", "more violently" });
        }		
        final TooltipMakerAPI alert = tooltip.beginImageWithText(Global.getSettings().getSpriteName("tooltips", "warning"), 40f);
        alert.addPara("%s", 0, warning, new String[] { "WARNING! Installation process will consume one Low-Grade Sigma Matter, once installed it will permanently remove the item from your inventory. Furthermore, removing the hullmod will not return the consumed Sigma Matter."});
        tooltip.addImageWithText(opad);
    }

}