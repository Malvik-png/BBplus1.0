package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.util.Misc;
import java.util.HashSet;
import java.util.Set;
import java.awt.Color;

public class BBPlusSoulBreakProtocol extends BaseHullMod {

    private static final Set<String> BLOCKED_HULLMODS = new HashSet();
    static
        {
            BLOCKED_HULLMODS.add("expanded_deck_crew"); // Oh no no no no
        }
    //private float check = 0;
    //private String ID, ERROR = "IncompatibleHullmodWarning";
    private static final float BONUS_DAMAGE = 6f;
    private static final float WEAPON_DAMAGE_BONUS = 10f;
    private static final float MANEUVER_BONUS = 12f;	
    private static final float PROJECTILE_SPEED_BONUS = 14f;	
    private static final float REFIT_MALUS = 20f;
    private static final float OVERLOAD_DUR_MULT = 1.18f;
    public static final float COST_REDUCTION_WINGS = 2f;
        
    @Override
    public void applyEffectsBeforeShipCreation(final HullSize hullSize, final MutableShipStatsAPI stats, final String id) {
        stats.getDynamic().getMod(Stats.ALL_FIGHTER_COST_MOD).modifyFlat(id, -COST_REDUCTION_WINGS); // Let the bullshitry begins
        stats.getDynamic().getMod(Stats.FIGHTER_COST_MOD).modifyFlat(id, -COST_REDUCTION_WINGS);
        stats.getDynamic().getMod(Stats.INTERCEPTOR_COST_MOD).modifyFlat(id, -COST_REDUCTION_WINGS);
        stats.getDynamic().getMod(Stats.BOMBER_COST_MOD).modifyFlat(id, -COST_REDUCTION_WINGS);
        stats.getDynamic().getMod(Stats.SUPPORT_COST_MOD).modifyFlat(id, -COST_REDUCTION_WINGS);
        stats.getFighterRefitTimeMult().modifyPercent(id, +REFIT_MALUS); // Oh look at that, a setback lmoa xddDd
    }
	
    @Override
    public void applyEffectsToFighterSpawnedByShip(final ShipAPI fighter, final ShipAPI ship, final String id) {
        fighter.getMutableStats().getAcceleration().modifyMult(id, 1f + MANEUVER_BONUS * 0.01f); // Ever wonder why
        fighter.getMutableStats().getDeceleration().modifyMult(id, 1f + MANEUVER_BONUS * 0.01f);
        fighter.getMutableStats().getTurnAcceleration().modifyMult(id, 1f + MANEUVER_BONUS * 0.01f);
        fighter.getMutableStats().getMaxTurnRate().modifyMult(id, 1f + MANEUVER_BONUS * 0.01f);
        fighter.getMutableStats().getMaxSpeed().modifyMult(id, 1f + MANEUVER_BONUS * 0.01f);
        fighter.getMutableStats().getProjectileSpeedMult().modifyPercent(id, PROJECTILE_SPEED_BONUS); // I am doing this shit
        fighter.getMutableStats().getEnergyWeaponDamageMult().modifyMult(id, 1f + WEAPON_DAMAGE_BONUS * 0.01f);
        fighter.getMutableStats().getBallisticWeaponDamageMult().modifyMult(id, 1f + WEAPON_DAMAGE_BONUS * 0.01f);
        fighter.getMutableStats().getMissileWeaponDamageMult().modifyMult(id, 1f + WEAPON_DAMAGE_BONUS * 0.01f);
        fighter.getMutableStats().getDamageToFrigates().modifyMult(id, 1f + BONUS_DAMAGE * 0.01f); // Have sex, that's why
        fighter.getMutableStats().getDamageToDestroyers().modifyMult(id, 1f + BONUS_DAMAGE * 0.01f);
        fighter.getMutableStats().getDamageToCruisers().modifyMult(id, 1f + BONUS_DAMAGE * 0.01f);
        fighter.getMutableStats().getDamageToCapital().modifyMult(id, 1f + BONUS_DAMAGE * 0.01f);
        fighter.getMutableStats().getDamageToFighters().modifyMult(id, 1f + BONUS_DAMAGE * 0.01f); // ...and I like Yukikaze, the chinese cartoon
        fighter.getMutableStats().getOverloadTimeMod().modifyMult(id, OVERLOAD_DUR_MULT); //more penalty ok
    }

    @Override
    public String getDescriptionParam(final int index, final HullSize hullSize) {
        return null;
    }

    @Override
    public void applyEffectsAfterShipCreation(final ShipAPI ship, final String id){
        for (final String tmp : BLOCKED_HULLMODS) {
            if (ship.getVariant().getHullMods().contains(tmp)) {                
                ship.getVariant().removeMod(tmp); 
                DMEBlockedHullmodDisplayScript.showBlocked(ship);
                //ship.getVariant().addMod(ERROR);
            }
        }
    }

    @Override
    public boolean affectsOPCosts() {
        return true;
    }
    // it's a fucking built-in but okay
    @Override
    public boolean isApplicableToShip(final ShipAPI ship) {
        return (ship.getHullSpec().getFighterBays() >= 1) &&
               !ship.getVariant().getHullMods().contains("expanded_deck_crew"); //look if you want more OP bullshit just win this ship from !jalter
    }                                                                           //then slap a sigma drive

    @Override
    public String getUnapplicableReason(final ShipAPI ship) {
        if (ship.getHullSpec().getFighterBays() < 1) {
            return "Ship does not have standard fighter bays";
        }
        if (ship.getVariant().hasHullMod("expanded_deck_crew")) {
            return "The ship's fighter manufactories are already operating in highest output and unable to accept further modifications."; // Can't have all nice things
        }
        return null;
    }

    @Override
    public void addPostDescriptionSection(final TooltipMakerAPI tooltip, final ShipAPI.HullSize hullSize, final ShipAPI ship, final float width, final boolean isForModSpec) {
        final Color green = new Color(55,245,65,255);
        final Color red = new Color(255,0,0,255);
        final Color flavor = new Color(110,110,110,255);
        final float pad = 10f;
        final float padList = 0.0f;
        final float padQuote = 6f;
        final float padSig = 1f;
        tooltip.addSectionHeading("Incompatibilities", Alignment.MID, pad);
        tooltip.addPara("- %s", pad, Misc.getNegativeHighlightColor(), new String[] { "Expanded Deck Crew" });	
        tooltip.addSectionHeading("Details", Alignment.MID, pad);
        tooltip.addPara("- Increased fighter maneuverabilty: %s \n- Increased fighter projectile firing speed: %s \n- Increased fighter weapon damage(all): %s \n- Amplified damage to all size of hull: %s \n- All variations of LPCs receive reduced %s OP cost.", pad, green, new String[] { Misc.getRoundedValue(12.0f) + "%", Misc.getRoundedValue(14.0f) + "%", Misc.getRoundedValue(10.0f) + "%", Misc.getRoundedValue(6.0f) + "%", Misc.getRoundedValue(2.0f) + "" });		
        tooltip.addPara("- Decreased fighter rate of recovery: %s \n- Increased fighter overload duration: %s", padList, red, new String[] { Misc.getRoundedValue(20.0f) + "%", Misc.getRoundedValue(18.0f) + "%" });			 	
        tooltip.addPara("%s", padQuote, flavor, new String[] { "\"Her insurrection were indeed unexpected and terrible. Claire did really played us like a damn fiddle.\"" });
        tooltip.addPara("%s", padSig, flavor, new String[] { "         \u2014 Sixth Bureau Inspecteur Principal" }); 
    }	

}