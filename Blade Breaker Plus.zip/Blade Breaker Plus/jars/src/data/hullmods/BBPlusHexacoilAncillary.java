package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;

public class BBPlusHexacoilAncillary extends BaseHullMod {
	
    public static final float VENT_BONUS = 10f;
    public static final float HEALTH_BONUS = 50f;
    public static final float DEGRADE_INCREASE_PERCENT = 50f; // Delicate Machineries my ass
	
    @Override
    public void applyEffectsBeforeShipCreation(final HullSize hullSize, final MutableShipStatsAPI stats, final String id) {
        stats.getVentRateMult().modifyPercent(id, VENT_BONUS);
        stats.getWeaponHealthBonus().modifyPercent(id, HEALTH_BONUS);
        stats.getCRLossPerSecondPercent().modifyPercent(id, DEGRADE_INCREASE_PERCENT);
    }
	
    @Override
    public String getDescriptionParam(final int index, final HullSize hullSize) {
       return null;
    }

    @Override
    public boolean isApplicableToShip(final ShipAPI ship) {
       return ship != null && (ship.getHullSpec().getNoCRLossTime() < 10000 || ship.getHullSpec().getCRLossPerSecond() > 0); 
    }
        
    @Override
    public void addPostDescriptionSection(final TooltipMakerAPI tooltip, final ShipAPI.HullSize hullSize, final ShipAPI ship, final float width, final boolean isForModSpec) {
       final Color green = new Color(55,245,65,255);
       final Color red = new Color(255,0,0,255);
       final Color flavor = new Color(110,110,110,255);
       final float pad = 10f;
       final float padNeg = 0.0f;
       final float padQuote = 6f;
       final float padSig = 1f;
       tooltip.addSectionHeading("Details", Alignment.MID, pad);
       tooltip.addPara("- Improved active vent rate: %s \n- Increased weapon health: %s", pad, green, new String[] { Misc.getRoundedValue(10.0f) + "%", Misc.getRoundedValue(50.0f) + "%"});		
       tooltip.addPara("- Increased CR decay after PPT expires: %s", padNeg, red, new String[] { Misc.getRoundedValue(50.0f) + "%" });
       tooltip.addPara("%s", padQuote, flavor, new String[] { "\"The pay I get from fiddling these things aren't justified. You know being in this job makes you wish for another AI War.\"" });
       tooltip.addPara("%s", padSig, flavor, new String[] { "         \u2014 SNRI lab scientist data logs ~c201" });                 
    }

}