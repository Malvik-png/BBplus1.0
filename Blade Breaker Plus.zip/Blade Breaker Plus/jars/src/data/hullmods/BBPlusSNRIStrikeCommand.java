package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;
import data.campaign.ids.bbplus_HullMods;

public class BBPlusSNRIStrikeCommand extends BaseHullMod {
    // The old carrier officer skill is now a hullmod!? WOW!
    // Only for BB/DME ships LOL!
    private static final String[] ALL_INCOMPAT_IDS = {"bbplus_snri_carrier_command", "bbplus_snri_wing_command", "expanded_deck_crew"};
    public static final float MISSILE_SPEED_BONUS = 25f;
    public static final float MISSILE_RANGE_MULT = 0.8f;
    public static final float MISSILE_HITPOINTS_BONUS = 50f;
    public static final float STRIKE_DAMAGE_BONUS = 10f; //from 20f - feels like it's too much
	   
    @Override
    public void applyEffectsToFighterSpawnedByShip(final ShipAPI fighter, final ShipAPI ship, final String id) {
        fighter.getMutableStats().getMissileMaxSpeedBonus().modifyPercent(id, MISSILE_SPEED_BONUS);
        fighter.getMutableStats().getMissileTurnAccelerationBonus().modifyPercent(id, MISSILE_SPEED_BONUS);                        	
        fighter.getMutableStats().getMissileAccelerationBonus().modifyPercent(id, MISSILE_SPEED_BONUS);
        fighter.getMutableStats().getMissileMaxTurnRateBonus().modifyPercent(id, MISSILE_SPEED_BONUS * 2f);
        fighter.getMutableStats().getMissileWeaponRangeBonus().modifyMult(id, MISSILE_RANGE_MULT);
        fighter.getMutableStats().getMissileHealthBonus().modifyPercent(id, MISSILE_HITPOINTS_BONUS);
        fighter.getMutableStats().getDamageToDestroyers().modifyPercent(id, STRIKE_DAMAGE_BONUS);
        fighter.getMutableStats().getDamageToCruisers().modifyPercent(id, STRIKE_DAMAGE_BONUS);
        fighter.getMutableStats().getDamageToCapital().modifyPercent(id, STRIKE_DAMAGE_BONUS);            
    }
        
    @Override
    public void applyEffectsAfterShipCreation(final ShipAPI ship, final String id){
        for (final String tmp : ALL_INCOMPAT_IDS) {
            if (ship.getVariant().getHullMods().contains(tmp)) {                
                ship.getVariant().removeMod(tmp);
                DMEBlockedHullmodDisplayScript.showBlocked(ship);
                //ship.getVariant().addMod(ERROR);
            }
        }
    }
        
    @Override
    public String getDescriptionParam(final int index, final HullSize hullSize) {
        if (index == 0) {
            return "one";
        }
        return null;
    }
	
    @Override
    public boolean isApplicableToShip(final ShipAPI ship) {
        if (ship == null || ship.getVariant() == null)
            return false;
                if (shipHasOtherModInCategory(ship, spec.getId(), bbplus_HullMods.BBPLUS_TAG_SNRI_PACKAGE)) return false;            
                if (ship.getVariant().getHullMods().contains("istl_bbengineering") && (ship.getHullSpec().getFighterBays() >= 1)) return true;
                if (ship.getVariant().getHullMods().contains("istl_monobloc_ca") && (ship.getHullSpec().getFighterBays() >= 1)) return true;
                if (ship.getVariant().getHullMods().contains("istl_monobloc") && (ship.getHullSpec().getFighterBays() >= 1)) return true;
                if (ship.getVariant().getHullMods().contains("istl_6eme_upgr") && (ship.getHullSpec().getFighterBays() >= 1)) return true;
                if (ship.getVariant().getHullMods().contains("istl_refurbframe") && (ship.getHullSpec().getFighterBays() >= 1)) return true;                    
                if (ship.getVariant().getHullMods().contains("expanded_deck_crew")) return false;
        if (!ship.getVariant().hasHullMod("istl_bbengineering") ||
            !ship.getVariant().hasHullMod("istl_monobloc_ca") ||
            !ship.getVariant().hasHullMod("istl_monobloc") ||
            !ship.getVariant().hasHullMod("istl_6eme_upgr") ||
            !ship.getVariant().hasHullMod("istl_refurbframe")) {
            return false;
        }                   
        return super.isApplicableToShip(ship);
    }
           
    @Override
    public String getUnapplicableReason(final ShipAPI ship) {
        if (shipHasOtherModInCategory(ship, spec.getId(), bbplus_HullMods.BBPLUS_TAG_SNRI_PACKAGE)) {
            return "Only one type of SNRI Labs hullmod can be installed per ship";
        }              
        if (ship == null || ship.getVariant() == null)
            return "Unable to locate ship!";
                if (ship.getVariant().hasHullMod("expanded_deck_crew"))
                    return "Incompatible with Expanded Deck Crew";                
                if (ship.getHullSpec().getFighterBays() < 1) {
                    return "Ship does not have standard fighter bays";
                }                    
        if (!ship.getVariant().hasHullMod("istl_bbengineering") ||
            !ship.getVariant().hasHullMod("istl_monobloc_ca") ||
            !ship.getVariant().hasHullMod("istl_monobloc") ||
            !ship.getVariant().hasHullMod("istl_6eme_upgr") ||
            !ship.getVariant().hasHullMod("istl_refurbframe")) {
            return "Only applicable on DME and Blade Breaker hulls with standard fighter bays";
        }       
        return super.getUnapplicableReason(ship);
    }
              
    @Override
    public void addPostDescriptionSection(final TooltipMakerAPI tooltip, final ShipAPI.HullSize hullSize, final ShipAPI ship, final float width, final boolean isForModSpec) {
        final Color green = new Color(55,245,65,255);
        final Color flavor = new Color(110,110,110,255);
        final float pad = 10f;
        final float padQuote = 6f;
        final float padSig = 1f;
        tooltip.addSectionHeading("Incompatibilities", Alignment.MID, pad);
        tooltip.addPara("- Incompatible with %s, %s, %s", pad, Misc.getNegativeHighlightColor(), new String[] { "SNRI Carrier Command", "SNRI Wing Command", "Expanded Deck Crew" });             
        tooltip.addSectionHeading("Details", Alignment.MID, pad);
        tooltip.addPara("- Increased fighter's missile speed: %s \n- Increased fighter's missile maneuverability: %s \n- Increased fighter's missile health: %s \n- Increased fighter's damage to ships: %s", pad, green, new String[] { MISSILE_SPEED_BONUS  + "%", MISSILE_SPEED_BONUS + "%", MISSILE_HITPOINTS_BONUS + "%",  STRIKE_DAMAGE_BONUS + "%" });
        tooltip.addPara("%s", padQuote, flavor, new String[] { "\"I know this way of doing things is... So tell me. Tell me how to destroy the depths of these systems.\"" });
        tooltip.addPara("%s", padSig, flavor, new String[] { "         \u2014 Nikolaev Revolutionary Council Member" });                
    }

}