package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;
import data.campaign.ids.bbplus_HullMods;

public class BBPlusSNRICarrierCommand extends BaseHullMod {
    // The old carrier officer skill is now a hullmod!? WOW!
    // Only for BB/DME ships LOL!
    private static final String[] ALL_INCOMPAT_IDS = {"bbplus_snri_strike_command", "bbplus_snri_wing_command", "expanded_deck_crew"};
    public static final float FIGHTER_CREW_LOSS_REDUCTION = 20f;
    public static final float FIGHTER_DAMAGE_REDUCTION = 20f;
    public static final float FIGHTER_REPLACEMENT_RATE_BONUS = 20f;
    public static final float FIGHTER_RANGE_BONUS = 10f;
    
    @Override
    public void applyEffectsBeforeShipCreation(final HullSize hullSize, final MutableShipStatsAPI stats, final String id) {
        final float timeMult = 1f / ((100f + FIGHTER_REPLACEMENT_RATE_BONUS) / 100f);
        stats.getFighterRefitTimeMult().modifyMult(id, timeMult);
        stats.getDynamic().getStat(Stats.FIGHTER_CREW_LOSS_MULT).modifyMult(id, 1f - FIGHTER_CREW_LOSS_REDUCTION / 100f);
        stats.getFighterWingRange().modifyPercent(id, FIGHTER_RANGE_BONUS);
    }

    @Override
    public void applyEffectsToFighterSpawnedByShip(final ShipAPI fighter, final ShipAPI ship, final String id) {
        fighter.getMutableStats().getHullDamageTakenMult().modifyMult(id, 1f - FIGHTER_DAMAGE_REDUCTION / 100f);
        fighter.getMutableStats().getArmorDamageTakenMult().modifyMult(id, 1f - FIGHTER_DAMAGE_REDUCTION / 100f);
        fighter.getMutableStats().getShieldDamageTakenMult().modifyMult(id, 1f - FIGHTER_DAMAGE_REDUCTION / 100f);            
   }

    @Override
    public void applyEffectsAfterShipCreation(final ShipAPI ship, final String id){
        for (final String tmp : ALL_INCOMPAT_IDS) {
            if (ship.getVariant().getHullMods().contains(tmp)) {                
                ship.getVariant().removeMod(tmp);
                DMEBlockedHullmodDisplayScript.showBlocked(ship);
                //ship.getVariant().addMod(ERROR);
            }
        }
    }        
        
    @Override
    public String getDescriptionParam(final int index, final HullSize hullSize) {
        if (index == 0) {
            return "one";
        }
        return null;
    }
	
    @Override
    public boolean isApplicableToShip(final ShipAPI ship) {
        if (ship == null || ship.getVariant() == null)
            return false;
                if (shipHasOtherModInCategory(ship, spec.getId(), bbplus_HullMods.BBPLUS_TAG_SNRI_PACKAGE)) return false;
                if (ship.getVariant().getHullMods().contains("istl_bbengineering") && (ship.getHullSpec().getFighterBays() >= 1)) return true;
                if (ship.getVariant().getHullMods().contains("istl_monobloc_ca") && (ship.getHullSpec().getFighterBays() >= 1)) return true;
                if (ship.getVariant().getHullMods().contains("istl_monobloc") && (ship.getHullSpec().getFighterBays() >= 1)) return true;
                if (ship.getVariant().getHullMods().contains("istl_6eme_upgr") && (ship.getHullSpec().getFighterBays() >= 1)) return true;
                if (ship.getVariant().getHullMods().contains("istl_refurbframe") && (ship.getHullSpec().getFighterBays() >= 1)) return true;                    
                if (ship.getVariant().getHullMods().contains("expanded_deck_crew")) return false;
        if (!ship.getVariant().hasHullMod("istl_bbengineering") ||
            !ship.getVariant().hasHullMod("istl_monobloc_ca") ||
            !ship.getVariant().hasHullMod("istl_monobloc") ||
            !ship.getVariant().hasHullMod("istl_6eme_upgr") ||
            !ship.getVariant().hasHullMod("istl_refurbframe")) {
            return false;
        }                    
        return super.isApplicableToShip(ship);
    }
	
    @Override
    public String getUnapplicableReason(final ShipAPI ship) {
        if (shipHasOtherModInCategory(ship, spec.getId(), bbplus_HullMods.BBPLUS_TAG_SNRI_PACKAGE)) {
            return "Only one type of SNRI Labs hullmod can be installed per ship";
        }              
        if (ship == null || ship.getVariant() == null)
            return "Unable to locate ship!";
                if (ship.getVariant().hasHullMod("expanded_deck_crew"))
                    return "Incompatible with Expanded Deck Crew";                     
                if (ship.getHullSpec().getFighterBays() < 1) {
                    return "Ship does not have standard fighter bays";
                }                    
                if (!ship.getVariant().hasHullMod("istl_bbengineering") ||
                    !ship.getVariant().hasHullMod("istl_monobloc_ca") ||
                    !ship.getVariant().hasHullMod("istl_monobloc") ||
                    !ship.getVariant().hasHullMod("istl_6eme_upgr") ||
                    !ship.getVariant().hasHullMod("istl_refurbframe")) {
                    return "Only applicable on DME and Blade Breaker hulls with standard fighter bays";
                }                    
        return super.getUnapplicableReason(ship);     
    }

    @Override
    public void addPostDescriptionSection(final TooltipMakerAPI tooltip, final ShipAPI.HullSize hullSize, final ShipAPI ship, final float width, final boolean isForModSpec) {
        final Color green = new Color(55,245,65,255);
        final Color flavor = new Color(110,110,110,255);
        final float pad = 10f;
        final float padQuote = 6f;
        final float padSig = 1f;
        tooltip.addSectionHeading("Incompatibilities", Alignment.MID, pad);
        tooltip.addPara("- Incompatible with %s, %s, %s", pad, Misc.getNegativeHighlightColor(), new String[] { "SNRI Strike Command", "SNRI Wing Command", "Expanded Deck Crew" });               
        tooltip.addSectionHeading("Details", Alignment.MID, pad);
        tooltip.addPara("- Increased fighter replacement rate: %s \n- Fighters takes reduced damage: -%s \n- Reduced fighter crew casualties: -%s \n- Increased fighter engagement range: %s", pad, green, new String[] { FIGHTER_REPLACEMENT_RATE_BONUS  + "%", FIGHTER_DAMAGE_REDUCTION + "%",  FIGHTER_CREW_LOSS_REDUCTION + "%", FIGHTER_RANGE_BONUS + "%" });		
        tooltip.addPara("%s", padQuote, flavor, new String[] { "\"The grim reaper won't come when you're ready for him.\"" });
        tooltip.addPara("%s", padSig, flavor, new String[] { "         \u2014 Inspecteur Divisionnaire Claire de'Lunne" });
    }

}