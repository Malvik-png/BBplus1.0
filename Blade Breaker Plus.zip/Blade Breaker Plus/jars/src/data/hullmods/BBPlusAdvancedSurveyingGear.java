package data.hullmods;

import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.impl.hullmods.BaseLogisticsHullMod;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;
import java.util.HashMap;
import java.util.Map;
import java.util.HashSet;
import java.util.Set;

public class BBPlusAdvancedSurveyingGear extends BaseLogisticsHullMod {
    
    private static final Set<String> BLOCKED_HULLMODS = new HashSet();
    static
    {
        BLOCKED_HULLMODS.add("surveying_equipment"); // no stacking fucko
    }
    private static final Map mag = new HashMap();
    static
    {
        mag.put(HullSize.FRIGATE, 10f);
        mag.put(HullSize.DESTROYER, 20f);
        mag.put(HullSize.CRUISER, 30f);
        mag.put(HullSize.CAPITAL_SHIP, 40f);
    }

    @Override
    public void applyEffectsBeforeShipCreation(final HullSize hullSize, final MutableShipStatsAPI stats, final String id) {
        stats.getDynamic().getMod(Stats.getSurveyCostReductionId(Commodities.HEAVY_MACHINERY)).modifyFlat(id, (Float) mag.get(hullSize));
        stats.getDynamic().getMod(Stats.getSurveyCostReductionId(Commodities.SUPPLIES)).modifyFlat(id, (Float) mag.get(hullSize));
    }
	
    @Override
    public void applyEffectsAfterShipCreation(final ShipAPI ship, final String id){
        for (final String tmp : BLOCKED_HULLMODS) {
            if (ship.getVariant().getHullMods().contains(tmp)) {                
                ship.getVariant().removeMod(tmp);
                DMEBlockedHullmodDisplayScript.showBlocked(ship);
            }
        }
    }
	
    @Override
    public String getDescriptionParam(final int index, final HullSize hullSize) {
        return null;
    }

    @Override
    public boolean isApplicableToShip(final ShipAPI ship) {
        return ship != null && (!ship.getVariant().getHullMods().contains("surveying_equipment"));
    }
    
    @Override
    public String getUnapplicableReason(final ShipAPI ship) {
	if (ship.getVariant().hasHullMod("surveying_equipment")) {
            return "Incompatible with Surveying Equipment";
        }
        return null;
    }
	
    @Override
    public void addPostDescriptionSection(final TooltipMakerAPI tooltip, final ShipAPI.HullSize hullSize, final ShipAPI ship, final float width, final boolean isForModSpec) {
        final Color green = new Color(55,245,65,255);
        final float pad = 10f;		
        tooltip.addSectionHeading("Incompatibilities", Alignment.MID, pad);
        tooltip.addPara("- %s", pad, Misc.getNegativeHighlightColor(), new String[] { "Surveying Equipment" });	
        tooltip.addSectionHeading("Details", Alignment.MID, pad);
        tooltip.addPara("- Reduces %s/%s/%s/%s heavy machinery and supply requirements depending on hull size, down to a minimum of %s for each.", pad, green, new String[] { Misc.getRoundedValue(10.0f) + "", Misc.getRoundedValue(20.0f) + "", Misc.getRoundedValue(30.0f) + "", Misc.getRoundedValue(40.0f) + "", Misc.getRoundedValue(5.0f) + ""});		
    }
    
}