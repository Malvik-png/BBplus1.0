package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;
import java.util.HashSet;
import java.util.Set;

public class BBPlusWeaponControl extends BaseHullMod {
    //special built-in for certain Blade Breaker/Deserter ships
    private static final Set<String> BLOCKED_HULLMODS = new HashSet();
    static
    {
        BLOCKED_HULLMODS.add("pointdefenseai"); // proto-Sigma Core AI is possesive, doesn't want another weapon AI guide in your ship
        BLOCKED_HULLMODS.add("swp_gunneryai"); // never incur the wrath of a yandere AI or else you will end up stuck in a tube
    }
    public static final float DAMAGE_BONUS = 50f;
    public static final float AUTOFIRE_BONUS = 70f;
	
    @Override
    public void applyEffectsBeforeShipCreation(final HullSize hullSize, final MutableShipStatsAPI stats, final String id) {
        stats.getAutofireAimAccuracy().modifyFlat(id, AUTOFIRE_BONUS * 0.01f); //pls use BB ships
        stats.getDynamic().getMod(Stats.PD_IGNORES_FLARES).modifyFlat(id, 1f);
        stats.getDynamic().getMod(Stats.PD_BEST_TARGET_LEADING).modifyFlat(id, 1f);
        stats.getDamageToMissiles().modifyPercent(id, DAMAGE_BONUS);
        stats.getDamageToFighters().modifyPercent(id, DAMAGE_BONUS);
    }
	
    @Override
    public void applyEffectsAfterShipCreation(final ShipAPI ship, final String id){
        for (final String tmp : BLOCKED_HULLMODS) {
            if (ship.getVariant().getHullMods().contains(tmp)) {                
                ship.getVariant().removeMod(tmp);
                DMEBlockedHullmodDisplayScript.showBlocked(ship);
                //ship.getVariant().addMod(ERROR);
            }
        }
    }

    @Override
    public boolean isApplicableToShip(final ShipAPI ship) {
	//if (ship.getVariant().getHullMods().contains("pointdefenseai")) return false;
        //return ship != null && (!ship.getVariant().getHullMods().contains("istl_bbengineering"));
	//return !ship.getVariant().getHullMods().contains("swp_gunneryai");
        return ship != null && (ship.getVariant().getHullMods().contains("pointdefenseai")
            && (!(ship.getVariant().getHullMods().contains("swp_gunneryai"))
        ));
    }
    
    @Override
    public String getUnapplicableReason(final ShipAPI ship) {
        if (ship.getVariant().hasHullMod("pointdefenseai"))
            return "Incompatible with Integrated Point Defense AI"; //begone thots
        if (ship.getVariant().hasHullMod("swp_gunneryai")) //only one wAIfu is allowed!
            return "Incompatible with Gunnery Control AI";
        return null;
    }	

    @Override
    public String getDescriptionParam(final int index, final HullSize hullSize) {
        //if (index == 0) return "" + (int) AUTOFIRE_BONUS + "%";
        //if (index == 1) return "" + (int) DAMAGE_BONUS + "%";
        //if (index == 2) return "" + "Integrated Point Defense AI";
        //if (index == 3) return "" + "Gunnery Control AI";
        return null;
    }

    @Override
    public void addPostDescriptionSection(final TooltipMakerAPI tooltip, final ShipAPI.HullSize hullSize, final ShipAPI ship, final float width, final boolean isForModSpec) {
        final Color green = new Color(55,245,65,255);
        final float pad = 10f;
        final float padS = 0f;
        tooltip.addSectionHeading("Incompatibilities", Alignment.MID, pad);
        tooltip.addPara("- %s", pad, Misc.getNegativeHighlightColor(), new String[] { "Integrated Point Defense AI" });	
        tooltip.addSectionHeading("Details", Alignment.MID, pad);
        tooltip.addPara("- Increased weapon accuracy: %s \n- Increased damage to missiles and fighters: %s", pad, green, new String[] { Misc.getRoundedValue(70.0f) + "%", Misc.getRoundedValue(50.0f) + "%"});		
        tooltip.addPara("- PD weapons will %s decoy flares and acquires best target lead.", padS, Misc.getHighlightColor(), new String[] { "ignore" });
    }

}