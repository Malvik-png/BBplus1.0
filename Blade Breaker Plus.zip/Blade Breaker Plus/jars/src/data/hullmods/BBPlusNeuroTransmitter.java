package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;

public class BBPlusNeuroTransmitter extends BaseHullMod {

    private final Color color = new Color(90,210,160,255);
    public static final float PERFECT_BONUS = 1f;
	
    @Override
    public void applyEffectsBeforeShipCreation(final HullSize hullSize, final MutableShipStatsAPI stats, final String id) {
        stats.getAutofireAimAccuracy().modifyFlat(id, PERFECT_BONUS); // special built-in hullmod for Synapse
        stats.getDynamic().getMod(Stats.PD_BEST_TARGET_LEADING).modifyFlat(id, PERFECT_BONUS); // because the pilot neurally controlling it
        stats.getDynamic().getMod(Stats.PD_IGNORES_FLARES).modifyFlat(id, PERFECT_BONUS); // it gets the best possible aiming just like Newtypes in Gundam
    }
	
    @Override
    public void advanceInCombat(final ShipAPI ship, final float amount) {
        //ship.getEngineController().fadeToOtherColor(this, color, null, 1f, 0.4f);
        ship.getEngineController().fadeToOtherColor(this, color, null, 1f, 1f);
        //ship.getEngineController().extendFlame(this, 0.25f, 0.25f, 0.25f);
    }

    @Override
    public String getDescriptionParam(final int index, final HullSize hullSize) {
        return null;
    }

    @Override
    public void addPostDescriptionSection(final TooltipMakerAPI tooltip, final ShipAPI.HullSize hullSize, final ShipAPI ship, final float width, final boolean isForModSpec) {
        final Color green = new Color(55,245,65,255);
        final Color flavor = new Color(110,110,110,255);
        final float pad = 10f;
        final float padQuote = 6f;
        final float padSig = 1f;
        final float padS = 0f;
        tooltip.addSectionHeading("Details", Alignment.MID, pad);
        tooltip.addPara("- Increased autofire accuracy: %s", pad, green, new String[] { Misc.getRoundedValue(100.0f) + "%" });
        tooltip.addPara("- Weapons will %s.", padS, Misc.getHighlightColor(), new String[] { "ignore flares" });
        tooltip.addPara("%s", padQuote, flavor, new String[] { "\"Systems all green. Neural Connection - Success.\"" });
        tooltip.addPara("%s", padSig, flavor, new String[] { "         \u2014 Neuro Transmitter confirmation" });
    }

}