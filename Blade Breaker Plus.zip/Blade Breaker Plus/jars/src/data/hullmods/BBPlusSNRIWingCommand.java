package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;
import data.campaign.ids.bbplus_HullMods;

public class BBPlusSNRIWingCommand extends BaseHullMod {
    // The old carrier officer skill is now a hullmod!? WOW!
    // Only for BB/DME ships LOL!
    private static final String[] ALL_INCOMPAT_IDS = {"bbplus_snri_carrier_command", "bbplus_snri_strike_command", "expanded_deck_crew"};
    public static final float SPEED_BONUS = 25f;
    public static final float DAMAGE_TO_FIGHTERS_BONUS = 30f;
    public static final float DAMAGE_TO_MISSILES_BONUS = 30f;
    public static final float TARGET_LEADING_BONUS = 50f;

    @Override
    public void applyEffectsToFighterSpawnedByShip(final ShipAPI fighter, final ShipAPI ship, final String id) {
        fighter.getMutableStats().getMaxSpeed().modifyPercent(id, SPEED_BONUS);
        fighter.getMutableStats().getAcceleration().modifyPercent(id, SPEED_BONUS);
        fighter.getMutableStats().getDeceleration().modifyPercent(id, SPEED_BONUS);
        fighter.getMutableStats().getTurnAcceleration().modifyPercent(id, SPEED_BONUS * 2f);
        fighter.getMutableStats().getMaxTurnRate().modifyPercent(id, SPEED_BONUS);
        fighter.getMutableStats().getDamageToFighters().modifyFlat(id, DAMAGE_TO_FIGHTERS_BONUS / 100f);
        fighter.getMutableStats().getDamageToMissiles().modifyFlat(id, DAMAGE_TO_MISSILES_BONUS / 100f);
        fighter.getMutableStats().getAutofireAimAccuracy().modifyFlat(id, TARGET_LEADING_BONUS * 0.01f);
    }

    @Override
    public void applyEffectsAfterShipCreation(final ShipAPI ship, final String id){
        for (final String tmp : ALL_INCOMPAT_IDS) {
            if (ship.getVariant().getHullMods().contains(tmp)) {                
                ship.getVariant().removeMod(tmp);
                DMEBlockedHullmodDisplayScript.showBlocked(ship);
                //ship.getVariant().addMod(ERROR);
            }
        }
    }        
        
    @Override
    public String getDescriptionParam(final int index, final HullSize hullSize) {
        if (index == 0) {
            return "one";
        }
	return null;
    }
	
    @Override
    public boolean isApplicableToShip(final ShipAPI ship) {
        if (ship == null || ship.getVariant() == null)
            return false;
                if (shipHasOtherModInCategory(ship, spec.getId(), bbplus_HullMods.BBPLUS_TAG_SNRI_PACKAGE)) return false;           
                if (ship.getVariant().getHullMods().contains("istl_bbengineering") && (ship.getHullSpec().getFighterBays() >= 1)) return true;
                if (ship.getVariant().getHullMods().contains("istl_monobloc_ca") && (ship.getHullSpec().getFighterBays() >= 1)) return true;
                if (ship.getVariant().getHullMods().contains("istl_monobloc") && (ship.getHullSpec().getFighterBays() >= 1)) return true;
                if (ship.getVariant().getHullMods().contains("istl_6eme_upgr") && (ship.getHullSpec().getFighterBays() >= 1)) return true;
                if (ship.getVariant().getHullMods().contains("istl_refurbframe") && (ship.getHullSpec().getFighterBays() >= 1)) return true;                    
                if (ship.getVariant().getHullMods().contains("expanded_deck_crew")) return false;
        if (!ship.getVariant().hasHullMod("istl_bbengineering") ||
            !ship.getVariant().hasHullMod("istl_monobloc_ca") ||
            !ship.getVariant().hasHullMod("istl_monobloc") ||
            !ship.getVariant().hasHullMod("istl_6eme_upgr") ||
            !ship.getVariant().hasHullMod("istl_refurbframe")) {
            return false;
        }
        return super.isApplicableToShip(ship);
    }

    @Override
    public String getUnapplicableReason(final ShipAPI ship) {
        if (shipHasOtherModInCategory(ship, spec.getId(), bbplus_HullMods.BBPLUS_TAG_SNRI_PACKAGE)) {
            return "Only one type of SNRI Labs hullmod can be installed per ship";
        }              
        if (ship == null || ship.getVariant() == null)
            return "Unable to locate ship!";
                if (ship.getVariant().hasHullMod("expanded_deck_crew"))
                    return "Incompatible with Expanded Deck Crew";               
                if (ship.getHullSpec().getFighterBays() < 1) {
                    return "Ship does not have standard fighter bays";
                }
        if (!ship.getVariant().hasHullMod("istl_bbengineering") ||
            !ship.getVariant().hasHullMod("istl_monobloc_ca") ||
            !ship.getVariant().hasHullMod("istl_monobloc") ||
            !ship.getVariant().hasHullMod("istl_6eme_upgr") ||
            !ship.getVariant().hasHullMod("istl_refurbframe")) {
            return "Only applicable on DME and Blade Breaker hulls with standard fighter bays";
        }        
        return super.getUnapplicableReason(ship);                 
    }
          
    @Override
    public void addPostDescriptionSection(final TooltipMakerAPI tooltip, final ShipAPI.HullSize hullSize, final ShipAPI ship, final float width, final boolean isForModSpec) {
        final Color green = new Color(55,245,65,255);
        final Color flavor = new Color(110,110,110,255);
        final float pad = 10f;
        final float padQuote = 6f;
        final float padSig = 1f;
        tooltip.addSectionHeading("Incompatibilities", Alignment.MID, pad);
        tooltip.addPara("- Incompatible with %s, %s, %s", pad, Misc.getNegativeHighlightColor(), new String[] { "SNRI Carrier Command", "SNRI Strike Command", "Expanded Deck Crew" });
        tooltip.addSectionHeading("Details", Alignment.MID, pad);
        tooltip.addPara("- Increased fighter speed: %s \n- Increased fighter maneuverability: %s \n- Increased damage to fighters and missiles: %s \n- Increased fighter's target accuracy: %s", pad, green, new String[] { SPEED_BONUS  + "%", DAMAGE_TO_FIGHTERS_BONUS + "%", DAMAGE_TO_MISSILES_BONUS + "%",  TARGET_LEADING_BONUS + "%" });		
        tooltip.addPara("%s", padQuote, flavor, new String[] { "\"As long as there are exceptions to the rules, people will try to cheat.\"" });
        tooltip.addPara("%s", padSig, flavor, new String[] { "         \u2014 Peremohy Highport Warrant Officer" });
    }

}