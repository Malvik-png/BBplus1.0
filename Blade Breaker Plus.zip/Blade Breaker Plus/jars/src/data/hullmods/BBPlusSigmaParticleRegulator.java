package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;
import java.util.HashMap;
import java.util.Map;
import java.util.HashSet;
import java.util.Set;

public class BBPlusSigmaParticleRegulator extends BaseHullMod {

    private static final Set<String> BLOCKED_HULLMODS = new HashSet();
    static
    {
        BLOCKED_HULLMODS.add("ecm"); // I'm not sure if these things adds up but stacking is bad so fuck off
        BLOCKED_HULLMODS.add("drive_field_stabilizer"); // Just in case someone is nerd enough to make this modular
    }
    private static final Map mag = new HashMap();
    static
    {
        mag.put(HullSize.FRIGATE, 4f);
        mag.put(HullSize.DESTROYER, 5f);
        mag.put(HullSize.CRUISER, 6f);
        mag.put(HullSize.CAPITAL_SHIP, 7f);
    }

    public static final float BURN_BONUS = 1f;
    public static final float SENSOR_PROFILE = 250f;
		
    @Override
    public void applyEffectsBeforeShipCreation(final HullSize hullSize, final MutableShipStatsAPI stats, final String id) {
        stats.getDynamic().getMod(Stats.FLEET_BURN_BONUS).modifyFlat(id, BURN_BONUS);
        stats.getDynamic().getMod(Stats.ELECTRONIC_WARFARE_FLAT).modifyFlat(id, (Float) mag.get(hullSize));
        stats.getSensorProfile().modifyFlat(id, SENSOR_PROFILE);
    }

    @Override
    public void applyEffectsAfterShipCreation(final ShipAPI ship, final String id){
        for (final String tmp : BLOCKED_HULLMODS) {
            if (ship.getVariant().getHullMods().contains(tmp)) {                
                ship.getVariant().removeMod(tmp);
                DMEBlockedHullmodDisplayScript.showBlocked(ship);
            }
        }
    }

    @Override
    public String getDescriptionParam(final int index, final HullSize hullSize) {
        return null;
    }
	
    @Override
    public boolean isApplicableToShip(final ShipAPI ship) {
        if (ship.getVariant().getHullMods().contains("ecm")) return false;
        return !ship.getVariant().getHullMods().contains("drive_field_stabilizer");
    }
    
    @Override
    public String getUnapplicableReason(final ShipAPI ship) {
        if (ship.getVariant().hasHullMod("ecm")) {
            return "Incompatible with ECM Package";
        }
        if (ship.getVariant().hasHullMod("drive_field_stabilizer")) {
            return "Incompatible with Drive Field Stabilizer";
        }
        return null;
    }

    @Override
    public void addPostDescriptionSection(final TooltipMakerAPI tooltip, final ShipAPI.HullSize hullSize, final ShipAPI ship, final float width, final boolean isForModSpec) {
        final Color green = new Color(55,245,65,255);
        final Color red = new Color(255,0,0,255);
        final float pad = 10f;
        final float padList = 0.0f;
        tooltip.addSectionHeading("Incompatibilities", Alignment.MID, pad);
        tooltip.addPara("- %s", pad, Misc.getNegativeHighlightColor(), new String[] { "ECM Package" });	
        tooltip.addSectionHeading("Details", Alignment.MID, pad);
        tooltip.addPara("- Grants %s/%s/%s/%s ECM rating in combat, depending on hull size. \n- Increased maximum burn of the fleet: %s \nThe added burn level is cumulative with Stabilized Drive Field and other factors synonymous to this effect.", pad, green, new String[] { Misc.getRoundedValue(4.0f) + "%", Misc.getRoundedValue(5.0f) + "%", Misc.getRoundedValue(6.0f) + "%", Misc.getRoundedValue(7.0f) + "%", Misc.getRoundedValue(1.0f) + ""});		
        tooltip.addPara("- Increased sensor profile: %s", padList, red, new String[] { Misc.getRoundedValue(250.0f) + "" });			
    }	

}