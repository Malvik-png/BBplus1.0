package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import java.util.Collection;
import java.util.List;
import java.util.Map;

public abstract class BBPlusSigmaDriveInstaller {

    public static final int NOT_PLAYER = 0;
    public static final int IS_PLAYER = 1;
    public static final int HAS_HULLMOD = 2;
    public static final int HG_SIGMA = 0;
    public static final int LG_SIGMA = 1;
    public static final int U_SIGMA = 2;
  //public static final int LIGMA = 3;
    private static final String[] PREFIXES = {
        BBPlusHighGradeSigmaMatter.DATA_PREFIX,
        BBPlusLowGradeSigmaMatter.DATA_PREFIX,
        BBPlusUnstableSigmaMatter.DATA_PREFIX
    };
    private static final String[][] HMODS = { 
        {"bbplus_sm_highgrade", "bbplus_sm_highgrade_dummy"},
        {"bbplus_sm_lowgrade", "bbplus_sm_lowgrade_dummy"},
        {"bbplus_sm_unstable", "bbplus_sm_unstable_dummy"}
    };
    private static final String[] ITEMS = {
        BBPlusHighGradeSigmaMatter.ITEM,
        BBPlusLowGradeSigmaMatter.ITEM,
        BBPlusUnstableSigmaMatter.ITEM
    };
    public static String[] getMods(final int index) {
        return HMODS[index];
    }
    private static final int MAX_STRING = 3; //holy fuck this fucking fuck line fuck you
    private static final int NEW_SET = 2; //fuck you as well

    public static void removeHullmod(final FleetMemberAPI ship, final int type) {
        if (ship.getVariant() == null) {
            return;
        }
        final Map<String, Object> data = Global.getSector().getPersistentData();
        data.remove(PREFIXES[type] + ship.getId());
        for (final String id : HMODS[type]) {
            if (ship.getVariant().getHullMods().contains(id)) {
                ship.getVariant().removeMod(id);
            }
        }
    }

    public static int isPlayerShip(final ShipAPI ship, final String modId) {	
        final Map<String, Object> data = Global.getSector().getPersistentData();
        final CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
        if (playerFleet == null) {
            return NOT_PLAYER;
        }
        final List<FleetMemberAPI> playerShips = playerFleet.getFleetData().getMembersListCopy();
        final String memberId = ship.getFleetMemberId();
        boolean isPlayerShip = false;
        boolean hasCurrentMod = false;
            for (final FleetMemberAPI playerShip : playerShips) {
                for (int i = 0; i < MAX_STRING; i++) {
                    if (data.containsKey(PREFIXES[i] + playerShip.getId()) && playerShip.getVariant() != null) {
                        boolean hasMod = false;
                        for (final String item : HMODS[i]) {
                            hasMod = hasMod || playerShip.getVariant().getHullMods().contains(item);
                        }
                        if (!hasMod) {
                            data.remove(PREFIXES[i] + playerShip.getId());
                            if (i >= NEW_SET) {
                                playerFleet.getCargo().addCommodity(ITEMS[i], 0); //motherfucking line, I hate this line so much
                            }
                            else {
                                playerFleet.getCargo().addSpecial(new SpecialItemData(ITEMS[i], null), 0); //no refunds
                            }
                        }
                    }
                }
                if (playerShip.getId().equals(memberId)) {
                    isPlayerShip = true;
                }
                if (playerShip.getVariant() != null && playerShip.getVariant().getHullMods().contains(modId)) {
                    hasCurrentMod = true;
                }
            }
        if (isPlayerShip && hasCurrentMod) {
            return 2;
        }
        return isPlayerShip ? 1 : 0;
    }

    public static void removePlayerSpecialItem(final String id) {	
        final CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet(); //omega fuck you
        if (playerFleet == null) {
            return;
        }
        final List<CargoStackAPI> playerCargoStacks = playerFleet.getCargo().getStacksCopy();
            for (final CargoStackAPI cargoStack : playerCargoStacks) {
                if (cargoStack.isSpecialStack() && cargoStack.getSpecialDataIfSpecial().getId().equals(id)) {
                    cargoStack.subtract(1);
                        if (cargoStack.getSize() <= 0)
                            playerFleet.getCargo().removeStack(cargoStack);
                                return;
                }
            }
    }

    public static boolean playerHasSpecialItem(final String id) {	
        final CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
        if (playerFleet == null) {
            return false;
        }
        final List<CargoStackAPI> playerCargoStacks = playerFleet.getCargo().getStacksCopy();
        System.out.println("Searching for Sigma Matter " + id + "...");
            for (final CargoStackAPI cargoStack : playerCargoStacks) {
                if (cargoStack.isSpecialStack() && cargoStack.getSpecialDataIfSpecial().getId().equals(id) && cargoStack.getSize() > 0) {
                    System.out.println("Found Sigma Matter " + cargoStack.getDisplayName() + ", with size " + cargoStack.getSize() + ".");
                    return true;
                }
            }
        return false;
    }

    public static void removePlayerCommodity(final String id) {
        final CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
        if (playerFleet == null) {
            return;
        }
        final List<CargoStackAPI> playerCargoStacks = playerFleet.getCargo().getStacksCopy();
            for (final CargoStackAPI cargoStack : playerCargoStacks) {
                if (cargoStack.isCommodityStack() && cargoStack.getCommodityId().equals(id)) {
                    cargoStack.subtract(1);
                        if (cargoStack.getSize() <= 0)
                            playerFleet.getCargo().removeStack(cargoStack);
                                return;
                }
            }
    }

    public static boolean playerHasCommodity(final String id) {
        final CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
        if (playerFleet == null) {
            return false;
        }
        final List<CargoStackAPI> playerCargoStacks = playerFleet.getCargo().getStacksCopy();
            for (final CargoStackAPI cargoStack : playerCargoStacks) {
                if (cargoStack.isCommodityStack() && cargoStack.getCommodityId().equals(id) && cargoStack.getSize() > 0) {
                    return true;
                }
            }
        return false;
    }
    //so that the game won't shit the bed	
    public static boolean listContainsAny(final Collection list, final Object... objects) {
        if (objects == null) {
            return false;
        }
        for (final Object object : objects) {
            if (list.contains(object)) {
                return true;
            }
        }
        return false;
    }

}