package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.ui.Alignment;
import java.awt.Color;
import java.util.HashSet;
import java.util.Set;

public class BBPlusSigmaNode extends BaseHullMod {
    // attention
    // thank you for your attention
    private static final String SIGMA_NODE_VENTING_MALUS = "BBPlusSigmaNode";   
    private static final Set<String> BLOCKED_HULLMODS = new HashSet();
    static
    {
        BLOCKED_HULLMODS.add("fluxbreakers"); // AAAAAAAAAAAAAAAAAAAAAAIEEEEEEEEEEEEEEEEEEEEEEEEEE
        BLOCKED_HULLMODS.add("bbplus_sm_highgrade"); // noooooooo you can't just do this
        BLOCKED_HULLMODS.add("bbplus_sm_lowgrade"); // oh no no no no no
        BLOCKED_HULLMODS.add("bbplus_sm_unstable"); // OFFICER PLS NO
        BLOCKED_HULLMODS.add("bbplus_sm_highgrade_dummy"); // I'M GONNA
        BLOCKED_HULLMODS.add("bbplus_sm_lowgrade_dummy"); // I'M GONNAAAAA
        BLOCKED_HULLMODS.add("bbplus_sm_unstable_dummy"); // SNEEEEEEEEEEEEEEEEEEEEEEEEED!!!!!!!!!!
    }
    private final Color color = new Color(65,250,200,255); // Gonna snort that sigma crack
    public static final float VENT_BONUS = 20f; // Basically a portable bootleg of BB Engineering without the reduced weapon OP
    private static final float HARD_FLUX_DIS = 25f; // I have no idea what I am doing xd
    public static final float CORONA_EFFECT_REDUCTION = 0.80f; // wear your mask bigot, and triple the layers while you are it
    private static final float SUPPLY_PENALTY = 1.40f; // tax is not a crime if you are the one who's doing it
    private static final float OVERLOAD_DURATION_MULT = 1.50f; // fair trade ok
    private static final float ENGINE_DAMAGE = 1.10f; // wew
    public static final float EXPLODE_MULT = 1.5f; // explosions
    public static final float EXPLODE_RADIUS_MULT = 0.80f;
    public static final float FLUX_REDUC_PERCENT = 15f;
	
    @Override
    public void applyEffectsBeforeShipCreation(final HullSize hullSize, final MutableShipStatsAPI stats, final String id) {
        stats.getVentRateMult().modifyPercent(id, VENT_BONUS);
        stats.getBallisticWeaponFluxCostMod().modifyPercent(id, -FLUX_REDUC_PERCENT);
        stats.getEnergyWeaponFluxCostMod().modifyPercent(id, -FLUX_REDUC_PERCENT);            
        stats.getHardFluxDissipationFraction().modifyFlat(id, (float)HARD_FLUX_DIS * 0.01f);
        stats.getDynamic().getStat(Stats.CORONA_EFFECT_MULT).modifyMult(id, CORONA_EFFECT_REDUCTION);
        stats.getSuppliesPerMonth().modifyMult(id, SUPPLY_PENALTY);
        stats.getEngineDamageTakenMult().modifyMult(id, ENGINE_DAMAGE);	
        stats.getOverloadTimeMod().modifyMult(id, OVERLOAD_DURATION_MULT);
        stats.getDynamic().getStat(Stats.EXPLOSION_DAMAGE_MULT).modifyMult(id, EXPLODE_MULT); // boom just like the og
        stats.getDynamic().getStat(Stats.EXPLOSION_RADIUS_MULT).modifyMult(id, EXPLODE_RADIUS_MULT);		
    }

    @Override
    public void applyEffectsAfterShipCreation(final ShipAPI ship, final String id){
        for (final String tmp : BLOCKED_HULLMODS) {
            if (ship.getVariant().getHullMods().contains(tmp)) {                
                ship.getVariant().removeMod(tmp);
                DMEBlockedHullmodDisplayScript.showBlocked(ship);
                //ship.getVariant().addMod(ERROR);
            }
        }
    }
	
    @Override
    public String getDescriptionParam(final int index, final HullSize hullSize) {
        return null;
    }

    @Override
    public void advanceInCombat(final ShipAPI ship, final float amount) {
        final MutableShipStatsAPI stats = ship.getMutableStats();
        if (ship.getFluxTracker().isVenting() == true){
            stats.getArmorDamageTakenMult().modifyMult(SIGMA_NODE_VENTING_MALUS, 1.2f);
            stats.getShieldDamageTakenMult().modifyMult(SIGMA_NODE_VENTING_MALUS, 1.2f);
            stats.getHullDamageTakenMult().modifyMult(SIGMA_NODE_VENTING_MALUS, 1.2f);
        }
        else {
            stats.getArmorDamageTakenMult().modifyMult(SIGMA_NODE_VENTING_MALUS, 1f);
            stats.getShieldDamageTakenMult().modifyMult(SIGMA_NODE_VENTING_MALUS, 1f);
            stats.getHullDamageTakenMult().modifyMult(SIGMA_NODE_VENTING_MALUS, 1f);
        }        
        //ship.getEngineController().fadeToOtherColor(this, color, null, 1f, 0.4f);
        ship.getEngineController().fadeToOtherColor(this, color, null, 1f, 1f); // I can't believe it was just this fucking simple holy shiet
        //ship.getEngineController().extendFlame(this, 0.25f, 0.25f, 0.25f);
    }
	
    @Override
    public boolean isApplicableToShip(final ShipAPI ship) {
        return (!ship.getVariant().getHullMods().contains("istl_bbengineering")) &&
                !ship.getVariant().getHullMods().contains("fluxbreakers") &&
                !ship.getVariant().getHullMods().contains("bbplus_sm_highgrade") &&
                !ship.getVariant().getHullMods().contains("bbplus_sm_lowgrade") &&
                !ship.getVariant().getHullMods().contains("bbplus_sm_unstable") &&
                !ship.getVariant().getHullMods().contains("bbplus_sm_highgrade_dummy") &&
                !ship.getVariant().getHullMods().contains("bbplus_sm_lowgrade_dummy") &&
                !ship.getVariant().getHullMods().contains("bbplus_sm_unstable_dummy");
    }
    
    @Override
    public String getUnapplicableReason(final ShipAPI ship) {
        if (ship.getVariant().hasHullMod("istl_bbengineering"))
            return "This ship is already using Blade Breaker Engineering"; // installing this to a BB ship is redundant
        if (ship.getVariant().hasHullMod("fluxbreakers")) // NO SUPER VENTING SPEED FOR YOU FUCKO
            return "Incompatible with Resistant Flux Conduits";        
        if (ship.getVariant().hasHullMod("bbplus_sm_highgrade")) // YOU
            return "Incompatible with Sigma Drives";
        if (ship.getVariant().hasHullMod("bbplus_sm_lowgrade")) // SHALL
            return "Incompatible with Sigma Drives";
        if (ship.getVariant().hasHullMod("bbplus_sm_unstable")) // NOT PASS
            return "Incompatible with Sigma Drives";
        if (ship.getVariant().hasHullMod("bbplus_sm_highgrade_dummy")) // YOU
            return "Incompatible with Sigma Drives";
        if (ship.getVariant().hasHullMod("bbplus_sm_lowgrade_dummy")) // SHALL
            return "Incompatible with Sigma Drives";
        if (ship.getVariant().hasHullMod("bbplus_sm_unstable_dummy")) // NOT PASS AGAIN
            return "Incompatible with Sigma Drives";
        return null;
    }

    @Override
    public void addPostDescriptionSection(final TooltipMakerAPI tooltip, final ShipAPI.HullSize hullSize, final ShipAPI ship, final float width, final boolean isForModSpec) {
        final Color green = new Color(55,245,65,255);
        final Color red = new Color(255,0,0,255);
        final Color flavor = new Color(110,110,110,255);
        final float pad = 10f;
        final float padQuote = 6f;
        final float padNeg = 0.0f;
        final float padSig = 1f;
        tooltip.addSectionHeading("Incompatibilities", Alignment.MID, pad);
        tooltip.addPara("- Incompatible with %s, %s, %s, %s, %s", pad, Misc.getNegativeHighlightColor(), new String[] { "Blade Breaker Engineering", "Resistant Flux Conduits", "Sigma Drive Accelerator", "Sigma Drive Condenser", "Sigma Drive Stabilizer" });
        tooltip.addSectionHeading("Details", Alignment.MID, pad);
        tooltip.addPara("- Improves active vent rate: %s \n- Reduced ballistic and energy weapon flux cost: %s \n- Dissipates hard flux while shields are up: %s \n- Reduces negative effects of solar corona and hyperspace storm: %s", pad, green, new String[] { Misc.getRoundedValue(20.0f) + "%", Misc.getRoundedValue(15.0f) + "%", Misc.getRoundedValue(25.0f) + "%", Misc.getRoundedValue(20.0f) + "%" });
        tooltip.addPara("- Supply cost is increased: %s \n- Overload duration is increased: %s \n- Damage taken increased during venting: %s \n- The engines will receive %s more damage. \n- Explodes %s than a comparable hull.", padNeg, red, new String[] { Misc.getRoundedValue(40.0f) + "%", Misc.getRoundedValue(50.0f) + "%", Misc.getRoundedValue(20.0f) + "%", Misc.getRoundedValue(10.0f) + "%", "more violently" });
        tooltip.addPara("%s", padQuote, flavor, new String[] { "\"You can't read anyway.\"" });
        tooltip.addPara("%s", padSig, flavor, new String[] { "         \u2014 Sephira Chief Researcher Gemie" });      
    }

}