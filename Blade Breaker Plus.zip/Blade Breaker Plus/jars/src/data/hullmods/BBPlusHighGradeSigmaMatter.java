package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.CampaignUIAPI.CoreUITradeMode;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.util.Misc;
import java.util.Map;
import java.awt.Color;
import data.campaign.ids.istl_Commodities;

public class BBPlusHighGradeSigmaMatter extends BaseHullMod {
    
    private final Color color = new Color(90,210,160,255); // Gonna snort that sigma crack
    private static final String[] ALL_INCOMPAT_IDS = {
        "bbplus_sm_unstable", "bbplus_sm_lowgrade", "bbplus_sigmanode",
        "bbplus_sm_unstable_dummy", "bbplus_sm_lowgrade_dummy", "swp_shieldbypass", "roider_fighterClamps",
        "safetyoverrides", "solar_shielding", "shield_shunt", "converted_hangar"};
    private final String BBreakerENG = "istl_bbengineering";
    private final String BBreakerDEF = "istl_bbdefense";        
    public static final String DATA_PREFIX = "sigma_matter_high_gen_check_";
    public static final String ITEM = istl_Commodities.SIGMA_MATTER_HIGH;
    private String[] getIncompatibleIds() {
        if (super.spec.getId().equals("bbplus_sm_highgrade")) //only one is allowed wtf
            return ALL_INCOMPAT_IDS;
        return null;
    }
    //public static final float REPAIR_BONUS = 30f; // how stupid of me, there was an engine damage then I'll add a fucking repair bonus? W0WW0W
    public static final float PHASE_BONUS = 15f;
    public static final float PHASE_SPEED_BONUS = 20f;        
    public static final float SHIELD_EFF = 20f;
    public static final float SHIELD_HE_REDUCTION = 20f;
    public static final float SHIELD_RATE = 50f;
    public static final float MANEUVERABILITY_BONUS = 15f;	
    public static final float PIERCE_MULT = 0.50f;
    public static final float FLUX_RESISTANCE = 35f;
    public static final float SHIELD_UPKEEP_BONUS = 60f;
	// Pseudo BB Engineering penalties and etc
    private static final float SUPPLY_PENALTY = 1.50f; // just like Sigma Node but since this is the superior version, it is more expensive
    private static final float OVERLOAD_DURATION_MULT = 1.50f; // there's nothing wrong with this, plus it takes 0 OP 
    private static final float ENGINE_DAMAGE = 1.10f; // your trophy is now usable so it's fine (^:
    public static final float EXPLODE_MULT = 1.5f; // E X P L O S I O N
    public static final float EXPLODE_RADIUS_MULT = 0.80f;
    public static final float CORONA_EFFECT_REDUCTION = 0.50f;
    public static final float WEAPON_FLUX_PENALTY = 1.15f;
	// Lessened bonus for BB ships but the dumb malus is negated with some exceptions
    public static final float BB_PHASE_BONUS = 10f;
    public static final float BB_PHASE_SPEED_BONUS = 15f;
    public static final float BB_SHIELD_EFF = 10f;
    public static final float BB_SHIELD_HE_REDUCTION = 10f;
    public static final float BB_SHIELD_RATE = 25f;
    public static final float BB_MANEUVERABILITY_BONUS = 10f;	
    public static final float BB_PIERCE_MULT = 0.25f;
    public static final float BB_FLUX_RESISTANCE = 20f;
    public static final float BB_SHIELD_UPKEEP_BONUS = 30f;		
    //Defense Mode
    @Override
    public void applyEffectsBeforeShipCreation(final ShipAPI.HullSize hullSize, final MutableShipStatsAPI stats, final String id) {
        //stats.getFluxCapacity().modifyMult(id, FLUX_BONUS);
        //stats.getFluxDissipation().modifyMult(id , DISS_BONUS);
        //stats.getCombatWeaponRepairTimeMult().modifyMult(id, 1f - REPAIR_BONUS * 0.01f);
        //stats.getCombatEngineRepairTimeMult().modifyMult(id, 1f - REPAIR_BONUS * 0.01f);
        //stats.getTimeMult().modifyMult(id, CLOCK_UP); for the record, this is a shitty idea
        // will probably save this later for Twin S-Drive System
        // general malus
        stats.getBeamWeaponFluxCostMult().modifyMult(id, WEAPON_FLUX_PENALTY);
        stats.getBallisticWeaponFluxCostMod().modifyMult(id, WEAPON_FLUX_PENALTY);
        stats.getEnergyWeaponFluxCostMod().modifyMult(id, WEAPON_FLUX_PENALTY);
        stats.getMissileWeaponFluxCostMod().modifyMult(id, WEAPON_FLUX_PENALTY);
        stats.getEngineDamageTakenMult().modifyMult(id, ENGINE_DAMAGE);
        // what a fucking clusterfuck of a hullmod is this
        if (stats.getVariant().hasHullMod("istl_bbengineering") && stats.getVariant().hasHullMod("istl_bbdefense")) {
            // the BB Engineering-like penalties are negated for BB ships, why would you INCREASE it?
            // think of it as a supplementary sigma battery or some shit ok
            // in return, the benefits of this mod are lessened for BB ships            
            stats.getHighExplosiveShieldDamageTakenMult().modifyMult(id, 1f - BB_SHIELD_HE_REDUCTION / 100f);
            stats.getShieldUpkeepMult().modifyMult(id, 1f - BB_SHIELD_UPKEEP_BONUS * 0.01f);
            stats.getShieldUnfoldRateMult().modifyPercent(id, BB_SHIELD_RATE);
            stats.getShieldTurnRateMult().modifyPercent(id, BB_SHIELD_RATE);
        }
        else if (stats.getVariant().hasHullMod("istl_bbengineering")){
            stats.getHighExplosiveShieldDamageTakenMult().modifyMult(id, 1f - BB_SHIELD_HE_REDUCTION / 100f);
            stats.getShieldDamageTakenMult().modifyPercent(id, 1f -BB_SHIELD_EFF);
            stats.getShieldUpkeepMult().modifyMult(id, 1f - BB_SHIELD_UPKEEP_BONUS * 0.01f);
            stats.getDynamic().getStat(Stats.SHIELD_PIERCED_MULT).modifyMult(id, BB_PIERCE_MULT);
            stats.getShieldUnfoldRateMult().modifyPercent(id, BB_SHIELD_RATE);
            stats.getShieldTurnRateMult().modifyPercent(id, BB_SHIELD_RATE);
        }
        else {
            stats.getHighExplosiveShieldDamageTakenMult().modifyMult(id, 1f - SHIELD_HE_REDUCTION / 100f);
            stats.getShieldDamageTakenMult().modifyPercent(id, -SHIELD_EFF);
            stats.getShieldUpkeepMult().modifyMult(id, 1f - SHIELD_UPKEEP_BONUS * 0.01f);
            stats.getDynamic().getStat(Stats.SHIELD_PIERCED_MULT).modifyMult(id, PIERCE_MULT);
            stats.getShieldUnfoldRateMult().modifyPercent(id, SHIELD_RATE);
            stats.getShieldTurnRateMult().modifyPercent(id, SHIELD_RATE);            
            stats.getSuppliesPerMonth().modifyMult(id, SUPPLY_PENALTY);
            stats.getDynamic().getStat(Stats.CORONA_EFFECT_MULT).modifyMult(id, CORONA_EFFECT_REDUCTION);
        }
    }
	
    @Override
    public void applyEffectsAfterShipCreation(final ShipAPI ship, final String id) {		
        final MutableShipStatsAPI stats = ship.getMutableStats();
        if (ship.getVariant().hasHullMod("istl_bbengineering")){
            stats.getEmpDamageTakenMult().modifyMult(id, 1f - BB_FLUX_RESISTANCE * 0.01f);
            stats.getAcceleration().modifyPercent(id, BB_MANEUVERABILITY_BONUS);
            stats.getDeceleration().modifyPercent(id, BB_MANEUVERABILITY_BONUS);
            stats.getTurnAcceleration().modifyPercent(id, BB_MANEUVERABILITY_BONUS * 2f);
            stats.getMaxTurnRate().modifyPercent(id, BB_MANEUVERABILITY_BONUS);
            stats.getPhaseCloakActivationCostBonus().modifyPercent(id, -BB_PHASE_BONUS);
            stats.getPhaseCloakCooldownBonus().modifyPercent(id, -BB_PHASE_BONUS);
            stats.getPhaseCloakUpkeepCostBonus().modifyPercent(id, -BB_PHASE_BONUS);
            stats.getDynamic().getMod(Stats.PHASE_CLOAK_SPEED_MOD).modifyFlat(id, BB_PHASE_SPEED_BONUS);
        }
        else {
            stats.getEmpDamageTakenMult().modifyMult(id, 1f - FLUX_RESISTANCE * 0.01f);
            stats.getPhaseCloakActivationCostBonus().modifyPercent(id, -PHASE_BONUS);
            stats.getPhaseCloakCooldownBonus().modifyPercent(id, -PHASE_BONUS);
            stats.getPhaseCloakUpkeepCostBonus().modifyPercent(id, -PHASE_BONUS);
            stats.getDynamic().getMod(Stats.PHASE_CLOAK_SPEED_MOD).modifyFlat(id, PHASE_SPEED_BONUS);
            stats.getAcceleration().modifyPercent(id, MANEUVERABILITY_BONUS);
            stats.getDeceleration().modifyPercent(id, MANEUVERABILITY_BONUS);
            stats.getTurnAcceleration().modifyPercent(id, MANEUVERABILITY_BONUS * 2f);
            stats.getMaxTurnRate().modifyPercent(id, MANEUVERABILITY_BONUS);
            stats.getOverloadTimeMod().modifyMult(id, OVERLOAD_DURATION_MULT);
            stats.getDynamic().getStat(Stats.EXPLOSION_DAMAGE_MULT).modifyMult(id, EXPLODE_MULT); // boom just like the og
            stats.getDynamic().getStat(Stats.EXPLOSION_RADIUS_MULT).modifyMult(id, EXPLODE_RADIUS_MULT);
        }	
        // no stacking of things, fuck off 
        for (final String tmp : ALL_INCOMPAT_IDS) {
            if (ship.getVariant().getHullMods().contains(tmp)) {                
                ship.getVariant().removeMod(tmp);
                DMEBlockedHullmodDisplayScript.showBlocked(ship);
		//ship.getVariant().addMod(ERROR);
            }
        }
    }
		
    @Override
    public boolean isApplicableToShip(final ShipAPI ship) {
        if (ship == null || ship.getVariant() == null)
            return false;
                if (ship.getVariant().getHullMods().contains("bbplus_sm_highgrade_dummy")) return false;
                if (ship.getVariant().getHullMods().contains("converted_hangar")) return false;
                if (ship.getVariant().getHullMods().contains("safetyoverrides")) return false;
                if (ship.getVariant().getHullMods().contains("solar_shielding")) return false;
                if (ship.getVariant().getHullMods().contains("shield_shunt")) return false;
                if (ship.getVariant().getHullMods().contains("bbplus_sigmanode")) return false;
                if (ship.getVariant().getHullMods().contains("swp_shieldbypass")) return false;
                if (ship.getVariant().getHullMods().contains("roider_fighterClamps")) return false;
        if (BBPlusSigmaDriveInstaller.listContainsAny(ship.getVariant().getHullMods(), (Object[])ALL_INCOMPAT_IDS))
            return false;
        return !BBPlusSigmaDriveInstaller.listContainsAny(ship.getVariant().getHullMods(), (Object[])getIncompatibleIds());
    }
    
    @Override
    public String getUnapplicableReason(final ShipAPI ship) {
        if (ship == null || ship.getVariant() == null)
            return "Unable to locate ship!";
                if (ship.getVariant().hasHullMod("bbplus_sm_highgrade_dummy")) // To avoid fuckery
                    return "Sigma Drive Condenser is already installed";
                if (ship.getVariant().hasHullMod("converted_hangar"))
                    return "Incompatible with Converted Hangar";
                if (ship.getVariant().hasHullMod("safetyoverrides"))
                    return "Incompatible with Safety Overrides";
                if (ship.getVariant().hasHullMod("solar_shielding"))
                    return "Incompatible with Solar Shielding";                   
                if (ship.getVariant().hasHullMod("shield_shunt"))
                    return "Incompatible with Shield Shunt";                
                if (ship.getVariant().hasHullMod("bbplus_sigmanode"))
                    return "Incompatible with Sigma Node";
                if (ship.getVariant().hasHullMod("swp_shieldbypass"))
                    return "Incompatible with Shield Bypass";
                if (ship.getVariant().hasHullMod("roider_fighterClamps"))
                    return "Incompatible with Fighter Clamps";                
        if (BBPlusSigmaDriveInstaller.listContainsAny(ship.getVariant().getHullMods(), (Object[])ALL_INCOMPAT_IDS) ||
            BBPlusSigmaDriveInstaller.listContainsAny(ship.getVariant().getHullMods(), (Object[])getIncompatibleIds()))
            return "Only one type of Sigma Matter can be installed per ship";  
        return ""; //I have to repeat this warning several times for those who doesn't read
    }

    @Override
    public void advanceInCampaign(final FleetMemberAPI member, final float amount) {
        final Map<String, Object> data = Global.getSector().getPersistentData();
        if (data.containsKey(DATA_PREFIX + member.getId())) {
            return;
        }
        BBPlusSigmaDriveInstaller.removePlayerCommodity(ITEM);
        data.put(DATA_PREFIX + member.getId(), "placeholder");
    }

    @Override
    public boolean canBeAddedOrRemovedNow(final ShipAPI ship, final MarketAPI marketOrNull, final CoreUITradeMode mode) {
        final int status = BBPlusSigmaDriveInstaller.isPlayerShip(ship, super.spec.getId());
        if (status == BBPlusSigmaDriveInstaller.NOT_PLAYER) {
            return false;
        }
        if (status != BBPlusSigmaDriveInstaller.HAS_HULLMOD && !BBPlusSigmaDriveInstaller.playerHasCommodity(ITEM)) {
            return false;
        }
        return super.canBeAddedOrRemovedNow(ship, marketOrNull, mode);
    }

    @Override
    public String getCanNotBeInstalledNowReason(final ShipAPI ship, final MarketAPI marketOrNull, final CoreUITradeMode mode) {
        final int status = BBPlusSigmaDriveInstaller.isPlayerShip(ship, super.spec.getId());
        if (status == BBPlusSigmaDriveInstaller.NOT_PLAYER) {
            return "This installation is not applicable to modules";
        }
        if (status != BBPlusSigmaDriveInstaller.HAS_HULLMOD && !BBPlusSigmaDriveInstaller.playerHasCommodity(ITEM)) {
            return "Installation requires [High-Grade Sigma Matter] (1)";
        }
        return super.getCanNotBeInstalledNowReason(ship, marketOrNull, mode);
    }
	
    @Override
    public void advanceInCombat(final ShipAPI ship, final float amount) {
	//ship.getEngineController().fadeToOtherColor(this, color, null, 1f, 0.4f);
        ship.getEngineController().fadeToOtherColor(this, color, null, 1f, 1f);
	//ship.getEngineController().extendFlame(this, 0.25f, 0.25f, 0.25f);
    }
        
    @Override
    public String getDescriptionParam(final int index, final ShipAPI.HullSize hullSize) {
	//if (index == 0) return "" + "halves";
        if (index == 0) return "" + "varying effects";
        return null;
    }
	//HAVE SEX CRINJPRIEST
    @Override
    public void addPostDescriptionSection(final TooltipMakerAPI tooltip, final ShipAPI.HullSize hullSize, final ShipAPI ship, final float width, final boolean isForModSpec) {
        final Color bbreaker = new Color(155,155,190,255);
        final Color green = new Color(55,245,65,255);
        final Color red = new Color(255,0,0,255);
        final Color sigmadrivecond = new Color(20,220,240,255);
        final Color warning = new Color (255,80,0,255);
        final float pad = 10f;
        final float opad = 8.0f;
        tooltip.addImage("graphics/tooltips/bbplus_sigmaborder.png", 368f, 8f, 5f);
        TooltipMakerAPI text = tooltip.beginImageWithText(Global.getSettings().getSpriteName("smatters", "hgsigma"), 33.0f);
        text.addPara("If the %s is installed on a Blade Breaker ship, it will provide different effects.", 3.0f, sigmadrivecond, new String[] { "High-Grade Sigma Matter" });
        tooltip.addImageWithText(3.0f);
        tooltip.addSectionHeading("Incompatibilities", Alignment.MID, pad);
        tooltip.addPara("- Incompatible with %s, %s, %s, %s, %s", pad, Misc.getNegativeHighlightColor(), new String[] { "Converted Hangar", "Safety Overrides", "Sigma Node", "Solar Shielding", "Shield Shunt" });
        tooltip.addSectionHeading("Details", Alignment.MID, pad);
		// If you view this modspec in your inventory without the null conditions then it will cause CTD so...
		// I need to put this so the game won't shit the bed.
        if (ship == null || ship.getVariant() == null) {
            tooltip.addPara("\n- Reduces incoming EMP damage: %s \n- Increased maneuverability: %s \n- Reduced damage taken by shields: %s \n- Reduced flux upkeep for shields: %s \n- Improved shield unfold and turn rate: %s \n- Reduced chance of shield being pierced: %s \n- Reduced high-explosive damage taken by shields: %s \n- Phase activation/cooldown/upkeep cost reduced: %s \n- Increased top speed while phase cloak is active: %s flat \n- %s the harmful effects of solar coronas and hyperspace storms.", pad, green, new String[] { Misc.getRoundedValue(35.0f) + "%", Misc.getRoundedValue(15.0f) + "%" , Misc.getRoundedValue(20.0f) + "%" , Misc.getRoundedValue(60.0f) + "%" , Misc.getRoundedValue(50.0f) + "%", Misc.getRoundedValue(50.0f) + "%", Misc.getRoundedValue(20.0f) + "%", Misc.getRoundedValue(15.0f) + "%", Misc.getRoundedValue(20.0f), "Halves"});
            tooltip.addPara("- Supply cost increased: %s \n- Overload duration increased: %s \n- Weapon flux cost increased: %s \n- The engines will receive %s more damage. \n- Explodes %s than a comparable hull.", 0.0f, red, new String[] { Misc.getRoundedValue(50.0f) + "%", Misc.getRoundedValue(50.0f) + "%", Misc.getRoundedValue(15.0f) + "%", Misc.getRoundedValue(10.0f) + "%", "more violently" });
        }
        else if (ship.getPhaseCloak() != null && ship.getVariant().hasHullMod("istl_bbengineering") && ship.getVariant().hasHullMod("istl_bbdefense")){
            text = tooltip.beginImageWithText(Global.getSettings().getHullModSpec(BBreakerDEF).getSpriteName(), 36f);
            text.addPara("A %s ship is detected, certain negative effects are negated and overall bonus are reduced.", 0.0f, bbreaker, new String[] {"Blade Breaker"});
            tooltip.addImageWithText(pad);
            tooltip.addPara("\n- Reduces incoming EMP damage: %s \n- Increased maneuverability: %s \n- Phase activation/cooldown/upkeep cost reduced: %s \n- Increased top speed while phase cloak is active: %s flat", 0.0f, green, new String[] { Misc.getRoundedValue(20.0f) + "%", Misc.getRoundedValue(10.0f) + "%", Misc.getRoundedValue(10.0f) + "%", Misc.getRoundedValue(15.0f)});
            tooltip.addPara("- Weapon flux cost increased: %s \n- The engines will receive %s more damage.", 0.0f, red, new String[] { Misc.getRoundedValue(15.0f) + "%", Misc.getRoundedValue(10.0f) + "%" });
        }
        else if (ship.getPhaseCloak() != null && ship.getVariant().hasHullMod("istl_bbengineering")){
            text = tooltip.beginImageWithText(Global.getSettings().getHullModSpec(BBreakerENG).getSpriteName(), 36f);
            text.addPara("A %s ship is detected, certain negative effects are negated and overall bonus are reduced.", 0.0f, bbreaker, new String[] {"Blade Breaker"});
            tooltip.addImageWithText(pad);
            tooltip.addPara("\n- Reduces incoming EMP damage: %s \n- Increased maneuverability: %s \n- Phase activation/cooldown/upkeep cost reduced: %s \n- Increased top speed while phase cloak is active: %s flat", 0.0f, green, new String[] { Misc.getRoundedValue(20.0f) + "%", Misc.getRoundedValue(10.0f) + "%", Misc.getRoundedValue(10.0f) + "%", Misc.getRoundedValue(15.0f)});
            tooltip.addPara("- Weapon flux cost increased: %s \n- The engines will receive %s more damage.", 0.0f, red, new String[] { Misc.getRoundedValue(15.0f) + "%", Misc.getRoundedValue(10.0f) + "%" });
        }
        else if (ship.getVariant().hasHullMod("istl_bbengineering") && ship.getVariant().hasHullMod("istl_bbdefense")){
            text = tooltip.beginImageWithText(Global.getSettings().getHullModSpec(BBreakerDEF).getSpriteName(), 36f);
            text.addPara("A %s ship with %s is detected, further adjustment to bonuses are applied.", 0.0f, bbreaker, new String[] { "Blade Breaker", "Breaker Defense" });
            tooltip.addImageWithText(pad);
            tooltip.addPara("\n- Reduces incoming EMP damage: %s \n- Increased maneuverability: %s \n- Reduced flux upkeep for shields: %s \n- Improved shield unfold and turn rate: %s \n- Reduced high-explosive damage taken by shields: %s", 0.0f, green, new String[] { Misc.getRoundedValue(20.0f) + "%", Misc.getRoundedValue(10.0f) + "%", Misc.getRoundedValue(30.0f) + "%" , Misc.getRoundedValue(25.0f) + "%", Misc.getRoundedValue(10.0f) + "%"});
            tooltip.addPara("- Weapon flux cost increased: %s \n- The engines will receive %s more damage.", 0.0f, red, new String[] { Misc.getRoundedValue(15.0f) + "%", Misc.getRoundedValue(10.0f) + "%" });
        }
        else if (ship.getVariant().hasHullMod("istl_bbengineering")){
            text = tooltip.beginImageWithText(Global.getSettings().getHullModSpec(BBreakerENG).getSpriteName(), 36f);
            text.addPara("A %s ship is detected, certain negative effects are negated and overall bonus are reduced.", 0f, bbreaker, new String[] {"Blade Breaker"});
            tooltip.addImageWithText(pad);
            tooltip.addPara("\n- Reduces incoming EMP damage: %s \n- Increased maneuverability: %s \n- Reduced damage taken by shields: %s \n- Reduced flux upkeep for shields: %s \n- Improved shield unfold and turn rate: %s \n- Reduced chance of shield being pierced: %s \n- Reduced high-explosive damage taken by shields: %s", 0.0f, green, new String[] { Misc.getRoundedValue(20.0f) + "%", Misc.getRoundedValue(10.0f) + "%" , Misc.getRoundedValue(10.0f) + "%" , Misc.getRoundedValue(30.0f) + "%" , Misc.getRoundedValue(25.0f) + "%", Misc.getRoundedValue(25.0f) + "%", Misc.getRoundedValue(10.0f) + "%"});
            tooltip.addPara("- Weapon flux cost increased: %s \n- The engines will receive %s more damage.", 0.0f, red, new String[] { Misc.getRoundedValue(15.0f) + "%", Misc.getRoundedValue(10.0f) + "%" });
        }
        else if (ship.getPhaseCloak() != null){
            tooltip.addPara("\n- Reduces incoming EMP damage: %s \n- Increased maneuverability: %s \n- Phase activation/cooldown/upkeep cost reduced: %s \n- Increased top speed while phase cloak is active: %s flat \n- %s the harmful effects of solar coronas and hyperspace storms.", 0.0f, green, new String[] { Misc.getRoundedValue(35.0f) + "%", Misc.getRoundedValue(15.0f) + "%", Misc.getRoundedValue(15.0f) + "%", Misc.getRoundedValue(20.0f), "Halves"});
            tooltip.addPara("- Supply cost increased: %s \n- Overload duration increased: %s \n- Weapon flux cost increased: %s \n- The engines will receive %s more damage. \n- Explodes %s than a comparable hull.", 0.0f, red, new String[] { Misc.getRoundedValue(50.0f) + "%", Misc.getRoundedValue(50.0f) + "%", Misc.getRoundedValue(15.0f) + "%", Misc.getRoundedValue(10.0f) + "%", "more violently" });
        }        
        else {
            tooltip.addPara("\n- Reduces incoming EMP damage: %s \n- Increased maneuverability: %s \n- Reduced damage taken by shields: %s \n- Reduced flux upkeep for shields: %s \n- Improved shield unfold and turn rate: %s \n- Reduced chance of shield being pierced: %s \n- Reduced high-explosive damage taken by shields: %s \n- %s the harmful effects of solar coronas and hyperspace storms.", 0.0f, green, new String[] { Misc.getRoundedValue(35.0f) + "%", Misc.getRoundedValue(15.0f) + "%" , Misc.getRoundedValue(20.0f) + "%" , Misc.getRoundedValue(60.0f) + "%" , Misc.getRoundedValue(50.0f) + "%", Misc.getRoundedValue(50.0f) + "%", Misc.getRoundedValue(20.0f) + "%", "Halves"});
            tooltip.addPara("- Supply cost increased: %s \n- Overload duration increased: %s \n- Weapon flux cost increased: %s \n- The engines will receive %s more damage. \n- Explodes %s than a comparable hull.", 0.0f, red, new String[] { Misc.getRoundedValue(50.0f) + "%", Misc.getRoundedValue(50.0f) + "%", Misc.getRoundedValue(15.0f) + "%", Misc.getRoundedValue(10.0f) + "%", "more violently" });
        }		
        final TooltipMakerAPI alert = tooltip.beginImageWithText(Global.getSettings().getSpriteName("tooltips", "warning"), 40f);
        alert.addPara("%s", 0, warning, new String[] { "WARNING! Installation process will consume one High-Grade Sigma Matter, once installed it will permanently remove the item from your inventory. Furthermore, removing the hullmod will not return the consumed Sigma Matter." });
        tooltip.addImageWithText(opad);
    }
    
}