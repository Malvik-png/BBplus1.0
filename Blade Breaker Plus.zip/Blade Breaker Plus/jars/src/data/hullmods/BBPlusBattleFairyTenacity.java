package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;

public class BBPlusBattleFairyTenacity extends BaseHullMod {
	
    private final Color color = new Color(0,255,0,255);
    public static final float PIERCE_MULT = 0.5f; // what? a hullmod just for a single fighter that comes with a unique hullmod icon? w0w!
    public static final float SHIELD_BONUS = 20f; // and you can't even see its hullmod description, double w0w!!
    public static final float WEAPON_HEALTH_BONUS = 40f; // furthermore, techpriest won't release iron shell, fuck
    public static final float ARMOR_BONUS = 10f;
    public static final float BONUS_DAMAGE = 100f; // yes, a fucking jacked up terminator core lol
	
    @Override
    public void applyEffectsBeforeShipCreation(final HullSize hullSize, final MutableShipStatsAPI stats, final String id) {
        stats.getShieldDamageTakenMult().modifyMult(id, 1f - SHIELD_BONUS * 0.01f);
        stats.getDynamic().getStat(Stats.SHIELD_PIERCED_MULT).modifyMult(id, PIERCE_MULT);
        stats.getArmorBonus().modifyPercent(id, ARMOR_BONUS);
        stats.getWeaponHealthBonus().modifyPercent(id, WEAPON_HEALTH_BONUS);
        stats.getDamageToMissiles().modifyPercent(id, BONUS_DAMAGE);
        stats.getDamageToFighters().modifyPercent(id, BONUS_DAMAGE);        
        stats.getDynamic().getMod(Stats.PD_IGNORES_FLARES).modifyFlat(id, 1f);
        stats.getDynamic().getMod(Stats.PD_BEST_TARGET_LEADING).modifyFlat(id, 1f);
    }
	
    @Override
    public String getDescriptionParam(final int index, final HullSize hullSize) {
        //if (index == 0) return "" + (int) SHIELD_BONUS + "%";
        //if (index == 1) return "" + (int) WEAPON_HEALTH_BONUS + "%";
        //if (index == 2) return "" + (int) ARMOR_BONUS + "%";
        return null;
    }

    @Override
    public void advanceInCombat(final ShipAPI ship, final float amount) {
        ship.getEngineController().fadeToOtherColor(this, color, null, 1f, 0.4f);
        ship.getEngineController().extendFlame(this, 0.25f, 0.25f, 0.25f);
    }

    @Override
    public boolean isApplicableToShip(final ShipAPI ship) {
        return ship != null && ship.getShield() != null;
    }
	
    @Override
    public String getUnapplicableReason(final ShipAPI ship) {
        return "Ship has no shields";
    }

    @Override
    public void addPostDescriptionSection(final TooltipMakerAPI tooltip, final ShipAPI.HullSize hullSize, final ShipAPI ship, final float width, final boolean isForModSpec) {
        final Color green = new Color(55,245,65,255);
        final Color flavor = new Color(110,110,110,255);
        final float pad = 10f;
        final float padQuote = 6f;
        final float padSig = 1f;
        final float padS = 0f;
        tooltip.addSectionHeading("Details", Alignment.MID, pad);
        tooltip.addPara("- Reduced damage taken by shields: %s \n- Reduced chance of shield being pierced: %s \n- Increased armor rating: %s \n- Increased weapon durability: %s \n- Increased damage to fighters: %s \n- Increased damage to missiles: %s", pad, green, new String[] { Misc.getRoundedValue(20.0f) + "%", Misc.getRoundedValue(50.0f) + "%", Misc.getRoundedValue(10.0f) + "%", Misc.getRoundedValue(40.0f) + "%", Misc.getRoundedValue(100.0f) + "%", Misc.getRoundedValue(100.0f) + "%" });
        tooltip.addPara("- Weapons will %s.", padS, Misc.getHighlightColor(), new String[] { "ignore flares" });        
        tooltip.addPara("%s", padQuote, flavor, new String[] { "\"Good luck, Yukikaze.\"" });
        tooltip.addPara("%s", padSig, flavor, new String[] { "         \u2014 Major James Bukhar" });
    }

}