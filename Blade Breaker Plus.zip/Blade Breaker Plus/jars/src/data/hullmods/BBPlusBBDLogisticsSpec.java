package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.impl.hullmods.BaseLogisticsHullMod;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import java.util.HashSet;
import java.util.Set;
import java.awt.Color;
import data.campaign.ids.bbplus_HullMods;

public class BBPlusBBDLogisticsSpec extends BaseLogisticsHullMod {

    private static final Set<String> BLOCKED_HULLMODS = new HashSet();
    static
    {
        BLOCKED_HULLMODS.add("militarized_subsystems"); // sneed
    }

    @Override
    public void applyEffectsAfterShipCreation(final ShipAPI ship, final String id){
        for (final String tmp : BLOCKED_HULLMODS) {
            if (ship.getVariant().getHullMods().contains(tmp)) {                
                ship.getVariant().removeMod(tmp);
                DMEBlockedHullmodDisplayScript.showBlocked(ship);
                //ship.getVariant().addMod(ERROR);
            }
        }
    }

    @Override
    public String getDescriptionParam(final int index, final ShipAPI.HullSize hullSize) {
        if (index == 0) {
            return "hullmod spec";
        }
        return null;
    }

    @Override
    public boolean isApplicableToShip(final ShipAPI ship) {
        return !ship.getVariant().getHullMods().contains("militarized_subsystems");
    }
    
    @Override
    public String getUnapplicableReason(final ShipAPI ship) {
        if (ship.getVariant().hasHullMod("militarized_subsystems"))
	    return "Incompatible with Militarized Subsystems";
        return null;
    }	    
    
    @Override
    public void addPostDescriptionSection(final TooltipMakerAPI tooltip, final ShipAPI.HullSize hullSize, final ShipAPI ship, final float width, final boolean isForModSpec) {
        final Color deserter = new Color(105,105,120,255);
        final float pad = 10f;
        tooltip.addSectionHeading("Details", Alignment.MID, pad);
        tooltip.addPara("Allows the installation of the following hullmods. Only %s type of special logistic modspec is allowed.", pad, Misc.getHighlightColor(), new String[] { "one"});
        TooltipMakerAPI text = tooltip.beginImageWithText(Global.getSettings().getHullModSpec(bbplus_HullMods.BBD_CARGO).getSpriteName(), 36);
        text.addPara("Durable Cargo Frames" + "\n" + "Increases cargo capacity and lessens sensor profile." + "\n", 0, deserter, "Durable Cargo Frames");
        tooltip.addImageWithText(pad);
        text = tooltip.beginImageWithText(Global.getSettings().getHullModSpec(bbplus_HullMods.BBD_FUEL).getSpriteName(), 36);
        text.addPara("Calibrated Fuel Tanks" + "\n" + "Increases fuel capacity and lowers fuel consumption." + "\n", 0, deserter, "Calibrated Fuel Tanks");
        tooltip.addImageWithText(pad);
        text = tooltip.beginImageWithText(Global.getSettings().getHullModSpec(bbplus_HullMods.BBD_CREW).getSpriteName(), 36);
        text.addPara("Fortified Crew Quarters" + "\n" + "Increases crew capacity and reduces the chance of crew loss from combat." + "\n", 0, deserter, "Fortified Crew Quarters");
        tooltip.addImageWithText(pad);
        text = tooltip.beginImageWithText(Global.getSettings().getHullModSpec(bbplus_HullMods.BBD_SALVAGE).getSpriteName(), 36);
        text.addPara("Utility Drones" + "\n" + "Increases resources gained from salvage and faster repair/CR recovery rate." + "\n", 0, deserter, "Utility Drones");
        tooltip.addImageWithText(pad);
    }
    
}