package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;
import data.shipsystems.scripts.SkipjetParticleFX;

public class BBPlusBitControlSystem extends BaseHullMod {

    public static final float PERFECT_BONUS = 1f;
    //public static final float BEAM_RANGE_REDUCTION = 30f;
    private static final float PARTICLE_BASE_SIZE = 3f;
    private static final float PARTICLE_BASE_DURATION = 0.4f;
    private static final float PARTICLE_BASE_CHANCE = 0.8f;
    private static final float PARTICLE_BASE_BRIGHTNESS = 9.0f;
    private static final float PARTICLE_VELOCITY_MULT = 0.3f;
    private static final float CONE_ANGLE = 45f;
    private static final Color COLOR_FULL = new Color(205,15,15,255);
    private static final SkipjetParticleFX myParticleFX = new SkipjetParticleFX(
                PARTICLE_BASE_SIZE, PARTICLE_BASE_DURATION, PARTICLE_BASE_BRIGHTNESS,
                PARTICLE_BASE_CHANCE, PARTICLE_VELOCITY_MULT, CONE_ANGLE, COLOR_FULL
    );   
	
    @Override
    public void applyEffectsBeforeShipCreation(final HullSize hullSize, final MutableShipStatsAPI stats, final String id) {
        //stats.getBeamWeaponRangeBonus().modifyPercent(id, -BEAM_RANGE_REDUCTION);
        //stats.getEnergyWeaponRangeBonus().modifyPercent(id, -BEAM_RANGE_REDUCTION);
        stats.getAutofireAimAccuracy().modifyFlat(id, PERFECT_BONUS);
        stats.getDynamic().getMod(Stats.PD_BEST_TARGET_LEADING).modifyFlat(id, PERFECT_BONUS);
        stats.getDynamic().getMod(Stats.PD_IGNORES_FLARES).modifyFlat(id, PERFECT_BONUS);
    }
    
    @Override
    public void advanceInCombat(final ShipAPI ship, final float amount) {
        //for the asscancer giving GN Drive Tau particles
        myParticleFX.apply((ShipAPI) ship, Global.getCombatEngine(), 1f);
        //ship.getEngineController().extendFlame(this, 0f, 0f, 0f);
    }

    @Override
    public String getDescriptionParam(final int index, final HullSize hullSize) {
        return null;
    }
    // imagine using a fancy hullmod tooltip in a fucking hullmod that can't even be viewed IN THE GAME WOW WO WOOOOW!!!!!
    @Override
    public void addPostDescriptionSection(final TooltipMakerAPI tooltip, final ShipAPI.HullSize hullSize, final ShipAPI ship, final float width, final boolean isForModSpec) {
        final Color green = new Color(55,245,65,255);
        final float pad = 10f;
        final float padS = 0f;
        tooltip.addSectionHeading("Details", Alignment.MID, pad);
        tooltip.addPara("- Increased autofire accuracy: %s", pad, green, new String[] { Misc.getRoundedValue(100.0f) + "%" });
        tooltip.addPara("- Weapons will %s.", padS, Misc.getHighlightColor(), new String[] { "ignore flares" });
    }

}