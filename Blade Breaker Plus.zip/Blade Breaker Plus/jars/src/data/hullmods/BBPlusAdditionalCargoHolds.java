package data.hullmods;

import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.hullmods.BaseLogisticsHullMod;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;
import java.util.HashMap;
import java.util.Map;
import java.util.HashSet;
import java.util.Set;

public class BBPlusAdditionalCargoHolds extends BaseLogisticsHullMod {

    private static final Set<String> BLOCKED_HULLMODS = new HashSet();
    static
    {
        BLOCKED_HULLMODS.add("expanded_cargo_holds");
    }
    private static final Map mag = new HashMap();
    static {
        mag.put(HullSize.FIGHTER, 0f);        
        mag.put(HullSize.FRIGATE, 80f);
        mag.put(HullSize.DESTROYER, 160f);
        mag.put(HullSize.CRUISER, 300f);
        mag.put(HullSize.CAPITAL_SHIP, 400f);
    }
    private static final float PROFILE_MULT = 0.8f;
    public static final float BONUS_MULT = 5.00f;
    public static final float MIN_FRACTION = 0.5f;
    //public static final float CR_RECOVERY_BONUS = 15f;
	
    @Override
    public void applyEffectsBeforeShipCreation(final HullSize hullSize, final MutableShipStatsAPI stats, final String id) {
        //float mod = (Float) mag.get(hullSize);
        //if (stats.getVariant() != null) {
        //	mod = Math.max(stats.getVariant().getHullSpec().getCargo() * MIN_FRACTION, mod);
        //}
        stats.getCargoMod().modifyFlat(id, (Float) mag.get(hullSize));
        stats.getSensorProfile().modifyMult(id, PROFILE_MULT);
        //stats.getBaseCRRecoveryRatePercentPerDay().modifyPercent(id, CR_RECOVERY_BONUS);
        //stats.getCargoMod().modifyMult(id, BONUS_MULT);
    }

    @Override
    public void applyEffectsAfterShipCreation(final ShipAPI ship, final String id){
        for (final String tmp : BLOCKED_HULLMODS) {
            if (ship.getVariant().getHullMods().contains(tmp)) {                
                ship.getVariant().removeMod(tmp);
		DMEBlockedHullmodDisplayScript.showBlocked(ship);
                //ship.getVariant().addMod(ERROR);
            }
        }
    }

    @Override
    public String getDescriptionParam(final int index, final ShipAPI.HullSize hullSize) {
        // if (index == 0) {
        //    return Math.round(BONUS_MULT * 100f - 100f) + "%";
        //}
		//if (index == 0) return "" + ((Float) mag.get(HullSize.FRIGATE)).intValue();
		//if (index == 1) return "" + ((Float) mag.get(HullSize.DESTROYER)).intValue();
		//if (index == 2) return "" + ((Float) mag.get(HullSize.CRUISER)).intValue();
		//if (index == 3) return "" + ((Float) mag.get(HullSize.CAPITAL_SHIP)).intValue();
		//if (index == 4) return "" + (int) Math.round(MIN_FRACTION * 100f) + "%";
        //if (index == 5) return "" + 20 + "%";
        return null;
    }

    @Override
    public boolean isApplicableToShip(final ShipAPI ship) {
        return ship != null && (ship.getVariant().getHullMods().contains("bbplus_bbdlogistics")
                && (!(ship.getVariant().getHullMods().contains("bbplus_extrafueltanks"))
                && !(ship.getVariant().getHullMods().contains("bbplus_expandedcrewquarters"))
		&& !(ship.getVariant().getHullMods().contains("bbplus_utilitydrones"))
                && !(ship.getVariant().getHullMods().contains("expanded_cargo_holds"))
			));
    }

    @Override
    public String getUnapplicableReason(final ShipAPI ship) {
        if (ship == null || !ship.getVariant().getHullMods().contains("bbplus_bbdlogistics"))
            return "Can only be installed on a Blade Breaker hull with specialized logistic settings";
        if (ship.getVariant().getHullMods().contains("expanded_cargo_holds"))
            return "Incompatible with Expanded Cargo Holds";
        if (ship.getVariant().getHullMods().contains("bbplus_extrafueltanks"))
            return "Only one type of special logistic modspec is allowed";
        if (ship.getVariant().getHullMods().contains("bbplus_expandedcrewquarters"))
            return "Only one type of special logistic modspec is allowed";
        if (ship.getVariant().getHullMods().contains("bbplus_utilitydrones"))
            return "Only one type of special logistic modspec is allowed";
        return null;
    }
	
    @Override
    public void addPostDescriptionSection(final TooltipMakerAPI tooltip, final ShipAPI.HullSize hullSize, final ShipAPI ship, final float width, final boolean isForModSpec) {
        final Color green = new Color(55,245,65,255);
        final float pad = 10f;
        tooltip.addSectionHeading("Incompatibilities", Alignment.MID, pad);
        tooltip.addPara("- %s", pad, Misc.getNegativeHighlightColor(), new String[] { "Expanded Cargo Holds" });	
        tooltip.addSectionHeading("Details", Alignment.MID, pad);
        tooltip.addPara("- Increases maximum cargo capacity: %s/%s/%s/%s flat \n- Reduces sensor profile: %s", pad, green, new String[] { Misc.getRoundedValue(80.0f) + "", Misc.getRoundedValue(160.0f) + "", Misc.getRoundedValue(300.0f) + "", Misc.getRoundedValue(400.0f) + "", Misc.getRoundedValue(20.0f) + "%"});		
    }

}