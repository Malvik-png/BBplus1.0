package data.hullmods;

import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.hullmods.BaseLogisticsHullMod;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.util.Misc;
import java.util.HashMap;
import java.util.Map;
import java.awt.Color;

public class BBPlusUtilityDrone extends BaseLogisticsHullMod {

    private static final Map mag = new HashMap();
        static
        {
            mag.put(HullSize.FIGHTER, 0f);
            mag.put(HullSize.FRIGATE, 0.06f);
            mag.put(HullSize.DESTROYER, 0.08f);
            mag.put(HullSize.CRUISER, 0.12f);
            mag.put(HullSize.CAPITAL_SHIP, 0.20f);
        } 
    //salvaging your mum and ur sister
    //private static final float SALVAGE_RATE_BONUS = 0.25f;
    public static final float REPAIR_RATE_BONUS = 25f;
    public static final float CR_RECOVERY_BONUS = 25f;  
	
    @Override
    public void applyEffectsBeforeShipCreation(final ShipAPI.HullSize hullSize, final MutableShipStatsAPI stats, final String id) {
        //stats.getDynamic().getMod("salvage_value_bonus_ship").modifyFlat(id, ((Float)SALVAGE_RATE_BONUS));
        stats.getDynamic().getMod("salvage_value_bonus_ship").modifyFlat(id, (Float) mag.get(hullSize));
        stats.getBaseCRRecoveryRatePercentPerDay().modifyPercent(id, CR_RECOVERY_BONUS);
        stats.getRepairRatePercentPerDay().modifyPercent(id, REPAIR_RATE_BONUS);
    }
  
    @Override
    public String getDescriptionParam(final int index, final ShipAPI.HullSize hullSize)  {
        //if (index == 0) return "" + (int) (SALVAGE_RATE_BONUS * 100f) + "%";
        //if (index == 1) return "" + (int) REPAIR_RATE_BONUS + "%";
        return null;
    }

    @Override
    public boolean isApplicableToShip(final ShipAPI ship) {
        return ship != null && (ship.getVariant().getHullMods().contains("bbplus_bbdlogistics")
            && (!(ship.getVariant().getHullMods().contains("bbplus_additionalcargoholds"))
            && !(ship.getVariant().getHullMods().contains("bbplus_extrafueltanks"))
            && !(ship.getVariant().getHullMods().contains("bbplus_expandedcrewquarters"))
        ));
    }

    @Override
    public String getUnapplicableReason(final ShipAPI ship) {
        if (ship == null || !ship.getVariant().getHullMods().contains("bbplus_bbdlogistics"))
            return "Can only be installed on a Blade Breaker hull with specialized logistic settings";
        if (ship.getVariant().getHullMods().contains("bbplus_expandedcrewquarters"))
            return "Only one type of special logistic modspec is allowed";
        if (ship.getVariant().getHullMods().contains("bbplus_additionalcargoholds"))
            return "Only one type of special logistic modspec is allowed";
        if (ship.getVariant().getHullMods().contains("bbplus_extrafueltanks"))
            return "Only one type of special logistic modspec is allowed";
        return null;
    }

    @Override
    public void addPostDescriptionSection(final TooltipMakerAPI tooltip, final ShipAPI.HullSize hullSize, final ShipAPI ship, final float width, final boolean isForModSpec) {
        final Color green = new Color(55,245,65,255);
        final float pad = 10f;	
        tooltip.addSectionHeading("Details", Alignment.MID, pad);
        tooltip.addPara("- Increased salvaging bonus up to a fleetwide maximum equal to the salvage difficulty rating: %s/%s/%s/%s \n- Increased CR recovery and repair rates: %s", pad, green, new String[] { Misc.getRoundedValue(6.0f) + "%", Misc.getRoundedValue(8.0f) + "%", Misc.getRoundedValue(12.0f) + "%", Misc.getRoundedValue(20.0f) + "%", Misc.getRoundedValue(25.0f) + "%" });		
    }

}