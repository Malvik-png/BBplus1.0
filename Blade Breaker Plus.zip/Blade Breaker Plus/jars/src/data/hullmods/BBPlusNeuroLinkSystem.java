package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;

public class BBPlusNeuroLinkSystem extends BaseHullMod {

    private static final float MAX_SPEED = 15f;
    public static final float TURN_SPEED = 20f;
    public static final float TURN_ACCELERATION = 20f;
    public static final float ACCELERATION_BONUS = 35f;
    public static final float TURRET_SPEED_BONUS = 25f;
    public static final float AUTOFIRE_BONUS = 50f;
    public static final float DEGRADE_INCREASE_PERCENT = 40f;
    
    @Override
    public void applyEffectsBeforeShipCreation(final HullSize hullSize, final MutableShipStatsAPI stats, final String id) {
        stats.getAutofireAimAccuracy().modifyFlat(id, AUTOFIRE_BONUS * 0.01f);
        stats.getMaxSpeed().modifyFlat(id, MAX_SPEED);
        stats.getMaxTurnRate().modifyPercent(id, TURN_SPEED);
        stats.getTurnAcceleration().modifyPercent(id, TURN_ACCELERATION);
        stats.getAcceleration().modifyPercent(id, ACCELERATION_BONUS);
        stats.getWeaponTurnRateBonus().modifyPercent(id, TURRET_SPEED_BONUS);
        stats.getBeamWeaponTurnRateBonus().modifyPercent(id, TURRET_SPEED_BONUS);
        stats.getCRLossPerSecondPercent().modifyPercent(id, DEGRADE_INCREASE_PERCENT);
        stats.getDynamic().getMod(Stats.PD_IGNORES_FLARES).modifyFlat(id, 1f);
        stats.getDynamic().getMod(Stats.PD_BEST_TARGET_LEADING).modifyFlat(id, 1f);
    }
    
    @Override
    public String getDescriptionParam(final int index, final HullSize hullSize) {
        return null;
    }

    @Override
    public boolean isApplicableToShip(final ShipAPI ship) {
        return ship != null && (ship.getHullSpec().getNoCRLossTime() < 10000 || ship.getHullSpec().getCRLossPerSecond() > 0); 
    }

    @Override
    public void addPostDescriptionSection(final TooltipMakerAPI tooltip, final ShipAPI.HullSize hullSize, final ShipAPI ship, final float width, final boolean isForModSpec) {
        final Color green = new Color(55,245,65,255);
        final Color red = new Color(255,0,0,255);
        final Color flavor = new Color(110,110,110,255);
        final float pad = 10f;
        final float padNeg = 0.0f;
        final float padDesc = 1f;
        final float padQuote = 6f;
        final float padSig = 1f;   
        tooltip.addSectionHeading("Details", Alignment.MID, pad);
        tooltip.addPara("- Increased max speed: %s \n- Increased ship turn speed: %s \n- Increased acceleration: %s \n- Increased turret turn rate: %s \n- Increased weapon accuracy: %s", pad, green, new String[] { Misc.getRoundedValue(15.0f) + "%", Misc.getRoundedValue(20.0f) + "%", Misc.getRoundedValue(20.0f) + "%", Misc.getRoundedValue(35.0f) + "%", Misc.getRoundedValue(25.0f) + "%", Misc.getRoundedValue(50.0f) + "%" });		
        tooltip.addPara("- PD weapons will %s decoy flares and acquires best target lead.", padDesc, Misc.getHighlightColor(), new String[] { "ignore" });
        tooltip.addPara("- Increased CR decay after PPT expires: %s", padNeg, red, new String[] { Misc.getRoundedValue(40.0f) + "%" });
        tooltip.addPara("%s", padQuote, flavor, new String[] { "\"So this is what it feels like when you've become one with the ship... To serve the Council of Five in such way, ah~ this is pure ecstasy!\"" });
        tooltip.addPara("%s", padSig, flavor, new String[] { "         \u2014 Inferi during her first activation of Neurolink" });                  
    }

}