package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;

public class BBPlusBombardment extends BaseHullMod {
	// lessened bombardment costs because fuck you
    private static final String BOMBARD_BONUS_ID = "bbplus_bombardment";
    public static final float BOMBARDMENT_BONUS = 150.0f;

    @Override
    public void applyEffectsBeforeShipCreation(final HullSize hullSize, final MutableShipStatsAPI stats, final String id) {
       // stats.getDynamic().getMod(Stats.FLEET_BOMBARD_COST_REDUCTION).modifyMult(id, BOMBARDMENT_MULT);
    }
    
    @Override
    public void advanceInCampaign(final FleetMemberAPI member, final float amount) {//"bbplus_bombardment"
        member.getStats().getDynamic().getMod("fleet_bombard_cost_reduction").modifyFlat(BOMBARD_BONUS_ID, BOMBARDMENT_BONUS);
    }   
      
    @Override
    public String getDescriptionParam(final int index, final HullSize hullSize) {
        if (index == 0) return "additive" ;
        return null;
    }

    @Override
    public boolean isApplicableToShip(final ShipAPI ship) {
        return false;
    }

    @Override
    public String getUnapplicableReason(final ShipAPI ship) {
        return null;
    }    
    
    @Override
    public void addPostDescriptionSection(final TooltipMakerAPI tooltip, final ShipAPI.HullSize hullSize, final ShipAPI ship, final float width, final boolean isForModSpec) {
        final Color green = new Color(55,245,65,255);
        final Color flavor = new Color(110,110,110,255);
        final float pad = 10f;
        final float padQuote = 6f;
        final float padSig = 1f;
        tooltip.addSectionHeading("Details", Alignment.MID, pad);
        tooltip.addPara("- Reduced fuel cost for orbital bombardments: %s", pad, green, new String[] { Misc.getRoundedValue(150.0f) + "" });		
        tooltip.addPara("%s", padQuote, flavor, new String[] { "\"To clean the sector out; to purify the vermins. None shall defy the infallible visions of the Council of Five!\"" });
        tooltip.addPara("%s", padSig, flavor, new String[] { "         \u2014 Lenze Task Group Captain" });
    }	

}