package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;

public class BBPlusSGenFurnaceFlywheel extends BaseHullMod {

    private static final float SUPPLY_USE_MULT = 1.25f;
    public static final float DEGRADE_INCREASE_PERCENT = 30f;
    private final String BBreakerENG = "istl_bbengineering";
		
    @Override
    public void applyEffectsBeforeShipCreation(final HullSize hullSize, final MutableShipStatsAPI stats, final String id) {
        stats.getSuppliesPerMonth().modifyMult(id, SUPPLY_USE_MULT);
        stats.getCRLossPerSecondPercent().modifyPercent(id, DEGRADE_INCREASE_PERCENT);
    }
	
    @Override
    public String getDescriptionParam(final int index, final HullSize hullSize) {
        return null;
    }
					
    @Override
    public void addPostDescriptionSection(final TooltipMakerAPI tooltip, final ShipAPI.HullSize hullSize, final ShipAPI ship, final float width, final boolean isForModSpec) {
        final Color green = new Color(55,245,65,255);
        final Color red = new Color(255,0,0,255);
        final float pad = 10f;
        final float padS = 2f;
        final float padList = 3f;
        final float padSysDesc = 6f;	
        tooltip.addSectionHeading("Details", Alignment.MID, pad);
        tooltip.addPara("- Increased monthly supply cost: %s \n- Increased CR decay after PPT expires: %s", pad, red, new String[] { Misc.getRoundedValue(25.0f) + "%", Misc.getRoundedValue(30.0f) + "%"});		
        tooltip.addSectionHeading("Ship System Details", Alignment.MID, pad);
        TooltipMakerAPI text = tooltip.beginImageWithText(Global.getSettings().getSpriteName("tooltips", "sfield"), 42);
        text.addPara("Sigma Field" + "\n" + "Once the S-Particle Field are deployed in combat, these following effects will apply to friendly ships within the radius of Sigma Field. However, the ship will be unable to vent while the system is active.", padList, Global.getSettings().getColor("tooltipTitleAndLightHighlightColor"), "Sigma Field");
        tooltip.addImageWithText(pad);
	tooltip.addPara("- Rate of fire increased: %s \n- Reduces incoming EMP damage: %s \n- Reduces damage to shield: %s \n- Increased damage to missiles and fighters: %s \n- Increased zero-flux speed bonus: %s flat", padSysDesc, green, new String[] { Misc.getRoundedValue(10.0f) + "%", Misc.getRoundedValue(20.0f) + "%", Misc.getRoundedValue(20.0f) + "%", Misc.getRoundedValue(10.0f) + "%", Misc.getRoundedValue(10.0f) + ""});	
        text = tooltip.beginImageWithText(Global.getSettings().getHullModSpec(BBreakerENG).getSpriteName(), 36);
        text.addPara("Hulls with Blade Breaker Engineering will gain additional %s bonus to all aforementioned stats." + "\n", 0, green, new String[] { Misc.getRoundedValue(5.0f) + "%"});
        tooltip.addImageWithText(pad);
        tooltip.addPara("Multiple Sigma Field will not stack or add up together and morever, the periodic S-Particle discharge will be directed to nearby hostile contacts dealing %s.", padS, Misc.getHighlightColor(), new String[] { "EMP damage"});
    }	

    @Override
    public boolean isApplicableToShip(final ShipAPI ship) {
        return ship != null && (ship.getHullSpec().getNoCRLossTime() < 10000 || ship.getHullSpec().getCRLossPerSecond() > 0); 
    }

}