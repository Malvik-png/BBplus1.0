package data.shipsystems.scripts;

import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;

public class bbplus_SigmaFocusStats extends BaseShipSystemScript {

    public static final float DAMAGE_BONUS_PERCENT = 65f;
    public static final float ROF_BONUS = 10f;
    private static final float RANGE_MULT = 0.90f;
	
    @Override
    public void apply(final MutableShipStatsAPI stats, final String id, final State state, final float effectLevel) {	
        final float bonusPercent = DAMAGE_BONUS_PERCENT * effectLevel;
        stats.getEnergyWeaponDamageMult().modifyPercent(id, bonusPercent);
        stats.getEnergyRoFMult().modifyPercent(id, ROF_BONUS);
        stats.getEnergyWeaponRangeBonus().modifyMult(id, RANGE_MULT);
    }

    @Override
    public void unapply(final MutableShipStatsAPI stats, final String id) {
        stats.getEnergyWeaponDamageMult().unmodify(id);
        stats.getEnergyRoFMult().unmodify(id);
        stats.getEnergyWeaponRangeBonus().unmodify(id);
    }
	
    @Override
    public StatusData getStatusData(final int index, final State state, final float effectLevel) {
        final float bonusPercent = DAMAGE_BONUS_PERCENT * effectLevel;
        if (index == 0) {
            return new StatusData("+" + (int) bonusPercent + "% energy weapon damage and 10% increased rate of fire" , false);
        }
        if (index == 1) {
            return new StatusData("-10% energy weapon range", false);
        }
        return null;
    }
        
}