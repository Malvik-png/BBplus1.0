package data.shipsystems.scripts;

import java.awt.Color;
import java.util.List;
import java.util.ArrayList;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseEveryFrameCombatPlugin;
import com.fs.starfarer.api.combat.EveryFrameCombatPlugin;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipSystemAPI.SystemState;
import com.fs.starfarer.api.combat.ShipwideAIFlags.AIFlags;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.input.InputEventAPI;
import com.fs.starfarer.api.util.Misc;

@SuppressWarnings("UnusedAssignment")
public class bbplus_OverwhelmStats extends BaseShipSystemScript {
    
    public static final Object KEY_SHIP = new Object();
    public static final Object KEY_TARGET = new Object();    
    public static final Object KEY_JITTER = new Object();
    public static final float DAM_MULT = 1.41f;
    public static final float RANGE = 2500f;
    public static final float CLOCK_UP = 1.20f;
    public static final float BB_DAMAGE_PERCENT = 6f;
    public static final float BB_SPEED_PERCENT = 20f;
    public static final float AUTOFIRE_MULT = 1.69f;
    public static final Color TEXT_COLOR = new Color(105,255,205,255);
    public static final Color JITTER_COLOR = new Color(105,255,205,155);
    public static final Color SHIP_JITTER_COLOR = new Color(214,29,30,225);
    public static final Color JITTER_UNDER_COLOR = new Color(105,255,205,255);

    public static class TargetData {
        public ShipAPI ship;
        public ShipAPI target;
        public EveryFrameCombatPlugin targetEffectPlugin;
        public float currDamMult;
        public float elaspedAfterInState;
        public TargetData(final ShipAPI ship, final ShipAPI target)
        {
            this.ship = ship;
            this.target = target;
        }
    }
	
    @Override
    public void apply(final MutableShipStatsAPI stats, final String id, State state, final float effectLevel) {
        ShipAPI ship = null;
        final float shipTimeMult = 1f + (CLOCK_UP - 1f) * effectLevel;
        if (stats.getEntity() instanceof ShipAPI) {
            ship = (ShipAPI) stats.getEntity();
        } else {
            return;
        }	
        if (effectLevel > 0) {
            final float jitterLevel = effectLevel;
            final float maxRangeBonus = 5f;
            final float jitterRangeBonus = jitterLevel * maxRangeBonus;
            for (final ShipAPI fighter : getFighters(ship)) {
                if (fighter.isHulk()) continue;
                    final MutableShipStatsAPI fStats = fighter.getMutableStats();
                    fStats.getAutofireAimAccuracy().modifyFlat(id, AUTOFIRE_MULT - 1f);
                    fStats.getMaxRecoilMult().modifyMult(id, 1f + (AUTOFIRE_MULT - 1f) * effectLevel);
                    fStats.getRecoilPerShotMult().modifyMult(id, 1f + (AUTOFIRE_MULT - 1f) * effectLevel);
                    //fighter.setWeaponGlow(effectLevel, Misc.setAlpha(JITTER_UNDER_COLOR, 255), EnumSet.allOf(WeaponType.class));
                    // More bonuses if you use BB/BBD LPCS MUWAHAHAH!!!
                    if (!fighter.getVariant().getHullSpec().getHullId().startsWith("bbplus_") &&
                        !fighter.getVariant().getHullSpec().getHullId().startsWith("istl_")) continue;				
                            fStats.getBallisticWeaponDamageMult().modifyMult(id, 1f + 0.01f * BB_DAMAGE_PERCENT * effectLevel);
                            fStats.getEnergyWeaponDamageMult().modifyMult(id, 1f + 0.01f * BB_DAMAGE_PERCENT * effectLevel);
                            fStats.getBeamWeaponDamageMult().modifyMult(id, 1f + 0.01f * BB_DAMAGE_PERCENT * effectLevel);
                            fStats.getMissileWeaponDamageMult().modifyMult(id, 1f + 0.01f * BB_DAMAGE_PERCENT * effectLevel);			
                            fStats.getMaxSpeed().modifyPercent(id, BB_SPEED_PERCENT);
                            fStats.getMaxSpeed().modifyFlat(id, BB_SPEED_PERCENT / 2);
                            fStats.getAcceleration().modifyPercent(id, BB_SPEED_PERCENT * 2 * effectLevel);
                            fStats.getDeceleration().modifyPercent(id, BB_SPEED_PERCENT * 2 * effectLevel);                                
                            fStats.getTurnAcceleration().modifyFlat(id, BB_SPEED_PERCENT * effectLevel);
                            fStats.getTurnAcceleration().modifyPercent(id, BB_SPEED_PERCENT * effectLevel);
                            fStats.getMaxTurnRate().modifyFlat(id, BB_SPEED_PERCENT / 2);
                            fStats.getMaxTurnRate().modifyPercent(id, BB_SPEED_PERCENT / 2);
                            fStats.getTimeMult().modifyMult(id, shipTimeMult);				                 
                    if (jitterLevel > 0) {   
                        fighter.setJitterUnder(KEY_JITTER, JITTER_COLOR, jitterLevel, 4, 0f, jitterRangeBonus);
                        fighter.setJitter(KEY_JITTER, JITTER_UNDER_COLOR, jitterLevel, 2, 0f, 0 + jitterRangeBonus * 1f);
                        Global.getSoundPlayer().playLoop("system_targeting_feed_loop", ship, 1f, 1f, fighter.getLocation(), fighter.getVelocity());
                    }
            }
        }           
        final String targetDataKey = ship.getId() + "_entropy_target_data";
        Object targetDataObj = Global.getCombatEngine().getCustomData().get(targetDataKey);
        if (state == State.IN && targetDataObj == null) {
            final ShipAPI target = findTarget(ship);
            Global.getCombatEngine().getCustomData().put(targetDataKey, new TargetData(ship, target));
            if (target != null) {
                if (target.getFluxTracker().showFloaty() || 
                    ship == Global.getCombatEngine().getPlayerShip() ||
                    target == Global.getCombatEngine().getPlayerShip()) {
                    target.getFluxTracker().showOverloadFloatyIfNeeded("-Target Lock Acquired-", TEXT_COLOR, 4f, true);
                }
            }
            } else if (state == State.IDLE && targetDataObj != null) {
                Global.getCombatEngine().getCustomData().remove(targetDataKey);
                    ((TargetData)targetDataObj).currDamMult = 1f;
                        targetDataObj = null;
            }
            if (targetDataObj == null || ((TargetData) targetDataObj).target == null) return;
            final TargetData targetData = (TargetData) targetDataObj;
            targetData.currDamMult = 1f + (DAM_MULT - 1f) * effectLevel;
            if (targetData.targetEffectPlugin == null) {
                targetData.targetEffectPlugin = new BaseEveryFrameCombatPlugin() {
                @Override
                public void advance(final float amount, final List<InputEventAPI> events) {
                    if (Global.getCombatEngine().isPaused()) return;
                    if (targetData.target == Global.getCombatEngine().getPlayerShip()) { 
                        Global.getCombatEngine().maintainStatusForPlayerShip(KEY_TARGET, 
                            targetData.ship.getSystem().getSpecAPI().getIconSpriteName(),
                            targetData.ship.getSystem().getDisplayName(), 
                            "" + (int)((targetData.currDamMult - 1f) * 100f) + "% more damage taken", true);
                    }
					
                    if (targetData.currDamMult <= 1f || !targetData.ship.isAlive()) {
                        targetData.target.getMutableStats().getHullDamageTakenMult().unmodify(id);
                        targetData.target.getMutableStats().getArmorDamageTakenMult().unmodify(id);
                        targetData.target.getMutableStats().getShieldDamageTakenMult().unmodify(id);
                        targetData.target.getMutableStats().getEmpDamageTakenMult().unmodify(id);
                        Global.getCombatEngine().removePlugin(targetData.targetEffectPlugin);
                    } else {
                        targetData.target.getMutableStats().getHullDamageTakenMult().modifyMult(id, targetData.currDamMult);
                        targetData.target.getMutableStats().getArmorDamageTakenMult().modifyMult(id, targetData.currDamMult);
                        targetData.target.getMutableStats().getShieldDamageTakenMult().modifyMult(id, targetData.currDamMult);
                        targetData.target.getMutableStats().getEmpDamageTakenMult().modifyMult(id, targetData.currDamMult);
                    }
                }
               };
             Global.getCombatEngine().addPlugin(targetData.targetEffectPlugin);
            }

        if (effectLevel > 0) {
            float shipJitterLevel = 0;
            final float targetJitterLevel = effectLevel;			
            final float maxRangeBonus = 50f;
            final float jitterRangeBonus = shipJitterLevel * maxRangeBonus;
            final Color color = SHIP_JITTER_COLOR;  
            if (state != State.IN) {
                targetData.elaspedAfterInState += Global.getCombatEngine().getElapsedInLastFrame();
            }
            if (state == State.IN) {
                shipJitterLevel = effectLevel;
            } else {
                final float durOut = 0.5f;
                shipJitterLevel = Math.max(0, durOut - targetData.elaspedAfterInState) / durOut;
            }
            if (shipJitterLevel > 0) {
                //ship.setJitterUnder(KEY_SHIP, JITTER_UNDER_COLOR, shipJitterLevel, 21, 0f, 3f + jitterRangeBonus);
                ship.setJitter(KEY_SHIP, color, shipJitterLevel, 4, 0f, 0 + jitterRangeBonus * 1f);
            }
            if (targetJitterLevel > 0) {
                //target.setJitterUnder(KEY_TARGET, JITTER_UNDER_COLOR, targetJitterLevel, 5, 0f, 15f);
                targetData.target.setJitter(KEY_TARGET, color, targetJitterLevel, 3, 0f, 5f);
            }
        }
    }
	
    private List<ShipAPI> getFighters(final ShipAPI carrier) {
        final List<ShipAPI> result = new ArrayList<ShipAPI>();	
            for (final ShipAPI ship : Global.getCombatEngine().getShips()) {
                if (!ship.isFighter()) continue;
                if (ship.getWing() == null) continue;
                if (ship.getWing().getSourceShip() == carrier) {
                    result.add(ship);
                }
            }	
        return result;
    }        
	
    @Override
    public void unapply(final MutableShipStatsAPI stats, final String id) {
        ShipAPI ship = null;
        if (stats.getEntity() instanceof ShipAPI) {
            ship = (ShipAPI) stats.getEntity();
        } else {
            return;
        }
        for (final ShipAPI fighter : getFighters(ship)) {
            if (fighter.isHulk()) continue;
            final MutableShipStatsAPI fStats = fighter.getMutableStats();
            fStats.getBallisticWeaponDamageMult().unmodify(id);
            fStats.getEnergyWeaponDamageMult().unmodify(id);
            fStats.getMissileWeaponDamageMult().unmodify(id);		
            fStats.getMaxSpeed().unmodify(id);
            fStats.getMaxTurnRate().unmodify(id);
            fStats.getTurnAcceleration().unmodify(id);
            fStats.getAcceleration().unmodify(id);
            fStats.getDeceleration().unmodify(id);
            fStats.getTimeMult().unmodify(id);
        }
    }
	
    protected ShipAPI findTarget(final ShipAPI ship) {
        final float range = getMaxRange(ship);
        final boolean player = ship == Global.getCombatEngine().getPlayerShip();
        ShipAPI target = ship.getShipTarget();
        if (target != null) {
            final float dist = Misc.getDistance(ship.getLocation(), target.getLocation());
            final float radSum = ship.getCollisionRadius() + target.getCollisionRadius();
            if (dist > range + radSum) target = null;
            } else {
                if (target == null || target.getOwner() == ship.getOwner()) {
                    if (player) {
                        target = Misc.findClosestShipEnemyOf(ship, ship.getMouseTarget(), HullSize.FIGHTER, range, true);
                    } else {
                        final Object test = ship.getAIFlags().getCustom(AIFlags.MANEUVER_TARGET);
                        if (test instanceof ShipAPI) {
                            target = (ShipAPI) test;
                            final float dist = Misc.getDistance(ship.getLocation(), target.getLocation());
                            final float radSum = ship.getCollisionRadius() + target.getCollisionRadius();
                            if (dist > range + radSum) target = null;
                        }
                    }
                }
                if (target == null) {
                    target = Misc.findClosestShipEnemyOf(ship, ship.getLocation(), HullSize.FIGHTER, range, true);
                }
            }		
        return target;
    }
	
    protected float getMaxRange(final ShipAPI ship) {
        return RANGE;
    }

    @Override
    public StatusData getStatusData(final int index, final State state, final float effectLevel) {
        if (effectLevel > 0) {
            if (index == 0) {
                final float damMult = 1f + (DAM_MULT - 1f) * effectLevel;
                return new StatusData("" + (int)((damMult - 1f) * 100f) + "% more damage to target", false);
            }
            if (index == 1) {
                final float accMult = 1f + (AUTOFIRE_MULT - 1f) * effectLevel;
                return new StatusData("" + (int)((accMult - 1f) * 100f) + "% added fighter accuracy", false);
            }
        }
        return null;
    }

    @Override
    public String getInfoText(final ShipSystemAPI system, final ShipAPI ship) {
        final ShipAPI target = findTarget(ship);
        if (system.isOutOfAmmo()) {
            return null;
        }
        if (system.getState() != SystemState.IDLE) {
            return null;
        }
        if (target != null && target != ship) {
            return "READY";
        }
        if ((target == null) && ship.getShipTarget() != null) {
            return "OUT OF RANGE";
        }
        return "NO TARGET";
    }
	
    @Override
    public boolean isUsable(final ShipSystemAPI system, final ShipAPI ship) {
        final ShipAPI target = findTarget(ship);
        return target != null && target != ship;
    }

}