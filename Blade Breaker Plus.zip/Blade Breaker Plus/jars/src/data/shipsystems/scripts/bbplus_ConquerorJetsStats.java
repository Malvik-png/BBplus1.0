package data.shipsystems.scripts;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.plugins.ShipSystemStatsScript;
import java.awt.Color;

public class bbplus_ConquerorJetsStats extends BaseShipSystemScript {
	
    private static final float PARTICLE_BASE_SIZE = 2f;
    private static final float PARTICLE_BASE_DURATION = 0.5f;
    private static final float PARTICLE_BASE_CHANCE = 0.5f;
    private static final float PARTICLE_BASE_BRIGHTNESS = 8.0f;
    private static final float PARTICLE_VELOCITY_MULT = 0.3f;
    private static final float CONE_ANGLE = 48f;
    private static final Color COLOR_FULL = new Color(105,255,205,255);
    private static final SkipjetParticleFX myParticleFX = new SkipjetParticleFX(
            PARTICLE_BASE_SIZE, PARTICLE_BASE_DURATION, PARTICLE_BASE_BRIGHTNESS,
            PARTICLE_BASE_CHANCE, PARTICLE_VELOCITY_MULT, CONE_ANGLE, COLOR_FULL);

    @Override
    public void apply(final MutableShipStatsAPI stats, final String id, final State state, final float effectLevel) {
        final CombatEntityAPI ship = stats.getEntity();
        if (state == ShipSystemStatsScript.State.OUT) {
            stats.getMaxSpeed().modifyFlat(id, 0f);
            stats.getMaxSpeed().modifyPercent(id, 100f * effectLevel);
            stats.getMaxTurnRate().modifyPercent(id, 100f * effectLevel);
            stats.getAcceleration().modifyPercent(id, 150f * effectLevel);
            stats.getDeceleration().modifyPercent(id, 200f);
        } else {
            stats.getMaxSpeed().modifyFlat(id, 160f * effectLevel);
            stats.getMaxSpeed().modifyPercent(id, 16f * effectLevel);
            stats.getAcceleration().modifyPercent(id, 400f * effectLevel);
            stats.getDeceleration().modifyPercent(id, 270f * effectLevel);
            stats.getTurnAcceleration().modifyFlat(id, 150f * effectLevel);
            stats.getTurnAcceleration().modifyPercent(id, 300f * effectLevel);
            stats.getMaxTurnRate().modifyFlat(id, 60f * effectLevel);
            stats.getMaxTurnRate().modifyPercent(id, 120f * effectLevel);
            if (ship instanceof ShipAPI) {
                myParticleFX.apply((ShipAPI) ship,
                        Global.getCombatEngine(),
                        effectLevel);
            }
        }
    }
	
    @Override
    public void unapply(final MutableShipStatsAPI stats, final String id) {
        stats.getMaxSpeed().unmodify(id);
        stats.getMaxTurnRate().unmodify(id);
        stats.getTurnAcceleration().unmodify(id);
        stats.getAcceleration().unmodify(id);
        stats.getDeceleration().unmodify(id);
    }
	
    @Override
    public StatusData getStatusData(final int index, final State state, final float effectLevel) {
        if (index == 0) {
            return new StatusData("Improved maneuverability", false);
        } else if (index == 1) {
            return new StatusData("Increased top speed", false);
        }
        return null;
    }

}