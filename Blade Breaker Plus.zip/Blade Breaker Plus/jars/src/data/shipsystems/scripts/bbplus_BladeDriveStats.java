package data.shipsystems.scripts;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.plugins.ShipSystemStatsScript;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import java.awt.Color;
import org.lwjgl.util.vector.Vector2f;
import org.lazywizard.lazylib.VectorUtils;
import org.lazywizard.lazylib.MathUtils;
import data.scripts.util.MagicRender;
// Based on Nia Tahl's Crusher Drive ship system
public class bbplus_BladeDriveStats extends BaseShipSystemScript {

    private ShipAPI ship;
    public static final float INCOMING_DAMAGE_MULT = 0.6f;
    public static final float MASS_MULT = 4f;
    public static final float RANGE = 800f;
    private static final float PARTICLE_BASE_SIZE = 4f;
    private static final float PARTICLE_BASE_DURATION = 0.9f;
    private static final float PARTICLE_BASE_BRIGHTNESS = 9.2f;
    private static final float PARTICLE_BASE_CHANCE = 1.0f;
    private static final float PARTICLE_VELOCITY_MULT = 0.4f;
    private static final float CONE_ANGLE = 50f;
    private static final Color COLOR_FULL = new Color(105,255,155,255);	
    private Float mass = null;
    private static final SkipjetParticleFX myParticleFX = new SkipjetParticleFX(
	    PARTICLE_BASE_SIZE, PARTICLE_BASE_DURATION, PARTICLE_BASE_BRIGHTNESS,
            PARTICLE_BASE_CHANCE, PARTICLE_VELOCITY_MULT, CONE_ANGLE, COLOR_FULL);

    @Override
    public void apply(final MutableShipStatsAPI stats, final String id, final State state, float effectLevel) {
        this.ship = (ShipAPI)stats.getEntity();
        if (this.ship == null) {
            return;
        }        
        if (mass == null) {
            mass = this.ship.getMass();
        }       
        final ShipAPI target = this.ship.getShipTarget();
        final float turnrate = this.ship.getMaxTurnRate()*2;
	    effectLevel = 1f;
        if (state == ShipSystemStatsScript.State.OUT) {
            stats.getMaxSpeed().unmodify(id);
            this.ship.setMass(mass);
        }
        else {
            if (this.ship.getMass() == mass) {
                this.ship.setMass(mass * MASS_MULT);
            } 
            stats.getMaxSpeed().modifyFlat(id, 190f * effectLevel);
            stats.getAcceleration().modifyFlat(id, 130f * effectLevel);
            stats.getHullDamageTakenMult().modifyMult(id, 1f - (1f - INCOMING_DAMAGE_MULT) * effectLevel);
            stats.getArmorDamageTakenMult().modifyMult(id, 1f - (1f - INCOMING_DAMAGE_MULT ) * effectLevel);
            stats.getEmpDamageTakenMult().modifyMult(id, 1f - (1f - INCOMING_DAMAGE_MULT) * effectLevel);
            //CombatEntityAPI ship = stats.getEntity();
            if (this.ship instanceof ShipAPI) {
                myParticleFX.apply((ShipAPI) this.ship,
                        Global.getCombatEngine(),
                        effectLevel);
            }
            
            if(target!=null && this.ship.getSystem().isActive()){
                //system's aiming effect
                float facing = this.ship.getFacing();
                facing = MathUtils.getShortestRotation(
                        facing,
                        VectorUtils.getAngle(this.ship.getLocation(),
                        target.getLocation())
                    );
                this.ship.setAngularVelocity(Math.min(turnrate, Math.max(-turnrate, facing*5)));
            }		
        }     
        if (state == ShipSystemStatsScript.State.ACTIVE || state == ShipSystemStatsScript.State.IN) {
            MagicRender.objectspace(Global.getSettings().getSprite("bbplus_fx", "bbplus_blade_drive_slipstream"),
			(CombatEntityAPI)this.ship,
                        new Vector2f(10f, 0f), // offset up-down,left-right
                        new Vector2f(), // velocity
			new Vector2f(146.0f, 300.0f), //size width, height
			new Vector2f(), //growth
			180f, //angle
			0f, // spin
			true, //parent if true the sprite will also follow the anchor's orientation in addition to the position.
			new Color(100,255,190,5), //null
                        true, //true // additive: boolean for additive blending.
                        1f, //fadein
                        0f, //full in sec at maximum opacity (clamped by color). If attached to a projectile that value can be longer than the maximum flight time, for example 99s.
                        0.7f, //fadeout secs
                        true //fade on death
                    );
        }        
    }

    @Override
    public void unapply(final MutableShipStatsAPI stats, final String id) {
        this.ship = (ShipAPI)stats.getEntity();
        if (this.ship == null) {
            return;
        }    
        if (mass == null) {
            mass = this.ship.getMass();
        }  
        if (this.ship.getMass() != mass) {
            this.ship.setMass(mass);
        }
        stats.getMaxSpeed().unmodify(id);
        stats.getMaxTurnRate().unmodify(id);
        stats.getTurnAcceleration().unmodify(id);
        stats.getAcceleration().unmodify(id);
        stats.getDeceleration().unmodify(id);
        stats.getHullDamageTakenMult().unmodify(id);
        stats.getArmorDamageTakenMult().unmodify(id);
	    stats.getEmpDamageTakenMult().unmodify(id);       
    }

    @Override
    public StatusData getStatusData(final int index, final State state, float effectLevel) {
	effectLevel = 1f;
        final float percent = INCOMING_DAMAGE_MULT * effectLevel * 100;
        if (index == 0) {
            return new StatusData((int) (percent) + "% reduction to armor/hull damage and max speed increased", false);
        }
        return null;
    }

    @Override
    public String getInfoText(final ShipSystemAPI system, final ShipAPI ship) {
        final ShipAPI target = findTarget(ship);
        if (system.isOutOfAmmo()) {
            return null;
        }     
        if (system.getState() != ShipSystemAPI.SystemState.IDLE){
            return null;
        }    
        if (target != null && target != ship) {
            return "READY";
        }   
        if ((target == null || target == ship) && ship.getShipTarget() != null) {
            return "OUT OF RANGE";
        }     
        return "NO TARGET";
    }

    protected ShipAPI findTarget(final ShipAPI ship) {
        final ShipAPI target = ship.getShipTarget();
        if(target!=null && (!target.isDrone()||!target.isFighter()) && MathUtils.isWithinRange(ship, target, RANGE) && target.getOwner()!=ship.getOwner()){
            return target;
        } else {
            return null;
	    }
    }

}