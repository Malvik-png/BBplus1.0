package data.shipsystems.scripts;

import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.combat.FighterLaunchBayAPI;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.loading.FighterWingSpecAPI;

@SuppressWarnings("UnusedAssignment") // could you stop doing this fucking IDE fuck youu
public class bbplus_ReserveWingStats extends BaseShipSystemScript {
	
    public static final String RD_NO_EXTRA_CRAFT = "rd_no_extra_craft";
    public static final String RD_FORCE_EXTRA_CRAFT = "rd_force_extra_craft";
    public static final float EXTRA_FIGHTER_DURATION = 20;
	
    @Override
    public void apply(final MutableShipStatsAPI stats, final String id, final State state, final float effectLevel) {
        ShipAPI ship = null;
        if (stats.getEntity() instanceof ShipAPI) {
            ship = (ShipAPI) stats.getEntity();
        } else {
            return;
        }
        if (effectLevel == 1) {
            for (final FighterLaunchBayAPI bay : ship.getLaunchBaysCopy()) {
                if (bay.getWing() == null) continue;		
                    bay.makeCurrentIntervalFast();
                    final FighterWingSpecAPI spec = bay.getWing().getSpec();
                    final int addForWing = getAdditionalFor(spec);
                    final int maxTotal = spec.getNumFighters() + addForWing;
                    int actualAdd = maxTotal - bay.getWing().getWingMembers().size();
                    actualAdd = Math.min(spec.getNumFighters(), actualAdd);
                    if (actualAdd > 0) {
                        bay.setFastReplacements(bay.getFastReplacements() + addForWing);
                        bay.setExtraDeployments(actualAdd);
                        bay.setExtraDeploymentLimit(maxTotal);
                        bay.setExtraDuration(EXTRA_FIGHTER_DURATION);
                    }
            }
        }
    }

    public static int getAdditionalFor(final FighterWingSpecAPI spec) {
        final int size = spec.getNumFighters();
        if (spec.isBomber() && !spec.hasTag(RD_FORCE_EXTRA_CRAFT)) {
            return 1;
        } //0 
        if (spec.hasTag(RD_NO_EXTRA_CRAFT)) {
            return 0;
        }
        if (size <= 3) {
            return 1;
        }
        return 2;
    }

    @Override
    public void unapply(final MutableShipStatsAPI stats, final String id) {
        //have sex sex sex
    }
	
    @Override
    public StatusData getStatusData(final int index, final State state, final float effectLevel) {
        if (index == 0) {
            return new StatusData("deploying additional wings", false);
        }
        return null;
    }

    @Override
    public boolean isUsable(final ShipSystemAPI system, final ShipAPI ship) {
        return true;
    }
		
}