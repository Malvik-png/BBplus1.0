package data.shipsystems.scripts;

import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
//Placeholder for better shit
public class bbplus_SigmaFieldStats extends BaseShipSystemScript {

    @Override
    public void apply(final MutableShipStatsAPI stats, final String id, final State state, final float effectLevel) {
        //I
    }

    @Override
    public void unapply(final MutableShipStatsAPI stats, final String id) {
        //CAN'T
    }	

    @Override
    public StatusData getStatusData(final int index, final State state, final float effectLevel) {
        //SNEED
        return null;
    }
    
}