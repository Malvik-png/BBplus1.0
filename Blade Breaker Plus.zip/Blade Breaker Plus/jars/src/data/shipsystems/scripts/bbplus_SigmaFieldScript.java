package data.shipsystems.scripts;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.plugins.ShipSystemStatsScript;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipEngineControllerAPI.ShipEngineAPI;
import java.util.ArrayList;
import java.util.List;
import java.awt.Color;
import org.lazywizard.lazylib.combat.AIUtils;
import data.scripts.util.MagicRender;
import org.lwjgl.util.vector.Vector2f;
/**
 * Based on AE sympathetic system - Inventor Racoon, credits goes to him (:
 * @author Mayu
 */
public class bbplus_SigmaFieldScript extends BaseShipSystemScript {
	
    private ShipAPI ship;
    protected Object STATUSKEY1;
    private final List<ShipAPI> buffed;
    public static final float BUFF_RANGE = 650.0f;
    public static final float BB_EMP_REDUCTION = 0.75f;
    public static final float BB_DAMAGE_BONUS = 15f;
    public static final float BB_ROF_BONUS = 15f;
    public static final float BB_ZERO_FLUX_SPEED = 15f;
    public static final float BB_SHIELD_DAMAGE_REDUCTION = 0.8f;
    public static final float BB_SHIELD_UPKEEP = 0.65f;
    public static final float BB_CR_BONUS = 0.75f;
    public static final float EMP_REDUCTION = 0.80f;
    public static final float DAMAGE_BONUS = 10f;
    public static final float ROF_BONUS = 10f;
    public static final float ZERO_FLUX_SPEED = 10f;
    public static final float SHIELD_DAMAGE_REDUCTION = 0.9f;
    public static final float SHIELD_UPKEEP = 0.75f;
    public static final float CR_BONUS = 0.80f;
    public static final Color JITTER_COLOR = new Color(105,255,205,175);
    private static final float PARTICLE_BASE_SIZE = 3f;
    private static final float PARTICLE_BASE_DURATION = 0.4f;
    private static final float PARTICLE_BASE_CHANCE = 0.7f;
    private static final float PARTICLE_BASE_BRIGHTNESS = 8.0f;
    private static final float PARTICLE_VELOCITY_MULT = 0.3f;
    private static final float CONE_ANGLE = 45f;
    private static final Color COLOR_FULL = new Color(105,255,205,255);
    private static final SkipjetParticleFX myParticleFX = new SkipjetParticleFX(
		PARTICLE_BASE_SIZE, PARTICLE_BASE_DURATION, PARTICLE_BASE_BRIGHTNESS,
		PARTICLE_BASE_CHANCE, PARTICLE_VELOCITY_MULT, CONE_ANGLE, COLOR_FULL
    );

    public bbplus_SigmaFieldScript() {
        this.STATUSKEY1 = new Object();
        this.buffed = new ArrayList<ShipAPI>();
    }
    
    protected void maintainStatus(final ShipAPI ship, final ShipSystemStatsScript.State state, final float effectLevel) {
        final float level = effectLevel;
    }
    
    @Override
    public void apply(final MutableShipStatsAPI stats, String id, final ShipSystemStatsScript.State state, final float effectLevel) {
        final float level = effectLevel;
        this.ship = (ShipAPI)stats.getEntity();
        id = id + "_" + this.ship.getId();
        final boolean visible = MagicRender.screenCheck(0.1f, this.ship.getLocation());
        this.maintainStatus(this.ship, state, effectLevel);
        final List<ShipAPI> nearby = (List<ShipAPI>)AIUtils.getNearbyAllies((CombatEntityAPI)this.ship, BUFF_RANGE);
        final List<ShipAPI> previous = new ArrayList<ShipAPI>(this.buffed);
        if (!(stats.getEntity() instanceof ShipAPI)) {
            return;
        }
        if (Global.getCombatEngine().isPaused()) {
            return;
        }
        if (state == ShipSystemStatsScript.State.COOLDOWN || state == ShipSystemStatsScript.State.IDLE) {
            this.unapply(stats, id);
            return;
        }
        if (state == ShipSystemStatsScript.State.ACTIVE || state == ShipSystemStatsScript.State.IN) {
            MagicRender.objectspace(Global.getSettings().getSprite("graphics/fx/bbplus_sigmacircle.png"),
			//MagicRender.objectspace(Global.getSettings().getSprite("graphics/fx/bbplus_sigmagenglow.png"),
			(CombatEntityAPI)this.ship, new Vector2f(), new Vector2f(),
			new Vector2f(1350.0f, 1350.0f),
			new Vector2f(-100.0f, -100.0f),
			0.0f, 
			0.0f, // jitter fuck
			false,
			new Color(105,255,205,85), true, 0.1f, 0.0f, 0.1f, true
			);
        }
        if (stats.getEntity() instanceof ShipAPI && false) {
            final String key = this.ship.getId() + "_" + id;
            final Object test = Global.getCombatEngine().getCustomData().get(key);
            if (state == State.IN) {
                if (test == null && effectLevel > 0.2f) {
                    Global.getCombatEngine().getCustomData().put(key, new Object());
                    this.ship.getEngineController().getExtendLengthFraction().advance(1f);
                    for (final ShipEngineAPI engine : this.ship.getEngineController().getShipEngines()) {
                        if (engine.isSystemActivated()) {
                            this.ship.getEngineController().setFlameLevel(engine.getEngineSlot(), 1f);
                        }
                    }
                }
            }
            else {
                Global.getCombatEngine().getCustomData().remove(key);
            }
        }
        //final CombatEntityAPI ship = stats.getEntity();
        if (ship instanceof ShipAPI) {
                myParticleFX.apply((ShipAPI) this.ship, Global.getCombatEngine(), effectLevel);
        }
        if (state == ShipSystemStatsScript.State.ACTIVE) {            
            if (!nearby.isEmpty()) {
                for (final ShipAPI affected : nearby) {               
                    if (!previous.contains(affected)) {
                        this.applyBuff(affected, this.ship, level, visible);                      
                        this.buffed.add(affected);                        
                    }                                  
                    if (previous.contains(affected)) {
                        previous.remove(affected);
                        this.applyBuff(affected, this.ship, level, visible);
                    }
                    if (affected == Global.getCombatEngine().getPlayerShip()) {
                                Global.getCombatEngine().maintainStatusForPlayerShip(affected, //affected //bring back this. if that fucking thing didn't work
				this.ship.getSystem().getSpecAPI().getIconSpriteName(),
				this.ship.getSystem().getDisplayName(),
                                "Increased combat parameters", false);
                    }                    
                }
                if (!previous.isEmpty()) {
                    for (final ShipAPI s : previous) {
                        this.buffed.remove(s);
                        this.unapplyBuff(s);
                    }
                }
            }
            else if (!this.buffed.isEmpty()) {
                for (final ShipAPI affected : this.buffed) {
                    this.unapplyBuff(affected);
                }
                this.buffed.clear();
            }          
        } else if (state == ShipSystemStatsScript.State.OUT) {
            for (final ShipAPI affected : nearby) {
                if (!previous.contains(affected)) {
                    this.unapplyBuff(affected);                      
                    this.buffed.remove(affected);                        
                }                                  
                if (previous.contains(affected)) {
                    previous.remove(affected);
                    this.unapplyBuff(affected); 
                }            
            }
            if (!this.buffed.isEmpty()) {
                for (final ShipAPI affected : this.buffed) {
                    this.unapplyBuff(affected);
                }
            }
            this.buffed.clear();
        }
    }
    
    private void applyBuff(final ShipAPI ship, final ShipAPI source, final float level, final boolean visible) {
        ship.setJitter((Object)ship, JITTER_COLOR, 0.1f, 3, 5.0f);
        if (ship.getVariant().hasHullMod("istl_bbengineering")) {
        // For BB/BBD ships, additional bonuses, please play them :^]
            ship.getMutableStats().getEmpDamageTakenMult().modifyMult(ship.getId(), BB_EMP_REDUCTION); // 25% reduction
            ship.getMutableStats().getDamageToMissiles().modifyPercent(ship.getId(), BB_DAMAGE_BONUS);
            ship.getMutableStats().getDamageToFighters().modifyPercent(ship.getId(), BB_DAMAGE_BONUS);
            ship.getMutableStats().getBallisticRoFMult().modifyPercent(ship.getId(), BB_ROF_BONUS);
            ship.getMutableStats().getEnergyRoFMult().modifyPercent(ship.getId(), BB_ROF_BONUS);
            ship.getMutableStats().getMissileRoFMult().modifyPercent(ship.getId(), BB_ROF_BONUS);
               //ship.getMutableStats().getMaxSpeed().modifyFlat(ship.getId(), 25.0f);
            ship.getMutableStats().getZeroFluxSpeedBoost().modifyFlat(ship.getId(), BB_ZERO_FLUX_SPEED);
            ship.getMutableStats().getShieldDamageTakenMult().modifyMult(ship.getId(), BB_SHIELD_DAMAGE_REDUCTION); // 20% reduction
            ship.getMutableStats().getShieldUpkeepMult().modifyMult(ship.getId(), BB_SHIELD_UPKEEP);  // 35% reduce upkeep
            ship.getMutableStats().getCRLossPerSecondPercent().modifyMult(ship.getId(), BB_CR_BONUS);
        } else {
        // For Non-BB ships
            ship.getMutableStats().getEmpDamageTakenMult().modifyMult(ship.getId(), EMP_REDUCTION); // 20% reduction			
            ship.getMutableStats().getDamageToMissiles().modifyPercent(ship.getId(), DAMAGE_BONUS);
            ship.getMutableStats().getDamageToFighters().modifyPercent(ship.getId(), DAMAGE_BONUS);			
            ship.getMutableStats().getBallisticRoFMult().modifyPercent(ship.getId(), ROF_BONUS);
            ship.getMutableStats().getEnergyRoFMult().modifyPercent(ship.getId(), ROF_BONUS);
            ship.getMutableStats().getMissileRoFMult().modifyPercent(ship.getId(), ROF_BONUS);				
               //ship.getMutableStats().getMaxSpeed().modifyFlat(ship.getId(), 15.0f);
            ship.getMutableStats().getZeroFluxSpeedBoost().modifyFlat(ship.getId(), ZERO_FLUX_SPEED);
            ship.getMutableStats().getShieldDamageTakenMult().modifyMult(ship.getId(), SHIELD_DAMAGE_REDUCTION);
            ship.getMutableStats().getShieldUpkeepMult().modifyMult(ship.getId(), SHIELD_UPKEEP);
            ship.getMutableStats().getCRLossPerSecondPercent().modifyMult(ship.getId(), CR_BONUS);
        }
    }
    
    private void unapplyBuff(final ShipAPI ship) {
        ship.getMutableStats().getEmpDamageTakenMult().unmodify(ship.getId());
        ship.getMutableStats().getDamageToMissiles().unmodify(ship.getId());
        ship.getMutableStats().getDamageToFighters().unmodify(ship.getId());
        ship.getMutableStats().getBallisticRoFMult().unmodify(ship.getId());
        ship.getMutableStats().getEnergyRoFMult().unmodify(ship.getId());
        ship.getMutableStats().getMissileRoFMult().unmodify(ship.getId());
            //ship.getMutableStats().getMaxSpeed().unmodify(ship.getId());
        ship.getMutableStats().getZeroFluxSpeedBoost().unmodify(ship.getId());
        ship.getMutableStats().getShieldDamageTakenMult().unmodify(ship.getId());
        ship.getMutableStats().getShieldUpkeepMult().unmodify(ship.getId());
        ship.getMutableStats().getCRLossPerSecondPercent().unmodify(ship.getId());
    }
    
    @Override
    public ShipSystemStatsScript.StatusData getStatusData(final int index, final ShipSystemStatsScript.State state, final float effectLevel) {
        if (index == 0) {
            return new ShipSystemStatsScript.StatusData("Deploying Sigma Field... Improving combat ability of nearby allies.", false);
        }
        //if (index == 1) {
        //    return new ShipSystemStatsScript.StatusData("Active venting is disabled.", false);
        //}
        return null;
    }

}