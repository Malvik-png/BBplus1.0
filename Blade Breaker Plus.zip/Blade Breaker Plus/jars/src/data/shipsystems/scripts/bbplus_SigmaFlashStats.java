package data.shipsystems.scripts;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.util.IntervalUtil;
import org.lazywizard.lazylib.VectorUtils;
import java.awt.*;

@SuppressWarnings("UnusedAssignment")
public class bbplus_SigmaFlashStats extends BaseShipSystemScript {

    private static final Color FLICKER_COLOR = new Color(105,255,155,185);
    private static final Color AFTERIMAGE_COLOR = new Color(0, 255, 180, 100);
    private final Color color = new Color(105,255,155,35);
    public static final float MAX_TIME_MULT = 25f; //5f
    private final IntervalUtil interval = new IntervalUtil(0.05f, 0.05f);

    @Override
    public void apply(final MutableShipStatsAPI stats, String id, final State state, final float effectLevel) {
        ShipAPI ship = null;
        boolean player = false;
        final CombatEngineAPI engine = Global.getCombatEngine();
        if (stats.getEntity() instanceof ShipAPI) {
            ship = (ShipAPI) stats.getEntity();
            player = ship == Global.getCombatEngine().getPlayerShip();
            id = id + "_" + ship.getId();
        } else {
            return;
        }
        final float TimeMult = 1f + (MAX_TIME_MULT - 1f) * effectLevel;
        stats.getTimeMult().modifyMult(id, TimeMult);
        ship.getEngineController().fadeToOtherColor(this, color, new Color(0,0,0,0), effectLevel, 0.67f);
        final float driftamount = engine.getElapsedInLastFrame();
        interval.advance(engine.getElapsedInLastFrame());
        if (interval.intervalElapsed()) {
            ship.addAfterimage(AFTERIMAGE_COLOR,
                    0f,
                    0f,
                    ship.getVelocity().getX() * (-1f),
                    ship.getVelocity().getY() * (-1f),
                    5,0f,0.1f,0.5f,true,true,false);
        }
        if (null == state) {
            final float speed = ship.getVelocity().length();
            if (speed > ship.getMutableStats().getMaxSpeed().getModifiedValue()) {
                ship.getVelocity().normalise();
                ship.getVelocity().scale(speed - driftamount * 3600f);
            }
        } else switch (state) {
            case IN:
                ship.getMutableStats().getAcceleration().modifyFlat(id, 5000f);
                ship.getMutableStats().getDeceleration().modifyFlat(id, 5000f);
                break;
            case ACTIVE:
                {
                    ship.setPhased(true);
                    ship.setExtraAlphaMult(0.25f);
                    ship.setApplyExtraAlphaToEngines(true);
                    ship.setJitter(ship,FLICKER_COLOR,0.5f,5,5f,10f);
                    stats.getAcceleration().unmodify(id);
                    stats.getDeceleration().unmodify(id);
                    final float speed = ship.getVelocity().length();
                    if (speed <= 0.1f) {
                        ship.getVelocity().set(VectorUtils.getDirectionalVector(ship.getLocation(), ship.getVelocity()));
                    }
                    if (speed < 900f) {
                        ship.getVelocity().normalise();
                        ship.getVelocity().scale(speed + driftamount * 3600f);
                    }
                    break;
                }
            default:
                {
                    final float speed = ship.getVelocity().length();
                    if (speed > ship.getMutableStats().getMaxSpeed().getModifiedValue()) {
                        ship.getVelocity().normalise();
                        ship.getVelocity().scale(speed - driftamount * 3600f);
                    }
                    break;
                }
        }
    }

    @Override
    public void unapply(final MutableShipStatsAPI stats, String id) {
        ShipAPI ship = null;
        boolean player = false;
        if (stats.getEntity() instanceof ShipAPI) {
            ship = (ShipAPI) stats.getEntity();
            player = ship == Global.getCombatEngine().getPlayerShip();
            id = id + "_" + ship.getId();
        } else {
            return;
        }
        stats.getMaxTurnRate().unmodify(id);
        stats.getTurnAcceleration().unmodify(id);
        ship.setPhased(false);
        ship.setExtraAlphaMult(1f);
        stats.getTimeMult().unmodify(id);
        stats.getAcceleration().unmodify(id);
        stats.getDeceleration().unmodify(id);
        stats.getEmpDamageTakenMult().unmodify(id);
        stats.getHullDamageTakenMult().unmodify(id);
        stats.getArmorDamageTakenMult().unmodify(id);
    }

    @Override
    public StatusData getStatusData(final int index, final State state, final float effectLevel) {
        return null;
    }

    @Override
    public float getActiveOverride(final ShipAPI ship) {
        return -1;
    }

    @Override
    public float getInOverride(final ShipAPI ship) {
        return -1;
    }

    @Override
    public float getOutOverride(final ShipAPI ship) {
        return -1;
    }

    @Override
    public float getRegenOverride(final ShipAPI ship) {
        return -1;
    }

    @Override
    public int getUsesOverride(final ShipAPI ship) {
        return -1;
    }
    
}