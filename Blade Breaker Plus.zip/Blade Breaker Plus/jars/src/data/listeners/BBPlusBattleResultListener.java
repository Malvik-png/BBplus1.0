package data.scripts.listeners;

import static data.hullmods.BBPlusSigmaDriveInstaller.removeHullmod;
import static data.hullmods.BBPlusSigmaDriveInstaller.listContainsAny;
import static data.hullmods.BBPlusSigmaDriveInstaller.getMods;
import static data.hullmods.BBPlusSigmaDriveInstaller.HG_SIGMA;
import static data.hullmods.BBPlusSigmaDriveInstaller.LG_SIGMA;
import static data.hullmods.BBPlusSigmaDriveInstaller.U_SIGMA;
import com.fs.starfarer.api.campaign.BaseCampaignEventListener;
import com.fs.starfarer.api.campaign.EngagementResultForFleetAPI;
import com.fs.starfarer.api.combat.EngagementResultAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;

public class BBPlusBattleResultListener extends BaseCampaignEventListener {
    //this was expected to work so if it works then it just works
    //king_crimson.jpg
    public BBPlusBattleResultListener(final boolean register) {
        super(register);
    }

    @Override
    public void reportPlayerEngagement(final EngagementResultAPI result) {
        final EngagementResultForFleetAPI playerResult = result.didPlayerWin() ? result.getWinnerResult() : result.getLoserResult();
        for (final FleetMemberAPI ship : playerResult.getDestroyed()) {
            processShip(ship);
        }
        for (final FleetMemberAPI ship : playerResult.getDisabled()) {
            processShip(ship);
        }
    }
    
    private static void processShip(final FleetMemberAPI ship) {
        if (ship == null || ship.getVariant() == null) {
            return;
        }
        if (listContainsAny(ship.getVariant().getHullMods(), (Object[])getMods(HG_SIGMA))) {
            removeHullmod(ship, HG_SIGMA);
        }
        if (listContainsAny(ship.getVariant().getHullMods(), (Object[])getMods(LG_SIGMA))) {
            removeHullmod(ship, LG_SIGMA);
        }
        if (listContainsAny(ship.getVariant().getHullMods(), (Object[])getMods(U_SIGMA))) {
            removeHullmod(ship, U_SIGMA);
        }
    }
    
}