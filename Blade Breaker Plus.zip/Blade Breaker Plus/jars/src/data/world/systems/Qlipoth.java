package data.scripts.world.systems;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.CustomCampaignEntityAPI;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Entities;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.DerelictShipEntityPlugin;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.StarAge;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.StarCoronaTerrainPlugin;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;
import com.fs.starfarer.api.impl.campaign.terrain.DebrisFieldTerrainPlugin;
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin;
import com.fs.starfarer.api.impl.campaign.procgen.DefenderDataOverride;
import com.fs.starfarer.api.impl.campaign.procgen.themes.BaseThemeGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.themes.DerelictThemeGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.themes.SalvageSpecialAssigner;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.special.BaseSalvageSpecial;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.special.ShipRecoverySpecial;
import com.fs.starfarer.api.impl.campaign.terrain.DebrisFieldTerrainPlugin.DebrisFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.DebrisFieldTerrainPlugin.DebrisFieldSource;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;
import data.campaign.procgen.themes.BladeBreakerThemeGenerator;
import data.campaign.ids.istl_Entities;
import data.campaign.ids.istl_Factions;
import data.campaign.ids.istl_Tags;
import data.campaign.ids.istl_Commodities;
import data.campaign.ids.istl_Terrain;
// Half of the stars system codes are based from Soren's Lenze Constellation. Credits goes to him.
public class Qlipoth {
    
    public void generate(final SectorAPI sector) {
        final StarSystemAPI system = sector.createStarSystem("Qliphoth");
        //system.setProcgen(true);
        //system.isProcGen(true);
        ///final LocationAPI hyper = Global.getSector().getHyperspace();
        system.setBackgroundTextureFilename("graphics/backgrounds/background1.jpg");
        system.addTag("theme_hidden");
        //system.addTag("sun_sl_hidden");
        final PlanetAPI qlipoth_star = system.initStar(
                                            "qlipoth", // unique id for this star 
                                            "star_neutron",  // id in planets.json
                                            250f, 		  // radius (in pixels at default zoom)
                                            200, // corona
                                            0f, // solar wind burn level
                                            1f, // flare probability
                                            5.0f // CR loss multiplier, good values are in the range of 1-5
                );
        system.setLightColor(new Color(255, 255, 255));
        system.getLocation().set(-16500, -43500); // Located at the left outer fringe of Lenze
        // Death beams
        final SectorEntityToken qlipothPulsar1 = system.addTerrain(
                                Terrain.PULSAR_BEAM,
				new StarCoronaTerrainPlugin.CoronaParams(
                                            25000,
                                            12000,
                                            qlipoth_star,
                                            40f,
                                            0f,
                                            5f
                                )
                );
        qlipothPulsar1.setCircularOrbit(qlipoth_star, 0, 0, 15);
        // Fucking magnets how do they work
        final SectorEntityToken qlipoth_magneticfield = system.addTerrain(
                                Terrain.MAGNETIC_FIELD,
                                new MagneticFieldTerrainPlugin.MagneticFieldParams(
                                            700f, // terrain effect band width 
                                            750, // terrain effect middle radius
                                            qlipoth_star, // entity that it's around
                                            700f, // visual band start
                                            880f, // visual band end
                                            new Color(50, 20, 100, 40), // base color
                                            1f, // probability to spawn aurora sequence, checked once/day when no aurora in progress
			                    new Color(50, 120, 110, 130),
	                                    new Color(150, 130, 120, 150), 
			                    new Color(200, 150, 130, 190),
			                    new Color(250, 170, 150, 240),
			                    new Color(200, 180, 130, 255),
			                    new Color(75, 50, 160), 
			                    new Color(130, 60, 255)
                                )
                );
        qlipoth_magneticfield.setCircularOrbit(qlipoth_star, 0, 0, 150);        
        // Asteroid belt and dust ring shits
        system.addAsteroidBelt(qlipoth_star, 150, 2350, 500, 290, 310, Terrain.ASTEROID_BELT, "Shattered Souls");
        system.addRingBand(qlipoth_star, "misc", "rings_asteroids0", 256f, 0, Color.white, 256f, 2300, 360f, null, null);
        // Outerband
        system.addAsteroidBelt(qlipoth_star, 200, 9100, 300, 150, 400, Terrain.ASTEROID_BELT, "Road of Liminality");
        system.addRingBand(qlipoth_star, "misc", "rings_dust0", 300f, 1, Color.white, 250f, 9000, 320f, null, null);
        system.addRingBand(qlipoth_star, "misc", "rings_ice0", 300f, 1, Color.white, 250f, 9100, 300f, null, null);
        // Debris field
        final DebrisFieldTerrainPlugin.DebrisFieldParams params1 = new DebrisFieldTerrainPlugin.DebrisFieldParams(
                    290f, // field radius - should not go above 1000 for performance reasons
                    1.0f, // density, visual - affects number of debris pieces
                    10000000f, // duration in days 
                    0f); // days the field will keep generating glowing pieces
        params1.source = DebrisFieldTerrainPlugin.DebrisFieldSource.MIXED;
        params1.baseSalvageXP = 800; // base XP for scavenging in field
        final SectorEntityToken debrisAlpha = Misc.addDebrisField(system, params1, StarSystemGenerator.random);
        debrisAlpha.setSensorProfile(1000f);
        debrisAlpha.setDiscoverable(true);
        debrisAlpha.setCircularOrbit(qlipoth_star, 360*(float)Math.random(), 8750, 200f);
        debrisAlpha.setId("qliphoth_debris");
		
        //Asteroid field surrounding Gamchicoth
        final SectorEntityToken GamchicothL1 = system.addTerrain(Terrain.ASTEROID_FIELD,
            new AsteroidFieldParams(
                        340f, // min radius
                        680f, // max radius
                        20, // min asteroid count
                        30, // max asteroid count
                        7f, // min asteroid radius 
                        20f, // max asteroid radius
                        "Vestige of Hope")); // null for default name
        GamchicothL1.setCircularOrbit(qlipoth_star, 190f, 3250, 210f);
                
        final SectorEntityToken QliphothL2 = system.addTerrain(Terrain.ASTEROID_FIELD,
            new AsteroidFieldParams(
                        400f, // min radius
                        800f, // max radius
                        15, // min asteroid count
                        25, // max asteroid count
                        4f, // min asteroid radius 
                        25f, // max asteroid radius
                        "Qliphoth L2 Shoal Zone")); // null for default name
        QliphothL2.setCircularOrbit(qlipoth_star, 330f, 8050, 320f);
		
        // A crimson irradiated planet
        final PlanetAPI PlanetAdimiron = system.addPlanet("bbplus_planet_adimiron", qlipoth_star, "Adimiron", "irradiated", 75, 150, 1900, 180f);
        Misc.initConditionMarket(PlanetAdimiron);
        PlanetAdimiron.getMarket().addCondition(Conditions.VERY_HOT);
        PlanetAdimiron.getMarket().addCondition(Conditions.EXTREME_TECTONIC_ACTIVITY);
        PlanetAdimiron.getMarket().addCondition(Conditions.IRRADIATED);
        PlanetAdimiron.getMarket().addCondition(Conditions.RARE_ORE_MODERATE);
        PlanetAdimiron.getSpec().setPlanetColor(new Color(255, 90, 75, 255));
        PlanetAdimiron.applySpecChanges();
        PlanetAdimiron.setCustomDescriptionId("bbplus_planet_adimiron");
		
        // A granulated planetoid mined to death by Blade Breakers for their S-Bomb project
        final PlanetAPI PlanetGamchicoth = system.addPlanet("bbplus_planet_gamchicoth", qlipoth_star, "Gamchicoth", "barren2", 190, 105, 3250, 210f);
        Misc.initConditionMarket(PlanetGamchicoth);
        PlanetGamchicoth.getMarket().addCondition("bbplus_cracked_planet");
        PlanetGamchicoth.getMarket().addCondition(Conditions.RUINS_SCATTERED);
        PlanetGamchicoth.getMarket().addCondition(Conditions.IRRADIATED);
        PlanetGamchicoth.getMarket().addCondition(Conditions.VERY_HOT);
        PlanetGamchicoth.getMarket().addCondition(Conditions.LOW_GRAVITY);
        PlanetGamchicoth.getMarket().addCondition(Conditions.NO_ATMOSPHERE);
        PlanetGamchicoth.getMarket().addCondition(Conditions.METEOR_IMPACTS);
        PlanetGamchicoth.getMarket().addCondition(Conditions.ORE_SPARSE);
        PlanetGamchicoth.getMarket().addCondition(Conditions.RARE_ORE_SPARSE);
        PlanetGamchicoth.setCustomDescriptionId("bbplus_planet_gamchicoth");
			
        // Irradiated by intense Sigma-bombing test by the Blade Breakers in the past.
        final PlanetAPI PlanetNahemoth = system.addPlanet("bbplus_planet_nahemoth", qlipoth_star, "Nahemoth", "bbplus_sigma_planet", 55, 330, 6900, 310f);
        Misc.initConditionMarket(PlanetNahemoth);
        PlanetNahemoth.getMarket().addCondition("bbplus_sigmairradiated");
        PlanetNahemoth.getMarket().addCondition("bbplus_spatial_turbulence");
        PlanetNahemoth.getMarket().addCondition(Conditions.VERY_HOT);
        PlanetNahemoth.getMarket().addCondition(Conditions.HIGH_GRAVITY);
        PlanetNahemoth.getMarket().addCondition(Conditions.DENSE_ATMOSPHERE);
        PlanetNahemoth.getMarket().addCondition(Conditions.VOLATILES_DIFFUSE);
        PlanetNahemoth.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "aurorae"));
        PlanetNahemoth.getSpec().setGlowColor(new Color(165, 215, 255, 255));
        PlanetNahemoth.getSpec().setUseReverseLightForGlow(true);
        PlanetNahemoth.setCustomDescriptionId("bbplus_planet_nahemoth");
        system.addCorona(PlanetNahemoth, istl_Terrain.CORONA_SIGMA, // borrowed from Lenze
                            340f, // radius outside planet
                            10f, // burn level of "wind"
                            0f, // flare probability
                            2f // CR loss mult while in it
                            );
        final SectorEntityToken nahemoth_field1 = system.addTerrain(Terrain.MAGNETIC_FIELD,
        new MagneticFieldTerrainPlugin.MagneticFieldParams(
                            340f, // terrain effect band width 
                            335, // terrain effect middle radius
                            PlanetNahemoth, // entity that it's around
                            335f, // visual band start
                            345f, // visual band end
                            new Color(50, 30, 100, 120), // base color, increment brightness down by 15 each time
                            0.5f, // probability to spawn aurora sequence, checked once/day when no aurora in progress
                            new Color(50, 20, 110, 130), // Standard aurora colors.
                            new Color(150, 30, 120, 150), 
                            new Color(200, 50, 130, 190),
                            new Color(250, 70, 150, 240),
                            new Color(200, 80, 130, 255),
                            new Color(75, 0, 160), 
                            new Color(127, 0, 255)
                            ));
        nahemoth_field1.setCircularOrbit(PlanetNahemoth, 0, 0, 70);
        final SectorEntityToken nahemoth_field2 = system.addTerrain(Terrain.MAGNETIC_FIELD,
                            new MagneticFieldTerrainPlugin.MagneticFieldParams(
                            450f,
                            335,
                            PlanetNahemoth,
                            310f,
                            750f,
                            new Color(10, 25, 60, 5),
                            0.1f,
                            new Color(25, 60, 150, 120),
                            new Color(40, 90, 180, 135), 
                            new Color(50, 105, 195, 165),
                            new Color(60, 120, 210, 185),
                            new Color(70, 145, 225, 195),
                            new Color(10, 0, 125), 
                            new Color(15, 50, 100)
                            ));
        nahemoth_field2.setCircularOrbit(PlanetNahemoth, 0, 0, 85);
        final SectorEntityToken nahemoth_field3 = system.addTerrain(Terrain.MAGNETIC_FIELD,
                            new MagneticFieldTerrainPlugin.MagneticFieldParams(
                            90f,
                            335,
                            PlanetNahemoth,
                            335f,
                            340f,
                            new Color(165, 215, 255, 120),
                            0f,
                            new Color(25, 60, 150, 100),
                            new Color(40, 90, 180, 115), 
                            new Color(50, 105, 195, 145),
                            new Color(60, 120, 210, 160),
                            new Color(70, 145, 225, 170),
                            new Color(10, 0, 125), 
                            new Color(15, 50, 100)
                            ));
        nahemoth_field3.setCircularOrbit(PlanetNahemoth, 0, 0, 120);
        final SectorEntityToken nahemoth_field4 = system.addTerrain(Terrain.MAGNETIC_FIELD,
                            new MagneticFieldTerrainPlugin.MagneticFieldParams(
                            360f,
                            340,
                            PlanetNahemoth,
                            335f,
                            405f,
                            new Color(30, 105, 120, 90),
                            0.3f,
                            new Color(25, 90, 90, 130),
                            new Color(40, 120, 120, 150), 
                            new Color(50, 135, 135, 190),
                            new Color(60, 150, 150, 240),
                            new Color(70, 175, 175, 255),
                            new Color(40, 0, 125), 
                            new Color(45, 100, 100)
                            ));
        nahemoth_field4.setCircularOrbit(PlanetNahemoth, 0, 0, 100);
				
        // Deserter's hidden operational base behind Nahemoth's dark side
        final SectorEntityToken starkeep_sephira = system.addCustomEntity(
                "deserter_starkeep",
                "Starkeep Sephira",
                "bbplus_deserter_starkeep",
                "the_deserter_ex"
            );
        starkeep_sephira.setCircularOrbitPointingDown(qlipoth_star, 55, 7620, 310f);
        //starkeep_umbra.getMemoryWithoutUpdate().set("$abandonedStation", true);
        //Misc.setAbandonedStationMarket("deserter_starkeep_market", starkeep_umbra);
        //starkeep_umbra.setCustomDescriptionId("bbplus_starkeep_umbra");

        // Another planet to shield the dumb gate
        final PlanetAPI PlanetThagirion = system.addPlanet("bbplus_planet_thagirion", qlipoth_star, "Thagirion", "toxic", 120, 230, 9500, 390f);
        Misc.initConditionMarket(PlanetThagirion);
        PlanetThagirion.getMarket().addCondition(Conditions.IRRADIATED);
        PlanetThagirion.getMarket().addCondition(Conditions.TOXIC_ATMOSPHERE);
        PlanetThagirion.getMarket().addCondition(Conditions.DENSE_ATMOSPHERE);
        PlanetThagirion.getMarket().addCondition(Conditions.VERY_HOT);
        PlanetThagirion.getMarket().addCondition(Conditions.HIGH_GRAVITY);
        PlanetThagirion.getMarket().addCondition(Conditions.ORGANICS_PLENTIFUL);
        PlanetThagirion.getSpec().setPlanetColor(new Color(130, 60, 140, 255));
        PlanetThagirion.applySpecChanges();
        PlanetThagirion.setCustomDescriptionId("bbplus_planet_thagirion");             
  
        // Qliphoth Gate
        final SectorEntityToken QliphothGate = system.addCustomEntity("qliphoth_gate", // unique id
				 "Qliphoth Gate", // name - if null, defaultName from custom_entities.json will be used
				 Entities.INACTIVE_GATE, // type of object, defined in custom_entities.json
				 null); // faction
        QliphothGate.setCircularOrbit(qlipoth_star, 120, 10000, 390f);
        //Trash surrounding the gate
        final DebrisFieldParams params = new DebrisFieldParams(
				500f, // field radius - should not go above 1000 for performance reasons
				-1f, // density, visual - affects number of debris pieces
				10000000f, // duration in days 
				0f); // days the field will keep generating glowing pieces
        params.source = DebrisFieldSource.MIXED;
        params.baseSalvageXP = 250; // base XP for scavenging in field
        final SectorEntityToken debrisNextToGate = Misc.addDebrisField(system, params, StarSystemGenerator.random);
        debrisNextToGate.setSensorProfile(null);
        debrisNextToGate.setDiscoverable(null);
        debrisNextToGate.setCircularOrbit(QliphothGate, 0f, 0f, 100f);
        debrisNextToGate.setId("qliphoth_debrisNextToGate");                
                
        // Far-most planet in Qlipoth, Blade Breakers used to siphon it for volatiles
        final PlanetAPI PlanetGomaliel = system.addPlanet("bbplus_planet_gomaliel", qlipoth_star, "Gomaliel", "gas_giant", -120, 590, 14000, 620f);
        Misc.initConditionMarket(PlanetGomaliel);
        PlanetGomaliel.getMarket().addCondition(Conditions.POOR_LIGHT);
        PlanetGomaliel.getMarket().addCondition(Conditions.VERY_HOT); 
        PlanetGomaliel.getMarket().addCondition(Conditions.EXTREME_WEATHER);
        PlanetGomaliel.getMarket().addCondition(Conditions.DENSE_ATMOSPHERE);
        PlanetGomaliel.getMarket().addCondition(Conditions.HIGH_GRAVITY);
        PlanetGomaliel.getMarket().addCondition(Conditions.VOLATILES_PLENTIFUL);
        PlanetGomaliel.getSpec().setPlanetColor(new Color(200, 75, 20, 200));
        PlanetGomaliel.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "banded"));
        PlanetGomaliel.getSpec().setGlowColor(new Color(195, 220, 255, 255));
        PlanetGomaliel.getSpec().setAtmosphereThickness(0.8f);
        PlanetGomaliel.getSpec().setCloudRotation(18f);
        PlanetGomaliel.getSpec().setAtmosphereColor(new Color(240, 75, 20, 255));
        PlanetGomaliel.getSpec().setPitch(-6f);
        PlanetGomaliel.getSpec().setTilt(25f);
        PlanetGomaliel.applySpecChanges();
        system.addRingBand(PlanetGomaliel, "misc", "rings_dust0", 600f, 3, Color.gray, 220f, 1800, 150f, Terrain.RING, "Gomaliel's Obscenity");
        PlanetGomaliel.setCustomDescriptionId("bbplus_planet_gomaliel");
        final SectorEntityToken gomaliel_field = system.addTerrain(Terrain.MAGNETIC_FIELD,
                            new MagneticFieldTerrainPlugin.MagneticFieldParams(
                            590f, // terrain effect band width 
                            630, // terrain effect middle radius
                            PlanetGomaliel, // entity that it's around
                            640f, // visual band start, increment by 15
                            1250f, // visual band end
                            new Color(30, 105, 120, 90), // base color, increment brightness down by 15 each time
                            0.8f, // probability to spawn aurora sequence, checked once/day when no aurora in progress
                            new Color(25, 90, 90, 130),
                            new Color(40, 120, 120, 150), 
                            new Color(50, 135, 135, 190),
                            new Color(60, 150, 150, 240),
                            new Color(70, 175, 175, 255),
                            new Color(40, 0, 125), 
                            new Color(45, 100, 100)
                            ));
        gomaliel_field.setCircularOrbit(PlanetGomaliel, 0, 0, 120);
        
        // Abandoned BB siphon station for lore shit
        final SectorEntityToken GomalielSiphon = system.addCustomEntity("qliphoth_siphon_station", "Qliphah-P 545", "bbplus_bladebreaker_siphon", "neutral");
        GomalielSiphon.setCircularOrbitPointingDown(system.getEntityById("bbplus_planet_gomaliel"), 0, 1030, 190f);
        //GomalielSiphon.setSurveyLevel(MarketAPI.SurveyLevel.NONE);
        GomalielSiphon.setSensorProfile(1f);
        GomalielSiphon.setDiscoverable(true);
        GomalielSiphon.setDiscoveryXP(1500f);
        GomalielSiphon.getDetectedRangeMod().modifyFlat("gen", 3000f);
        GomalielSiphon.addTag("bbplus_qliphah_p_545");
        //siphon_station.setCustomDescriptionId("siphon_station");
		
        // Fucking salvage goodies
        // Station behind Gamchicoth
        final SectorEntityToken stationDerelict1 = DerelictThemeGenerator.addSalvageEntity(system, istl_Entities.STATION_MINING_BREAKER, istl_Factions.BREAKERS);
        stationDerelict1.setId("qliphoth_derelict1");
        stationDerelict1.setCircularOrbit(qlipoth_star, 190, 3520, 210f);
        final CargoAPI extraStation1Salvage = Global.getFactory().createCargo(true);
        //extraStation1Salvage.addHullmods("bbplus_sm_highgrade", 1);
        //extraStation1Salvage.addHullmods("bbplus_sm_lowgrade", 1);
        //extraStation1Salvage.addHullmods("bbplus_sm_unstable", 1);
        extraStation1Salvage.addCommodity(istl_Commodities.SIGMA_MATTER_HIGH, 3);
        extraStation1Salvage.addCommodity(istl_Commodities.SIGMA_MATTER_LOW, 4);
        extraStation1Salvage.addCommodity(istl_Commodities.SIGMA_MATTER_UNSTABLE, 3);
        //BaseSalvageSpecial.setExtraSalvage(extraStation1Salvage, stationDerelict1.getMemoryWithoutUpdate(), -1); // change it for 0.95 below
        BaseSalvageSpecial.addExtraSalvage(extraStation1Salvage, stationDerelict1.getMemoryWithoutUpdate(), -1);
        Misc.setDefenderOverride(stationDerelict1, new DefenderDataOverride("blade_breakers", 1f, 5, 11));
		
        // Gomaliel's abandoned research station
        final SectorEntityToken stationDerelict2 = DerelictThemeGenerator.addSalvageEntity(system, istl_Entities.STATION_RESEARCH_BREAKER, istl_Factions.BREAKERS);
        stationDerelict2.setId("qliphoth_derelict2");
        stationDerelict2.setCircularOrbit(PlanetGomaliel, 180, 1050, 190f);
        final CargoAPI extraStation2Salvage = Global.getFactory().createCargo(true);
        //extraStation2Salvage.addSpecial(new SpecialItemData("fighter_chip", "bbplus_obscurer_wing"), 1);
        extraStation2Salvage.addCommodity(Commodities.ALPHA_CORE, 1);
        extraStation2Salvage.addCommodity(istl_Commodities.SIGMA_MATTER_HIGH, 3);
        extraStation2Salvage.addCommodity(istl_Commodities.SIGMA_MATTER_UNSTABLE, 2);
        //BaseSalvageSpecial.setExtraSalvage(extraStation2Salvage, stationDerelict2.getMemoryWithoutUpdate(), -1); // change it later below
        BaseSalvageSpecial.addExtraSalvage(extraStation2Salvage, stationDerelict2.getMemoryWithoutUpdate(), -1);
        Misc.setDefenderOverride(stationDerelict2, new DefenderDataOverride("blade_breakers", 1f, 5, 11));

        //L2 cache
        final SectorEntityToken L2Cache = DerelictThemeGenerator.addSalvageEntity(system, istl_Entities.WEAPONS_CACHE_BREAKER, istl_Factions.BREAKERS);
        L2Cache.setId("qliphoth_l2cache");
        L2Cache.setCircularOrbit(qlipoth_star, 330, 8000, 320f);
        Misc.setDefenderOverride(L2Cache, new DefenderDataOverride("blade_breakers", 1f, 6, 12));
        L2Cache.setDiscoverable(Boolean.TRUE);                
                
        // Derelict BB/BBD/DME/ETC ships
        this.addDerelict(system, qlipoth_star, "bbplus_venture_std", ShipRecoverySpecial.ShipCondition.GOOD, 2300f, true, "the_deserter_ex");
        this.addDerelict(system, qlipoth_star, "istl_starsylph_deserter_test", ShipRecoverySpecial.ShipCondition.BATTERED, 9050f, false, "the_deserter_ex");
        this.addDerelict(system, qlipoth_star, "bbplus_caprice_voyage", ShipRecoverySpecial.ShipCondition.BATTERED, 300 - 9050f, true, "the_deserter_ex");
        this.addDerelict(system, PlanetAdimiron, "bbplus_sunder_spt", ShipRecoverySpecial.ShipCondition.GOOD, 290f, true, "the_deserter_ex");
        this.addDerelict(system, L2Cache, "istl_reef_std", ShipRecoverySpecial.ShipCondition.BATTERED, 140f, true, "the_deserter");
        this.addDerelict(system, QliphothGate, "istl_mindanao_support", ShipRecoverySpecial.ShipCondition.GOOD, 350f, false, "dassault_mikoyan");                
        this.addDerelict(system, QliphothGate, "istl_centaur_export", ShipRecoverySpecial.ShipCondition.WRECKED, 125f, true, "dassault_mikoyan");
        this.addDerelict(system, QliphothGate, "omen_patrol", ShipRecoverySpecial.ShipCondition.BATTERED, 275f, true, "dassault_mikoyan");
        this.addDerelict(system, QliphothGate, "wolf_patrol", ShipRecoverySpecial.ShipCondition.BATTERED, 150 - 450f, true, "dassault_mikoyan");
        this.addDerelict(system, QliphothGate, "afflictor_patrol", ShipRecoverySpecial.ShipCondition.BATTERED, 450f, true, "dassault_mikoyan");
        this.addDerelict(system, QliphothGate, "istl_flatmouse_export2", ShipRecoverySpecial.ShipCondition.AVERAGE, 150f, true, "dassault_mikoyan");
        this.addDerelict(system, QliphothGate, "odyssey_improved", ShipRecoverySpecial.ShipCondition.AVERAGE, 900 - 300f, false, "dassault_mikoyan");                
        this.addDerelict(system, PlanetGomaliel, "bbplus_falcon_std", ShipRecoverySpecial.ShipCondition.GOOD, 200 - 1800f, false, "the_deserter_ex");
        this.addDerelict(system, PlanetGomaliel, "istl_demon_std", ShipRecoverySpecial.ShipCondition.PRISTINE, 3600 - 1800f, true, "the_deserter_ex");
        this.addDerelict(system, PlanetGomaliel, "bbplus_baikal_ass", ShipRecoverySpecial.ShipCondition.WRECKED, 1800f, false, "blade_breakers"); // no edgier baikal for you
		
        // 1st Jump Point
        final JumpPointAPI jumpPoint1 = Global.getFactory().createJumpPoint("fringe_jump", "Qliphoth's Passage");
        jumpPoint1.setCircularOrbit(system.getEntityById("qlipoth"), 2, 2300f, 200);
        jumpPoint1.setStandardWormholeToHyperspaceVisual();
        system.addEntity(jumpPoint1);
		
        // 2nd Jump Point
        final JumpPointAPI jumpPoint2 = Global.getFactory().createJumpPoint("fucking_jump_point", "Gomaliel's Jump Point");
        final OrbitAPI orbitouter = Global.getFactory().createCircularOrbit(PlanetGomaliel, 170, 2900, 160f);
        jumpPoint2.setOrbit(orbitouter);
        jumpPoint2.setStandardWormholeToHyperspaceVisual();
        system.addEntity(jumpPoint2);
        // Autogenerated Fucking Hyper Jumpoint
        system.autogenerateHyperspaceJumpPoints(true, true);
        // Nebula gas
        StarSystemGenerator.addSystemwideNebula(system, StarAge.OLD);
        //system.generateAnchorIfNeeded();
        //Alpha Site style hidden
        ///final NascentGravityWellAPI well = Global.getSector().createNascentGravityWell((SectorEntityToken)qlipoth_star, 0.0f);
        ///well.addTag("no_entity_tooltip");
        ///well.setColorOverride(new Color(255, 139, 0));
        ///hyper.addEntity((SectorEntityToken)well);
        ///well.autoUpdateHyperLocationBasedOnInSystemEntityAtRadius((SectorEntityToken)qlipoth_star, 10.0f);              
        //////CustomCampaignEntityAPI beacon = Global.getSector().getHyperspace().addCustomEntity(null, null, "istl_bladebreaker_beacon", Factions.NEUTRAL);
        // Hardened Bacon
        final SectorEntityToken anchor = system.getHyperspaceAnchor();
        final CustomCampaignEntityAPI beacon = BladeBreakerThemeGenerator.addBeacon(system, BladeBreakerThemeGenerator.BladeBreakerSystemType.DESTROYED);
        system.addTag(istl_Tags.THEME_BREAKER);
        system.addTag(istl_Tags.THEME_BREAKER_MAIN);
        system.addTag(istl_Tags.THEME_BREAKER_DESTROYED);
        beacon.setCircularOrbitPointingDown(anchor, 100, 300, 70f); //well,
        // Just in case because autism
        system.setEnteredByPlayer(false);
        // Suppress horni
        system.setDoNotShowIntelFromThisLocationOnMap(true);                  
        // Clean this shit up, janny                                 
        this.cleanup(system);
    }

    void cleanup(final StarSystemAPI system){
        final HyperspaceTerrainPlugin plugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain().getPlugin();
        final NebulaEditor editor = new NebulaEditor(plugin);
        final float minRadius = plugin.getTileSize() * 2f;
        final float radius = system.getMaxRadiusInHyperspace();
        editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius * 0.5f, 0, 360f);
        editor.clearArc(system.getLocation().x, system.getLocation().y, 0, radius + minRadius, 0, 360f, 0.25f);
    }
	
    private void addDerelict(final StarSystemAPI system, final SectorEntityToken focus, final String variantId, final ShipRecoverySpecial.ShipCondition condition, final float orbitRadius, final boolean recoverable, final String factionIdForShipName){
        final DerelictShipEntityPlugin.DerelictShipData params = new DerelictShipEntityPlugin.DerelictShipData(new ShipRecoverySpecial.PerShipData(variantId, condition), false);
        final SectorEntityToken ship = BaseThemeGenerator.addSalvageEntity(system, Entities.WRECK, Factions.NEUTRAL, params);
        ship.setDiscoverable(true);
        final float orbitDays = orbitRadius / (10f + (float) Math.random() * 5f);
        ship.setCircularOrbit(focus, (float) Math.random() * 360f, orbitRadius, orbitDays);
        if (recoverable) {
            final SalvageSpecialAssigner.ShipRecoverySpecialCreator creator = new SalvageSpecialAssigner.ShipRecoverySpecialCreator(null, 0, 0, false, null, null);
            Misc.setSalvageSpecial(ship, creator.createSpecial(ship, null));
        }
    }

}