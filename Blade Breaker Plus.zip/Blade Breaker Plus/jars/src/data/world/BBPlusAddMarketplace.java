package data.scripts.world;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.econ.EconomyAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import java.util.ArrayList;

public class BBPlusAddMarketplace{

    public static MarketAPI addMarketplace(final String factionID, final SectorEntityToken primaryEntity, final ArrayList<SectorEntityToken> connectedEntities, final String name, 
        final int size, final ArrayList<String> marketConditions, final ArrayList<String> Industries, final ArrayList<String> submarkets, final float tarrif) {  
        final EconomyAPI globalEconomy = Global.getSector().getEconomy();
        final String planetID = primaryEntity.getId();
        final String marketID = planetID;
        final MarketAPI newMarket = Global.getFactory().createMarket(marketID, name, size);
        
        newMarket.setFactionId(factionID);
        newMarket.setPrimaryEntity(primaryEntity);
        newMarket.getTariff().modifyFlat("generator", tarrif);
              
        if (null != submarkets){  
            for (final String market : submarkets){  
                newMarket.addSubmarket(market);  
            }  
        }  
              
        for (final String condition : marketConditions) {  
            newMarket.addCondition(condition);  
        }
        
        for (final String industry : Industries) {
            newMarket.addIndustry(industry);
        }
              
        if (null != connectedEntities) {  
            for (final SectorEntityToken entity : connectedEntities) {  
                newMarket.getConnectedEntities().add(entity);  
            }  
        }  
            
        globalEconomy.addMarket(newMarket, true);  
        primaryEntity.setMarket(newMarket);
        primaryEntity.setFaction(factionID);
              
        if (null != connectedEntities) {  
            for (final SectorEntityToken entity : connectedEntities) {  
                entity.setMarket(newMarket);
                entity.setFaction(factionID);
            }  
        }
        return newMarket;
    }

}