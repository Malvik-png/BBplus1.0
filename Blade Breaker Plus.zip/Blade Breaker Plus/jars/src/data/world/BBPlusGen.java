package data.scripts.world;

import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.RepLevel;
import com.fs.starfarer.api.campaign.SectorGeneratorPlugin;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import data.scripts.world.systems.Qlipoth;
//import com.fs.starfarer.api.impl.campaign.ids.BBPlus_People;
public class BBPlusGen implements SectorGeneratorPlugin {
    
    @Override
    public void generate(final SectorAPI sector) {
	initFactionRelationships(sector);
        new Qlipoth().generate(sector);
        //new BBPlus_People().advance();
    }
	
    public static void initFactionRelationships(final SectorAPI sector) {
		
        FactionAPI the_deserter_ex = sector.getFaction("the_deserter_ex");
        FactionAPI hegemony = sector.getFaction(Factions.HEGEMONY);
        FactionAPI tritachyon = sector.getFaction(Factions.TRITACHYON);
        FactionAPI pirates = sector.getFaction(Factions.PIRATES);
        FactionAPI independent = sector.getFaction(Factions.INDEPENDENT);
        FactionAPI kol = sector.getFaction(Factions.KOL);
        FactionAPI church = sector.getFaction(Factions.LUDDIC_CHURCH);
        FactionAPI path = sector.getFaction(Factions.LUDDIC_PATH);
        FactionAPI diktat = sector.getFaction(Factions.DIKTAT);
	    FactionAPI guard = sector.getFaction(Factions.LIONS_GUARD);
        FactionAPI league = sector.getFaction(Factions.PERSEAN);
        FactionAPI remnants = sector.getFaction(Factions.REMNANTS);
	    FactionAPI derelict = sector.getFaction(Factions.DERELICT);
	    FactionAPI player = sector.getFaction(Factions.PLAYER);
		
	    the_deserter_ex.setRelationship(player.getId(), RepLevel.NEUTRAL);
        the_deserter_ex.setRelationship(hegemony.getId(), RepLevel.HOSTILE);
        the_deserter_ex.setRelationship(tritachyon.getId(), RepLevel.VENGEFUL);
        the_deserter_ex.setRelationship(pirates.getId(), RepLevel.VENGEFUL);
        the_deserter_ex.setRelationship(independent.getId(), RepLevel.HOSTILE);
        the_deserter_ex.setRelationship(kol.getId(), RepLevel.HOSTILE);
        the_deserter_ex.setRelationship(church.getId(), RepLevel.HOSTILE);
        the_deserter_ex.setRelationship(path.getId(), RepLevel.VENGEFUL);
        the_deserter_ex.setRelationship(diktat.getId(), RepLevel.HOSTILE);
	    the_deserter_ex.setRelationship(guard.getId(), RepLevel.HOSTILE);
        the_deserter_ex.setRelationship(league.getId(), RepLevel.HOSTILE);
        the_deserter_ex.setRelationship(remnants.getId(), RepLevel.VENGEFUL);
	    the_deserter_ex.setRelationship(derelict.getId(), RepLevel.VENGEFUL);
		
	    the_deserter_ex.setRelationship("dassault_mikoyan", RepLevel.HOSTILE);
	    the_deserter_ex.setRelationship("6eme_bureau", RepLevel.VENGEFUL);
	    the_deserter_ex.setRelationship("the_deserter", RepLevel.COOPERATIVE); // need to reflect same as nex config
        the_deserter_ex.setRelationship("magellan_protectorate", RepLevel.HOSTILE);
        the_deserter_ex.setRelationship("blade_breakers", RepLevel.HOSTILE);
	    the_deserter_ex.setRelationship("cabal", RepLevel.HOSTILE);
        the_deserter_ex.setRelationship("shadow_industry", RepLevel.HOSTILE);
        the_deserter_ex.setRelationship("blackrock_driveyards", RepLevel.HOSTILE);
        the_deserter_ex.setRelationship("exigency", RepLevel.HOSTILE);
        the_deserter_ex.setRelationship("tiandong", RepLevel.INHOSPITABLE);
        the_deserter_ex.setRelationship("diableavionics", RepLevel.HOSTILE);
        the_deserter_ex.setRelationship("ORA", RepLevel.SUSPICIOUS);
        the_deserter_ex.setRelationship("SCY", RepLevel.HOSTILE);
        the_deserter_ex.setRelationship("neutrinocorp", RepLevel.INHOSPITABLE);
        the_deserter_ex.setRelationship("interstellarimperium", RepLevel.HOSTILE);
        the_deserter_ex.setRelationship("syndicate_asp", RepLevel.INHOSPITABLE);
        the_deserter_ex.setRelationship("pack", RepLevel.INHOSPITABLE);
        the_deserter_ex.setRelationship("junk_pirates", RepLevel.HOSTILE);
        the_deserter_ex.setRelationship("fob", RepLevel.HOSTILE);
        the_deserter_ex.setRelationship("sylphon", RepLevel.HOSTILE);
        the_deserter_ex.setRelationship("nullorder", RepLevel.HOSTILE);
        the_deserter_ex.setRelationship("Coalition", RepLevel.HOSTILE);
        the_deserter_ex.setRelationship("vass_shipyards", RepLevel.HOSTILE);
        the_deserter_ex.setRelationship("nomads", RepLevel.HOSTILE);
        the_deserter_ex.setRelationship("crystanite", RepLevel.HOSTILE);
        the_deserter_ex.setRelationship("sad", RepLevel.HOSTILE);
        the_deserter_ex.setRelationship("new_galactic_order", RepLevel.VENGEFUL);
    }
    
}