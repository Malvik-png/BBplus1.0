package data.scripts.ai.projectiles;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.CollisionClass;
import com.fs.starfarer.api.combat.DamageType;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.MissileAPI;
import com.fs.starfarer.api.combat.GuidedMissileAI;
import com.fs.starfarer.api.combat.MissileAIPlugin;
import com.fs.starfarer.api.util.IntervalUtil;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.awt.Color;
import data.scripts.util.MagicRender;
import org.dark.shaders.distortion.DistortionAPI;
import org.dark.shaders.distortion.DistortionShader;
import org.dark.shaders.distortion.RippleDistortion;
import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.ReadableVector2f;
import org.lazywizard.lazylib.CollisionUtils;
import org.lazywizard.lazylib.combat.entities.SimpleEntity;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lazywizard.lazylib.combat.AIUtils;
import org.lazywizard.lazylib.MathUtils;

@SuppressWarnings("UnusedAssignment")
public class bbplus_ExocetBombletAI implements MissileAIPlugin, GuidedMissileAI {

    protected CombatEngineAPI engine;
    protected CombatEntityAPI target;
    protected final MissileAPI missile;
    private static final Map<Integer, Color> EXPLOSION_COLOR;
    private static final Map<Integer, Color> PARTICLE_COLOR;
    private static final Vector2f ZERO;
    private boolean hasCreatedFinalFX;
    private boolean showVFX;
    private boolean hasPlayedSound;
    private float finalDelay;
    private float reverseExplodeDelay;
    private float explodeDelay;
    private final IntervalUtil explodeInterval;
    private final float explodeDelayMax;
    private final float explosionRadius;
    private final float reverseExplodeDelayMax;
    public final boolean doOnce;
    public final float particleFXCount;
    public final float particleFXMaxDelay;
    public static final Color MIRV_SMOKE;
    static {
        (EXPLOSION_COLOR = new HashMap<Integer, Color>()).put(0, new Color(75,255,175,205));
        bbplus_ExocetBombletAI.EXPLOSION_COLOR.put(1, new Color(105,250,175,200));
        bbplus_ExocetBombletAI.EXPLOSION_COLOR.put(2, new Color(80,200,175,200));
        (PARTICLE_COLOR = new HashMap<Integer, Color>()).put(0, new Color(100,110,255,195));
        bbplus_ExocetBombletAI.PARTICLE_COLOR.put(1, new Color(100,255,175,205));
        bbplus_ExocetBombletAI.PARTICLE_COLOR.put(2, new Color(75,255,175,155));
        ZERO = new Vector2f();
        MIRV_SMOKE = new Color(25,200,125,75);
    }
    
    public bbplus_ExocetBombletAI(final MissileAPI missile, final ShipAPI launchingShip) {
        this.explodeInterval = new IntervalUtil(0.1f, 0.1f);
        this.finalDelay = 0.1f;
        this.hasCreatedFinalFX = false;
        this.reverseExplodeDelay = 0.3f;
        this.reverseExplodeDelayMax = 0.3f;
        this.explodeDelay = 1.5f;
        this.explodeDelayMax = 1.5f;
        this.explosionRadius = 600.0f;
        this.doOnce = false;
        this.hasPlayedSound = false;
        this.particleFXCount = 0.0f;
        this.particleFXMaxDelay = 0.1f;
        this.showVFX = false;
        if (this.engine != Global.getCombatEngine()) {
            this.engine = Global.getCombatEngine();
        }
        (this.missile = missile).setCollisionClass(CollisionClass.NONE);
        missile.setArmingTime(999999.0f);
        this.showVFX = Global.getSettings().getBoolean("bbplus_EnableVFX");
    }
    
    @Override
    public void advance(final float amount) {
        if (this.engine.isPaused() || this.missile.isFading()) {
            return;
        }
        if (!this.hasPlayedSound) {
            this.hasPlayedSound = true;
            Global.getSoundPlayer().playSound("bbplus_exo_blast_second", 1.0f, 1.0f, this.missile.getLocation(), this.missile.getVelocity());
        }
        if (this.explodeDelay > 0.0f) {
            this.explodeDelay -= amount;
            if (this.showVFX) {
                for (int i = MathUtils.getRandomNumberInRange(1, 3); i > 0; --i) {
                    final float axis = (float)Math.random() * 360.0f;
                    final float range = 800.0f;
                    this.engine.addHitParticle(MathUtils.getPointOnCircumference(this.missile.getLocation(), range, axis), MathUtils.getPointOnCircumference(bbplus_ExocetBombletAI.ZERO, range, axis + 180.0f), 10.0f + (float)Math.random() * 20.0f, 1.0f, 0.5f, (Color)bbplus_ExocetBombletAI.PARTICLE_COLOR.get(MathUtils.getRandomNumberInRange(0, 2)));
                }
            }
            this.engine.addHitParticle(this.missile.getLocation(), new Vector2f(), this.explosionRadius * (1.0f - this.explodeDelay / this.explodeDelayMax), 1.0f, 0.2f, (Color)bbplus_ExocetBombletAI.EXPLOSION_COLOR.get(MathUtils.getRandomNumberInRange(0, 2)));
            this.explodeInterval.advance(amount);
            if (this.explodeInterval.intervalElapsed()) {
                this.explodeLingeringDamage();
            }
            return;
        }
        if (this.reverseExplodeDelay > 0.0f) {
            this.reverseExplodeDelay -= amount;
            if (this.showVFX) {
                for (int i = MathUtils.getRandomNumberInRange(1, 3); i > 0; --i) {
                    final float axis = (float)Math.random() * 360.0f;
                    final float range = 800.0f;
                    this.engine.addHitParticle(MathUtils.getPointOnCircumference(this.missile.getLocation(), range, axis), MathUtils.getPointOnCircumference(bbplus_ExocetBombletAI.ZERO, range, axis + 180.0f), 10.0f + (float)Math.random() * 20.0f, 1.0f, 0.5f, (Color)bbplus_ExocetBombletAI.PARTICLE_COLOR.get(MathUtils.getRandomNumberInRange(0, 2)));
                }
            }
            this.engine.addHitParticle(this.missile.getLocation(), new Vector2f(), this.explosionRadius * (this.reverseExplodeDelay / this.reverseExplodeDelayMax), 1.0f, 0.2f, (Color)bbplus_ExocetBombletAI.EXPLOSION_COLOR.get(MathUtils.getRandomNumberInRange(0, 2)));
            return;
        }
        if (this.finalDelay > 0.0f) {
            this.finalDelay -= amount;
            if (!this.hasCreatedFinalFX) {
                this.hasCreatedFinalFX = true;
                //final float angle = 0.0f;
            }
            return;
        }
        final RippleDistortion wave = new RippleDistortion(this.missile.getLocation(), bbplus_ExocetBombletAI.ZERO);
        wave.setSize(this.explosionRadius * 3.0f);
        wave.setIntensity(200.0f);
        wave.setFrameRate(99.99999f);
        wave.fadeInSize(1.0f);
        wave.fadeOutIntensity(1.0f);
        DistortionShader.addDistortion((DistortionAPI)wave);
        this.explodeFX();
        this.explodeDamage();
    }
    
    private void explodeDamage() {
        final List<ShipAPI> closeEnemies = (List<ShipAPI>)AIUtils.getNearbyEnemies((CombatEntityAPI)this.missile, this.explosionRadius);
        final List<MissileAPI> closeMissiles = (List<MissileAPI>)AIUtils.getNearbyEnemyMissiles((CombatEntityAPI)this.missile, this.explosionRadius);
        Global.getSoundPlayer().playSound("bbplus_exo_blast", 1.0f, 1.0f, this.missile.getLocation(), this.missile.getVelocity());
        int k = 0;
        for (final ShipAPI ce : closeEnemies) {
            final float interceptAngle = VectorUtils.getAngle(this.missile.getLocation(), ce.getLocation());
            //final float complementOfIntercept = (interceptAngle > 180.0f) ? (interceptAngle - 180.0f) : (interceptAngle + 180.0f);
            CombatUtils.applyForce((CombatEntityAPI)ce, interceptAngle, 5.0f * (20.0f +280.0f * (MathUtils.getDistance(ce.getLocation(), this.missile.getLocation()) / this.explosionRadius)));
            float minimumDamage = 2000.0f;
            float scalingDamage = 400.0f * (this.explosionRadius - MathUtils.getDistance((CombatEntityAPI)ce, (CombatEntityAPI)this.missile)) / this.explosionRadius;
            float damageDealt = (scalingDamage < minimumDamage) ? minimumDamage : (minimumDamage + scalingDamage);
            if (ce.getHullSize() == ShipAPI.HullSize.FIGHTER) {
                minimumDamage = 2000.0f;
                scalingDamage = 400.0f * (this.explosionRadius - MathUtils.getDistance((CombatEntityAPI)ce, (CombatEntityAPI)this.missile)) / this.explosionRadius;
                damageDealt = ((scalingDamage < minimumDamage) ? minimumDamage : (minimumDamage + scalingDamage));
                this.engine.applyDamage((CombatEntityAPI)ce, ce.getLocation(), damageDealt, DamageType.ENERGY, 500.0f, false, true, (Object)this.missile.getSource());
            }
            else if (ce.getShield() != null && ce.getShield() != null && ce.getShield().isOn() && ce.getShield().isWithinArc(this.missile.getLocation())) {
                k = 0;
                do {
                    ++k;
                    final Vector2f vector2f;
                    final Vector2f point = vector2f = new Vector2f((ReadableVector2f)this.missile.getLocation());
                    vector2f.x += this.explosionRadius * ((float)Math.random() * 2.0f - 1.0f);
                    final Vector2f vector2f2 = point;
                    vector2f2.y += this.explosionRadius * ((float)Math.random() * 2.0f - 1.0f);
                    if (CollisionUtils.isPointWithinBounds(point, (CombatEntityAPI)ce)) {
                        minimumDamage = 2000.0f;
                        scalingDamage = 400.0f * (this.explosionRadius - MathUtils.getDistance((CombatEntityAPI)ce, (CombatEntityAPI)this.missile)) / this.explosionRadius;
                        damageDealt = ((scalingDamage < minimumDamage) ? minimumDamage : (minimumDamage + scalingDamage));
                        this.engine.applyDamage((CombatEntityAPI)ce, point, damageDealt, DamageType.ENERGY, 2000.0f, false, true, (Object)this.missile.getSource());
                        break;
                    }
                } while (k < 1000);
            }
            else {
                minimumDamage = 2000.0f;
                scalingDamage = 400.0f * (this.explosionRadius - MathUtils.getDistance((CombatEntityAPI)ce, (CombatEntityAPI)this.missile)) / this.explosionRadius;
                damageDealt = ((scalingDamage < minimumDamage) ? minimumDamage : (minimumDamage + scalingDamage));
                this.engine.applyDamage((CombatEntityAPI)ce, ce.getLocation(), damageDealt, DamageType.ENERGY, 2000.0f, false, true, (Object)this.missile.getSource());
            }
        }
        for (final MissileAPI cm : closeMissiles) {
            this.engine.applyDamage((CombatEntityAPI)cm, cm.getLocation(), this.missile.getDamageAmount(), DamageType.FRAGMENTATION, 0.0f, false, true, (Object)this.missile.getSource());
        }
        this.engine.applyDamage((CombatEntityAPI)this.missile, this.missile.getLocation(), this.missile.getHitpoints() * 2.0f, DamageType.FRAGMENTATION, 0.0f, false, false, (Object)this.missile);
    }
    
    private void explodeLingeringDamage() {
        final List<ShipAPI> closeEnemies = (List<ShipAPI>)AIUtils.getNearbyEnemies((CombatEntityAPI)this.missile, this.explosionRadius);
        final List<MissileAPI> closeMissiles = (List<MissileAPI>)AIUtils.getNearbyEnemyMissiles((CombatEntityAPI)this.missile, this.explosionRadius);
        final float lingeringExplosionRadius = this.explosionRadius * (1.0f - this.explodeDelay / this.explodeDelayMax);
        int k = 0;
        for (final ShipAPI ce : closeEnemies) {
            final float interceptAngle = VectorUtils.getAngle(ce.getLocation(), this.missile.getLocation());
            //final float complementOfIntercept = (interceptAngle > 180.0f) ? (interceptAngle - 180.0f) : (interceptAngle + 180.0f);
            CombatUtils.applyForce((CombatEntityAPI)ce, interceptAngle, 20.0f + 280.0f * (MathUtils.getDistance(ce.getLocation(), this.missile.getLocation()) / lingeringExplosionRadius));
            if (ce.getHullSize() == ShipAPI.HullSize.FIGHTER) {
                final float minimumDamage = 200.0f;
                final float scalingDamage = 200.0f * (lingeringExplosionRadius - MathUtils.getDistance((CombatEntityAPI)ce, (CombatEntityAPI)this.missile)) / this.explosionRadius;
                final float damageDealt = (scalingDamage < minimumDamage) ? minimumDamage : (minimumDamage + scalingDamage);
                this.engine.applyDamage((CombatEntityAPI)ce, ce.getLocation(), damageDealt, DamageType.ENERGY, 200.0f, false, true, (Object)this.missile.getSource());
            }
            else if (ce.getShield() != null && ce.getShield().isOn() && ce.getShield().isWithinArc(this.missile.getLocation())) {
                k = 0;
                do {
                    ++k;
                    final Vector2f vector2f;
                    final Vector2f point = vector2f = new Vector2f((ReadableVector2f)this.missile.getLocation());
                    vector2f.x += lingeringExplosionRadius * ((float)Math.random() * 2.0f - 1.0f);
                    final Vector2f vector2f2 = point;
                    vector2f2.y += lingeringExplosionRadius * ((float)Math.random() * 2.0f - 1.0f);
                    if (CollisionUtils.isPointWithinBounds(point, (CombatEntityAPI)ce)) {
                        final float minimumDamage = 200.0f;
                        final float scalingDamage = 200.0f * (lingeringExplosionRadius - MathUtils.getDistance((CombatEntityAPI)ce, (CombatEntityAPI)this.missile)) / lingeringExplosionRadius;
                        final float damageDealt = (scalingDamage < minimumDamage) ? minimumDamage : (minimumDamage + scalingDamage);
                        this.engine.applyDamage((CombatEntityAPI)ce, this.missile.getLocation(), damageDealt, DamageType.ENERGY, 200.0f, false, true, (Object)this.missile.getSource());
                        break;
                    }
                } while (k < 1000);
            }
            else {
                final float minimumDamage = 200.0f;
                final float scalingDamage = 200.0f * (lingeringExplosionRadius - MathUtils.getDistance((CombatEntityAPI)ce, (CombatEntityAPI)this.missile)) / lingeringExplosionRadius;
                final float damageDealt = (scalingDamage < minimumDamage) ? minimumDamage : (minimumDamage + scalingDamage);
                this.engine.applyDamage((CombatEntityAPI)ce, ce.getLocation(), damageDealt, DamageType.ENERGY, 200.0f, false, true, (Object)this.missile.getSource());
            }
        }
        for (final MissileAPI cm : closeMissiles) {
            this.engine.applyDamage((CombatEntityAPI)cm, cm.getLocation(), this.missile.getDamageAmount(), DamageType.FRAGMENTATION, 0.0f, false, true, (Object)this.missile.getSource());
        }
    }
    
    private void explodeFX() {
        if (MagicRender.screenCheck(0.1f, this.missile.getLocation())) {
            final int explosionColor = MathUtils.getRandomNumberInRange(0, 2);
            this.engine.addHitParticle(this.missile.getLocation(), bbplus_ExocetBombletAI.ZERO, this.explosionRadius * 2.0f, 1.0f, 1.0f, (Color)bbplus_ExocetBombletAI.EXPLOSION_COLOR.get(explosionColor));
            for (int j = 2; j >= 0; --j) {
                final float axis = (float)Math.random() * 360.0f;
                final float range = (float)Math.random() * 500.0f;
                this.engine.spawnExplosion(MathUtils.getPointOnCircumference(this.missile.getLocation(), range / 5.0f, axis), bbplus_ExocetBombletAI.ZERO, (Color)bbplus_ExocetBombletAI.EXPLOSION_COLOR.get(j), this.explosionRadius * 2.0f, 3.2f);
            }
            if (this.showVFX) {
                for (int k = 2; k >= 0; --k) {
                    final Vector2f point1 = MathUtils.getPointOnCircumference(this.missile.getLocation(), MathUtils.getRandomNumberInRange(5.0f, 60.0f), MathUtils.getRandomNumberInRange(0.0f, 360.0f));
                    final Vector2f point2 = MathUtils.getPointOnCircumference(this.missile.getLocation(), MathUtils.getRandomNumberInRange(5.0f, 550.0f), MathUtils.getRandomNumberInRange(0.0f, 360.0f));
                    Global.getCombatEngine().spawnEmpArc(this.missile.getSource(), point1, (CombatEntityAPI)null, (CombatEntityAPI)new SimpleEntity(point2), DamageType.ENERGY, 100.0f, 200.0f, 100000.0f, (String)null, MathUtils.getRandomNumberInRange(5.0f, 40.0f), (Color)bbplus_ExocetBombletAI.EXPLOSION_COLOR.get(k), (Color)bbplus_ExocetBombletAI.PARTICLE_COLOR.get(k));
                }
                for (int i = 0; i < 20; ++i) {
                    final float axis = (float)Math.random() * 360.0f;
                    final float range = (float)Math.random() * 500.0f;
                    this.engine.addHitParticle(MathUtils.getPointOnCircumference(this.missile.getLocation(), range / 5.0f, axis), MathUtils.getPointOnCircumference(bbplus_ExocetBombletAI.ZERO, range, axis), 10.0f + (float)Math.random() * 20.0f, 1.0f, 1.0f + (float)Math.random(), (Color)bbplus_ExocetBombletAI.PARTICLE_COLOR.get(explosionColor));
                }
            }
        }
    }
    
    @Override
    public CombatEntityAPI getTarget() {
        return this.target;
    }
    
    @Override
    public void setTarget(final CombatEntityAPI target) {
        this.target = target;
    }
    
}