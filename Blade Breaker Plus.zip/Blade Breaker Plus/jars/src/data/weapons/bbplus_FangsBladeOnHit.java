package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.util.IntervalUtil;
import java.util.List;
import java.util.ArrayList;
import java.awt.Color;
import org.lwjgl.util.vector.Vector2f;
import data.scripts.util.MagicRender;
import data.scripts.util.MagicLensFlare;
import data.scripts.plugins.MagicTrailPlugin;
import org.lazywizard.lazylib.MathUtils;
//import org.lazywizard.lazylib.VectorUtils;
public class bbplus_FangsBladeOnHit implements BeamEffectPlugin {

    private final IntervalUtil fireInterval = new IntervalUtil(0.05f, 0.05f);
    private final Vector2f ZERO = new Vector2f();
    public final float TURRET_OFFSET = 50f;
    private static final Color PARTICLE_COLOR = new Color(250,236,111,255);
    private static final float PARTICLE_SIZE = 4f;
    private static final float PARTICLE_BRIGHTNESS = 150f;
    private static final float PARTICLE_DURATION = .8f;
    private static final int PARTICLE_COUNT = 4;
    private static final float CONE_ANGLE = 150f;
    private static final float VEL_MIN = 0.1f;
    private static final float VEL_MAX = 0.3f;
    private static final float A_2 = CONE_ANGLE / 2;
    private boolean firstStrike = false;
    private float id2;
    private boolean runOnce = false;
    private WeaponAPI weapon;
    private final List<CombatEntityAPI> targets = new ArrayList<CombatEntityAPI>();
    private final List<CombatEntityAPI> hitTargets = new ArrayList<CombatEntityAPI>();
	
    @Override
    public void advance(final float amount, final CombatEngineAPI engine, final BeamAPI beam) {
        if(!this.runOnce) {
            //this.id = MagicTrailPlugin.getUniqueID();
            this.id2 = MagicTrailPlugin.getUniqueID();
            this.runOnce = true;
        }
	this.weapon = beam.getWeapon();
        beam.getDamage().setDamage(0);
        final CombatEntityAPI target = beam.getDamageTarget();
        if(!this.targets.contains(target)) {
            this.targets.add(target);
        }
        //final Vector2f spawnPoint = MathUtils.getRandomPointOnLine(beam.getFrom(), beam.getTo());
        if(this.weapon.isFiring()) {
            for(final CombatEntityAPI enemy : this.targets) {
                if(enemy == beam.getDamageTarget()) {
                    if(this.hitTargets.contains(beam.getDamageTarget())) {
		        //continue;
                    }
                    else {
                        boolean softFlux = true;
                        if(this.weapon.getDamage().isForceHardFlux() || this.weapon.getShip().getVariant().getHullMods().contains("high_scatter_amp")) {
                            softFlux = false;
                        }
                        float dmg = this.weapon.getDamage().getDamage() * this.weapon.getSpec().getBurstDuration();
                        final float mag = this.weapon.getShip().getFluxBasedEnergyWeaponDamageMultiplier() - 1f;
                        if(mag > 0) 
                            dmg = dmg*(1+mag);
                                engine.applyDamage(enemy, beam.getTo(), dmg, this.weapon.getDamageType(), dmg, false, softFlux, this.weapon.getShip()); 
                            this.hitTargets.add(enemy);
                            if (enemy instanceof ShipAPI) {
                                final ShipAPI empTarget = (ShipAPI)enemy;
                                for(int i = 0; i < 1; i++) {
                                    //final EmpArcEntityAPI arc 
                                    engine.spawnEmpArc(this.weapon.getShip(), beam.getTo(), empTarget, empTarget,
                                                    DamageType.ENERGY, 0f, dmg/2, 100f, null, 10f, beam.getFringeColor(), beam.getCoreColor());
                                }
                            }
                        
                    }
                }
            }
            this.fireInterval.advance(amount);
            if(this.fireInterval.intervalElapsed() && this.weapon.getChargeLevel() > .90f) {
                final float angle = weapon.getCurrAngle()-90f;			
                if(MagicRender.screenCheck(0.2f, beam.getFrom())) {					
                    MagicTrailPlugin.AddTrailMemberAdvanced(
                    this.weapon.getShip(), this.id2, Global.getSettings().getSprite("fx", "base_trail_zap"),
                    beam.getTo(), 
                    100f, 
                    50f,
                    angle, 
                    this.weapon.getShip().getAngularVelocity(), 
                    0f,
                    beam.getLength() / 3, beam.getLength() / 3, // /6
                    beam.getFringeColor(), beam.getCoreColor(), .7f,
                    .1f, .2f, 0f,
                    true,
                    300f, -256f, 0f,
                    null, null, null, 2f);
                }
            }				
        }
        if (target instanceof CombatEntityAPI) {
            //final float dur = beam.getDamage().getDpsDuration();
            if (!this.firstStrike) {
                final Vector2f point = beam.getTo();
                final float variance = MathUtils.getRandomNumberInRange(-0.3f, .3f);
                Global.getSoundPlayer().playSound("bbplus_fangs_beam_blade", 1f+variance, 1f+variance, point, this.ZERO);
                this.firstStrike = true;
                Vector2f.add(MathUtils.getPoint(new Vector2f(), 180, this.weapon.getCurrAngle()+180), this.weapon.getShip().getVelocity(), this.weapon.getShip().getVelocity());
                final Vector2f drift = MathUtils.getPoint(new Vector2f(), MathUtils.getRandomNumberInRange(0, 200), this.weapon.getCurrAngle());
                Vector2f.add(drift, new Vector2f(this.weapon.getShip().getVelocity()), drift);
            }
            //final float shipFacing = this.weapon.getCurrAngle();
            //final Vector2f shipVelocity = this.weapon.getShip().getVelocity();
            final Vector2f dir = Vector2f.sub(beam.getTo(), beam.getFrom(), new Vector2f());
            if (dir.lengthSquared() > 0) dir.normalise();
                dir.scale(50f);
            final Vector2f point = Vector2f.sub(beam.getTo(), dir, new Vector2f());
            if(MagicRender.screenCheck(0.2f, point)) {
                if(this.weapon.isFiring() && this.weapon.getChargeLevel() > 0f && this.weapon.getChargeLevel() < 1f || this.weapon.getChargeLevel() == 1f) {
                    final float radius = 10f + (this.weapon.getChargeLevel() * this.weapon.getChargeLevel()* MathUtils.getRandomNumberInRange(25f, 75f));
                    final Color color = beam.getFringeColor();
                    final Color core = beam.getCoreColor();					
                    final float speed = 500f;
                    final float facing = beam.getWeapon().getCurrAngle();
                        for (int i = 0; i <= PARTICLE_COUNT; i++) {
                            final float angle = MathUtils.getRandomNumberInRange(facing - A_2, facing + A_2);
                            final float vel = MathUtils.getRandomNumberInRange(speed * -VEL_MIN, speed * -VEL_MAX);
                            final Vector2f vector = MathUtils.getPointOnCircumference(null, vel, angle);
			    engine.addHitParticle(beam.getTo(), vector,
                                                    PARTICLE_SIZE,
                                                    PARTICLE_BRIGHTNESS,
                                                    PARTICLE_DURATION,
                                                    PARTICLE_COLOR);
                        }
                        if((float) Math.random() <= 0.10f) {
	                    MagicLensFlare.createSharpFlare(
                                engine,
                                beam.getSource(),
                                beam.getTo(),
                                4,
                                150,
                                beam.getWeapon().getCurrAngle(),
                                color,
                                core
                            );
                        }
                        if((float) Math.random() <= 0.15f) 
                            engine.addSmoothParticle(beam.getTo(), this.ZERO, radius, 0.1f+ this.weapon.getChargeLevel()* 0.25f, 0.1f, color);
                                engine.addHitParticle(beam.getTo(), this.ZERO, radius*.70f, 0.1f + this.weapon.getChargeLevel()* 0.1f, 0.1f, core);					
                        
                    }
                }
            
        }
    }

}