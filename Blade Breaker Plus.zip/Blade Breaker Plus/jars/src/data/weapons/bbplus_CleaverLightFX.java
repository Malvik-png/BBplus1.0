package data.scripts.weapons;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import data.scripts.DMEUtils;
import java.awt.Color;
import org.lwjgl.util.vector.Vector2f;
/**
 *
 * @author HarmfulMechanic
 * Based on scripts by Trylobot, Uomoz and Cycerin
 */
 // Based on istl_ShellheadFX, I just changed the flash color. Based.
public class bbplus_CleaverLightFX implements EveryFrameWeaponEffectPlugin {
    
    private static final float FIRE_DURATION = 0.15f; // Firing cycle time
    private static final Color FLASH_COLOR = new Color(250,215,75,255);
    private static final float OFFSET = 11f;
    private static final Color PARTICLE_COLOR = new Color(230,200,115,255); // Particle color
    private float elapsed = 0f;

    @Override
    public void advance(final float amount, final CombatEngineAPI engine, final WeaponAPI weapon) {
        if (engine.isPaused()) {
            return;
        }

        if (weapon.isFiring()) {
            final Vector2f weapon_location = weapon.getLocation();
            final ShipAPI ship = weapon.getShip();
            // explosion (frame 0 only)
            if (elapsed <= 0f) {
                final Vector2f explosion_offset = DMEUtils.translate_polar(weapon_location, OFFSET +
                                                                          ((0.05f * 100f) - 2f), weapon.getCurrAngle());
                engine.spawnExplosion(explosion_offset, ship.getVelocity(), FLASH_COLOR, 50f, 0.2f);
            }

            elapsed += amount;

            // particles
            final Vector2f particle_offset = DMEUtils.translate_polar(weapon_location, OFFSET, weapon.getCurrAngle());
            float size, speed, angle;
            Vector2f velocity;
            // more particles to start with, fewer later on
            final int particle_count_this_frame = (int) (25f * (FIRE_DURATION - elapsed));
            for (int x = 0; x < particle_count_this_frame; x++) {
                size = DMEUtils.get_random(3f, 6f);
                speed = DMEUtils.get_random(100f, 200f);
                angle = weapon.getCurrAngle() + DMEUtils.get_random(-60f, 60f);
                velocity = DMEUtils.translate_polar(ship.getVelocity(), speed, angle);
                engine.addHitParticle(particle_offset, velocity, size, 1.5f, 0.4f, PARTICLE_COLOR);
            }
        } else {
            elapsed = 0f;
        }
    }

}