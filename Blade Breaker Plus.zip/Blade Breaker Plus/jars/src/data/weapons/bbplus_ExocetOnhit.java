package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamageType;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.GuidedMissileAI;
import com.fs.starfarer.api.combat.MissileAPI;
import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import java.awt.Color;
import org.lwjgl.util.vector.Vector2f;
import org.lazywizard.lazylib.MathUtils;
/**
 * A simple on-hit effect for HE guns like the Howler
 *
 * @author Eliza Weisman
 */
public class bbplus_ExocetOnhit implements OnHitEffectPlugin {

    private static final int CRIT_DAMAGE_MIN = 400;
    private static final int CRIT_DAMAGE_MAX = 750;
    private static final float CRIT_CHANCE = 1.0f;
    private static final Color EXPLOSION_COLOR = new Color(175,125,255,255);
    private static final String SFX = "istl_shockarty_crit";
    private static final Color PARTICLE_COLOR = new Color(175,125,255,255);
    private static final float PARTICLE_SIZE = 7f;
    private static final float PARTICLE_BRIGHTNESS = 255f;
    private static final float PARTICLE_DURATION = 1.2f;
    private static final int PARTICLE_COUNT = 5;
    private static final float CONE_ANGLE = 150f;
    private static final float VEL_MIN = 0.2f;
    private static final float VEL_MAX = 0.3f;
    private static final float A_2 = CONE_ANGLE / 2;

    @Override
    public void onHit(final DamagingProjectileAPI projectile, final CombatEntityAPI target, final Vector2f point, final boolean shieldHit, final ApplyDamageResultAPI damageResult, final CombatEngineAPI engine) {

        final MissileAPI subProj = (MissileAPI) engine.spawnProjectile(projectile.getSource(),
	projectile.getWeapon(), "bbplus_exocet_collider_bomblet", projectile.getLocation(), projectile.getFacing(),null);
        subProj.setFromMissile(true);
        
        final GuidedMissileAI subAI = (GuidedMissileAI) subProj.getMissileAI();
        subAI.setTarget(target);

        if (target instanceof ShipAPI && !shieldHit && Math.random() <= CRIT_CHANCE) {
            // apply the extra damage to the target
            engine.applyDamage(target, point, // where to apply damage
                    MathUtils.getRandomNumberInRange(
                            CRIT_DAMAGE_MIN, CRIT_DAMAGE_MAX),
                    DamageType.HIGH_EXPLOSIVE, // damage type
                    0f, // amount of EMP damage (none)
                    false, // does this bypass shields? (no)
                    false, // does this deal soft flux? (no)
                    projectile.getSource());
            // do visual effects ---------------------------------------------
            engine.spawnExplosion(point,
                    target.getVelocity(),
                    EXPLOSION_COLOR, // color of the explosion
                    200f, // sets the size of the explosion
                    0.3f // how long the explosion lingers for
            );
            final float speed = projectile.getVelocity().length();
            final float facing = projectile.getFacing();
            for (int i = 0; i <= PARTICLE_COUNT; i++) {
                final float angle = MathUtils.getRandomNumberInRange(facing - A_2,
                        facing + A_2);
                final float vel = MathUtils.getRandomNumberInRange(speed * -VEL_MIN,
                        speed * -VEL_MAX);
                final Vector2f vector = MathUtils.getPointOnCircumference(null,
                        vel,
                        angle);
                engine.addHitParticle(point,
                        vector,
                        PARTICLE_SIZE,
                        PARTICLE_BRIGHTNESS,
                        PARTICLE_DURATION,
                        PARTICLE_COLOR);
            }
            //play a sound
            Global.getSoundPlayer().playSound(SFX, 1f, 1f, target.getLocation(), target.getVelocity());
        }

    }

}