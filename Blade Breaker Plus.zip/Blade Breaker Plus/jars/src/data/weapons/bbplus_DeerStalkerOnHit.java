package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ArmorGridAPI;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import com.fs.starfarer.api.impl.combat.DisintegratorEffect;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;
import org.lwjgl.util.vector.Vector2f;
/**
 *
 * @author Soren
 */
@SuppressWarnings("UnusedAssignment")
public class bbplus_DeerStalkerOnHit implements OnHitEffectPlugin {

    public static float DAMAGE = 300;
    private static final Color EXPLOSION_COLOR = new Color(65,175,255,235);

    @Override
    public void onHit(final DamagingProjectileAPI projectile, final CombatEntityAPI target, final Vector2f point, final boolean shieldHit, final ApplyDamageResultAPI damageResult, final CombatEngineAPI engine) {
        if (!shieldHit && target instanceof ShipAPI) {
            dealArmorDamage(projectile, (ShipAPI) target, point);
            engine.spawnExplosion(
                        point,
                        target.getVelocity(),
                        EXPLOSION_COLOR, // color of the explosion
                        100f, // sets the size of the explosion
                        1.0f // how long the explosion lingers for
                    );
        }
    }
	
    public static void dealArmorDamage(final DamagingProjectileAPI projectile, final ShipAPI target, final Vector2f point) {
        final CombatEngineAPI engine = Global.getCombatEngine();
        final ArmorGridAPI grid = target.getArmorGrid();
        final int[] cell = grid.getCellAtLocation(point);
        if (cell == null){ 
            return;
        }	
        final int gridWidth = grid.getGrid().length;
        final int gridHeight = grid.getGrid()[0].length;
        final float damageTypeMult = DisintegratorEffect.getDamageTypeMult(projectile.getSource(), target);
        float damageDealt = 0f;
        for (int i = -2; i <= 2; i++) {
            for (int j = -2; j <= 2; j++) {
                if ((i == 2 || i == -2) && (j == 2 || j == -2)) continue; // skip corners
                    int cx = cell[0] + i;
                    int cy = cell[1] + j;		
                    if (cx < 0 || cx >= gridWidth || cy < 0 || cy >= gridHeight) continue;
                        float damMult = 1/30f;
                        if (i == 0 && j == 0) {
                            damMult = 1/15f;
                        } else if (i <= 1 && i >= -1 && j <= 1 && j >= -1) { // S hits
                            damMult = 1/15f;
                        } else { // T hits
                            damMult = 1/30f;
                        }
                        final float armorInCell = grid.getArmorValue(cx, cy);
                        float damage = DAMAGE * damMult * damageTypeMult;
                        damage = Math.min(damage, armorInCell);
                        if (damage <= 0) continue;
                            target.getArmorGrid().setArmorValue(cx, cy, Math.max(0, armorInCell - damage));
                            damageDealt += damage;
            }
        }
        if (damageDealt > 0) {
            if (Misc.shouldShowDamageFloaty(projectile.getSource(), target)) {
                engine.addFloatingDamageText(point, damageDealt, Misc.FLOATY_ARMOR_DAMAGE_COLOR, target, projectile.getSource());
            }
            target.syncWithArmorGridState();
        }
    }

}