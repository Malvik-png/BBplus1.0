package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamageType;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import org.lwjgl.util.vector.Vector2f;
import org.lazywizard.lazylib.MathUtils;
import java.awt.Color;
/**
 * A simple on-hit effect for HE guns like the Howler
 *
 * @author Eliza Weisman
 */
 //based on previous Lens DEM
public class bbplus_FractalOnHit implements OnHitEffectPlugin {
    private static final int MIN_ARCS = 2;
    private static final int MAX_ARCS = 3;
    private static final float ARC_DAMAGE = 0.25f;
    private static final float ARC_EMP = 0.30f;
    // Declare important values as constants so that our
    // code isn't littered with magic numbers. If we want to
    // re-use this effect, we can easily just copy this class
    // and tweak some of these constants to get a similar effect.
    // -- crit damage -------------------------------------------------------
    // minimum amount of extra damage
    private static final int CRIT_DAMAGE_MIN = 150;
    // maximum amount of extra damage dealt
    private static final int CRIT_DAMAGE_MAX = 350;
    // probability (0-1) of dealing a critical hit
    private static final float CRIT_CHANCE = 1.0f;
    //  -- crit fx ----------------------------------------------------------
    // I took this from the 'core' color of the Howler projectile.
    // It can be changed
    private static final Color EXPLOSION_COLOR = new Color(175,125,255,255);
    // Kaboom
    private static final String SFX = "istl_shockarty_crit";
    // -- stuff for tweaking particle characteristics ------------------------
    // color of spawned particles
    private static final Color PARTICLE_COLOR = new Color(175,125,255,255);
    // size of spawned particles (possibly in pixels?)
    private static final float PARTICLE_SIZE = 10f;
    // brightness of spawned particles (i have no idea what this ranges from)
    private static final float PARTICLE_BRIGHTNESS = 255f;
    // how long the particles last (i'm assuming this is in seconds)
    private static final float PARTICLE_DURATION = 1.2f;
    private static final int PARTICLE_COUNT = 5;
    // -- particle geometry --------------------------------------------------
    // cone angle in degrees
    private static final float CONE_ANGLE = 150f;
    // constant that effects the lower end of the particle velocity
    private static final float VEL_MIN = 0.2f;
    // constant that effects the upper end of the particle velocity
    private static final float VEL_MAX = 0.3f;
    private static final float EXPLOSION_RADIUS = 150f;
    // how long the explosion lingers for
    private static final float EXPLOSION_DURATION = 0.1f;
    // one half of the angle. used internally, don't mess with thos
    private static final float A_2 = CONE_ANGLE / 2;

    @Override
    public void onHit(final DamagingProjectileAPI projectile, final CombatEntityAPI target, final Vector2f point, final boolean shieldHit, final ApplyDamageResultAPI damageResult,  final CombatEngineAPI engine) {
        // check whether or not we want to apply critical damage
        if (target instanceof ShipAPI && !shieldHit && Math.random() <= CRIT_CHANCE) {
            // apply the extra damage to the target
            engine.applyDamage(target, point, // where to apply damage
                    MathUtils.getRandomNumberInRange(
                            CRIT_DAMAGE_MIN, CRIT_DAMAGE_MAX),
                    DamageType.HIGH_EXPLOSIVE, // damage type
                    150f, // amount of EMP damage (none)
                    false, // does this bypass shields? (no)
                    false, // does this deal soft flux? (no)
                    projectile.getSource());

            // do visual effects ---------------------------------------------
            engine.spawnExplosion(point,
                    target.getVelocity(),
                    EXPLOSION_COLOR, // color of the explosion
                    90f, // sets the size of the explosion
                    0.3f // how long the explosion lingers for
            );
            final float dam = projectile.getDamageAmount() * ARC_DAMAGE;
            final float emp = projectile.getEmpAmount() * ARC_EMP;
            final float speed = projectile.getVelocity().length();
            final float facing = projectile.getFacing();
            final int arcs = MathUtils.getRandomNumberInRange(MIN_ARCS, MAX_ARCS);

            for (int empArc = 0; empArc < arcs; empArc++) {
                engine.spawnEmpArc(projectile.getSource(), point, target, target,
                        DamageType.ENERGY, // damage type
                        dam, // damage
                        emp, // emp 
                        100000f, // max range of arcs (on target)
                        "tachyon_lance_emp_impact", // sound
                        25f, // thickness
                        new Color(50, 55, 155, 255), // fringe color
                        new Color(200, 220, 255, 255) // core color
            );}
                
            for (int i = 0; i <= PARTICLE_COUNT; i++) {
                final float angle = MathUtils.getRandomNumberInRange(facing - A_2,
                        facing + A_2);
                final float vel = MathUtils.getRandomNumberInRange(speed * -VEL_MIN,
                        speed * -VEL_MAX);
                final Vector2f vector = MathUtils.getPointOnCircumference(null,
                        vel,
                        angle);
                engine.addHitParticle(point,
                        vector,
                        PARTICLE_SIZE,
                        PARTICLE_BRIGHTNESS,
                        PARTICLE_DURATION,
                        PARTICLE_COLOR);
            }
            final Vector2f v_target = new Vector2f(target.getVelocity());    
            // do visual effects
            engine.spawnExplosion(point, v_target,
                    EXPLOSION_COLOR, // color of the explosion
                    EXPLOSION_RADIUS,
                    EXPLOSION_DURATION
            );            
        //play a sound
        Global.getSoundPlayer().playSound(SFX, 1f, 1f, target.getLocation(), target.getVelocity());
        }
    }

}
