package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.DamageType;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import java.awt.Color;
import org.lwjgl.util.vector.Vector2f;
import org.lazywizard.lazylib.MathUtils;
import data.scripts.everyframe.bbplus_DecimatorRemnantEffectPlugin;

public class bbplus_DecimatorOnHit implements OnHitEffectPlugin {
    
    private static final int CRIT_DAMAGE_MIN = 100;
    private static final int CRIT_DAMAGE_MAX = 250;
    //private static final float CRIT_CHANCE = 0.2f;
    private static final Color EXPLOSION_COLOR;
    private static final Color PARTICLE_COLOR;
    static 
    {
        EXPLOSION_COLOR = new Color(205,50,15,255);
        PARTICLE_COLOR = new Color(190,50,25,255);
    }
    private static final String SFX_ONE = "istl_ballistic_crit";
    private static final String SFX_TWO = "bbplus_decimator_impact";
    private static final float PARTICLE_SIZE = 6.0f;
    private static final float PARTICLE_BRIGHTNESS = 255.0f;
    private static final float PARTICLE_DURATION = 0.9f;
    private static final int PARTICLE_COUNT = 7;
    private static final float CONE_ANGLE = 200.0f;
    private static final float VEL_MIN = 0.2f;
    private static final float VEL_MAX = 0.3f;
    private static final float A_2 = 75.0f;
    private static final float SIZE = 50f;
    private static final float DURATION = 1f;
    
    @Override
    public void onHit(final DamagingProjectileAPI projectile, final CombatEntityAPI target, final Vector2f point, final boolean shieldHit, final ApplyDamageResultAPI damageResult, final CombatEngineAPI engine) {
        if (target instanceof ShipAPI && !shieldHit) {
            final float variance = MathUtils.getRandomNumberInRange(-0.3f, 0.3f);
            final float speed = projectile.getVelocity().length();
            final float facing = projectile.getFacing();
            engine.applyDamage(target, point, (float)MathUtils.getRandomNumberInRange(CRIT_DAMAGE_MIN, CRIT_DAMAGE_MAX), DamageType.ENERGY, CONE_ANGLE, false, false, (Object)projectile.getSource());
            engine.spawnExplosion(point, target.getVelocity(), bbplus_DecimatorOnHit.EXPLOSION_COLOR, 100.0f, 0.85f);
            Global.getSoundPlayer().playSound(SFX_ONE, 1f+variance, 1f+variance, target.getLocation(), target.getVelocity());
            Global.getSoundPlayer().playSound(SFX_TWO, 1f+variance, 1f+variance, projectile.getLocation(), projectile.getVelocity());	
            bbplus_DecimatorRemnantEffectPlugin.addHaze(point, projectile, projectile.getWeapon(), projectile.getSource(), SIZE, DURATION);
            for (int i = 0; i <= PARTICLE_COUNT; ++i) {
                final float angle = MathUtils.getRandomNumberInRange(facing - A_2, facing + A_2);
                final float vel = MathUtils.getRandomNumberInRange(speed * -VEL_MIN, speed * -VEL_MAX);
                final Vector2f vector = MathUtils.getPointOnCircumference((Vector2f)null, vel, angle);
                engine.addHitParticle(point, vector, PARTICLE_SIZE, PARTICLE_BRIGHTNESS, PARTICLE_DURATION, bbplus_DecimatorOnHit.PARTICLE_COLOR);
            }
        }
    }
    
}