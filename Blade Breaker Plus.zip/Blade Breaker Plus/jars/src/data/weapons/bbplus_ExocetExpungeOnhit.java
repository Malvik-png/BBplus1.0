package data.scripts.weapons;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.GuidedMissileAI;
import com.fs.starfarer.api.combat.MissileAPI;
import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import org.lwjgl.util.vector.Vector2f;

public class bbplus_ExocetExpungeOnhit implements OnHitEffectPlugin {

    @Override
    public void onHit(final DamagingProjectileAPI projectile, final CombatEntityAPI target, final Vector2f point, final boolean shieldHit, final ApplyDamageResultAPI damageResult, final CombatEngineAPI engine) {

        final MissileAPI subProj = (MissileAPI) engine.spawnProjectile(projectile.getSource(),
	    projectile.getWeapon(), "bbplus_exocet_collider_rift", projectile.getLocation(), projectile.getFacing(),null);
        subProj.setFromMissile(true);

        final GuidedMissileAI subAI = (GuidedMissileAI) subProj.getMissileAI();
        subAI.setTarget(target);

    }

}