package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import data.scripts.util.MagicLensFlare;
import org.lwjgl.util.vector.Vector2f;
import java.awt.*;

public class bbplus_CleaverOnHit implements OnHitEffectPlugin {

    private static final Color EXPLOSION_COLOR = new Color(230,205,100,255);
    private static final float EXPLOSION_SIZE = 120f;
    private static final float EXPLOSION_DURATION = 0.6f;

    @Override
    public void onHit(final DamagingProjectileAPI projectile, final CombatEntityAPI target, final Vector2f point, final boolean shieldHit, final ApplyDamageResultAPI damageResult, final CombatEngineAPI engine) {
        final float HighExplosiveBonus = projectile.getDamageAmount()/4f;
        if (projectile.didDamage()) {
            Global.getCombatEngine().applyDamage(target, point, HighExplosiveBonus, DamageType.HIGH_EXPLOSIVE, HighExplosiveBonus, false, false, projectile.getSource(), true);
        }
        Global.getCombatEngine().spawnExplosion(point, new Vector2f(0f, 0f), EXPLOSION_COLOR, EXPLOSION_SIZE, EXPLOSION_DURATION);
            MagicLensFlare.createSharpFlare(
            engine,
            projectile.getSource(),
            projectile.getLocation(), 5, 350, 0,
            new Color(250, 230, 155),
            new Color(255, 255, 255)
        );
    }

}