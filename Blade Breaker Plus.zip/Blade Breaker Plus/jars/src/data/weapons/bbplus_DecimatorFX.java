package data.scripts.weapons;

import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import java.awt.Color;
import org.lwjgl.util.vector.Vector2f;
import data.scripts.DMEUtils;
/**
 *
 * @author Soren
 * Based on scripts by Trylobot, Uomoz and Cycerin
 */
public class bbplus_DecimatorFX implements EveryFrameWeaponEffectPlugin {
	
    private static final float FIRE_DURATION = 0.3f;
    private static final float OFFSET = 11.0f;
    private static final Color FLASH_COLOR;
    private static final Color PARTICLE_COLOR;
    static 
    {
        FLASH_COLOR = new Color(250,60,25,255);
        PARTICLE_COLOR = new Color(200,10,65,245);
    }    
    private float elapsed;
    public bbplus_DecimatorFX() {
        this.elapsed = 0.0f;
    }
    
    @Override
    public void advance(final float amount, final CombatEngineAPI engine, final WeaponAPI weapon) {
        if (engine.isPaused()) {
            return;
        }
        if (weapon.isFiring()) {
            final Vector2f weapon_location = weapon.getLocation();
            final ShipAPI ship = weapon.getShip();
            if (this.elapsed <= 0.0f) {
                final Vector2f explosion_offset = DMEUtils.translate_polar(weapon_location, 14.0f, weapon.getCurrAngle());
                engine.spawnExplosion(explosion_offset, ship.getVelocity(), bbplus_DecimatorFX.FLASH_COLOR, 50.0f, 0.2f);
            }
            this.elapsed += amount;
            final Vector2f particle_offset = DMEUtils.translate_polar(weapon_location, OFFSET, weapon.getCurrAngle());
            for (int particle_count_this_frame = (int)(15.0f * (FIRE_DURATION - this.elapsed)), x = 0; x < particle_count_this_frame; ++x) {
                final float size = DMEUtils.get_random(3.0f, 15.0f);
                final float speed = DMEUtils.get_random(150.0f, 300.0f);
                final float angle = weapon.getCurrAngle() + DMEUtils.get_random(-5.0f, 5.0f);
                final Vector2f velocity = DMEUtils.translate_polar(ship.getVelocity(), speed, angle);
                engine.addHitParticle(particle_offset, velocity, size, 1.5f, 0.4f, bbplus_DecimatorFX.PARTICLE_COLOR);
            }
        }
        else {
            this.elapsed = 0.0f;
        }
    }

}