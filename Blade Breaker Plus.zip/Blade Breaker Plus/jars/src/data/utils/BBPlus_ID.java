package data.scripts.utils;

import com.fs.starfarer.api.Global;

public class BBPlus_ID {
	
    private static final String BBPLUS = "bbplus";
    public static final String FACTION_ID = "the_deserter_ex";
    public static final String BBPLUS_SNRI_PACKAGE = "bbplus_snri_package";
           
    public static String assign(final String id){	
        return Global.getSettings().getString(BBPLUS, id);	
    }

    public static String faction_name(final String id){	
        return Global.getSettings().getString(FACTION_ID, id);	
    }   

}