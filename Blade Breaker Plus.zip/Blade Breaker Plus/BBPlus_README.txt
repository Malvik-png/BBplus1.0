- Please make sure you have the latest version of Dassault-Mikoyan Engineering mod since it relies heavily on it.

- Nexerelin BB Deserter start has a new starting option, please check them in-game. Furthermore, this mod adds one special mercenary group that is available for hiring.

- Adds a small selection of horrible kitbashed ships and weapons for Blade Breakers and their deserters. Will probably ruin your game and your life.

- This mod adds a new feature of using Sigma Matter on a ship through hullmods but you need to obtain the hullmod first from somewhere or someone. There's also a unique NPC hidden in the sector that you can turn in Sigma Matters and you might receive unique rewards for doing so.

- This mod will add new built-in hullmod for Starsylph (refit), Light and Heavy Cargo Rig. This built-in enables these ships to fit special logistic hullmods.

- Just to clear things up, this mod adds two HVBs to fight when you have Vayra Sector installed.

If you have questions or confused about what things that this mod adds, kindly check the other text file for the list of things OR just send me a message at discord @Mayu7150.


Footnotes:
Since this is my first mod and probably last, expect fucky shit, unnecessary bloat and something unbalanced.

Again, this is just a fanmod I made for fun; please message me if you have any complains or questions rather than bothering/contacting the original author: Harmful Mechanic. Thank you.



PS
cope techpriest ur very unbased

regards, Mayu